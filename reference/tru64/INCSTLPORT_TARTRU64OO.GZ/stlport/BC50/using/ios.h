#  ifdef _STLP_BROKEN_USING_DIRECTIVE
using namespace _STLP_NEW_IO_NAMESPACE;
#  else

using _STLP_NEW_IO_NAMESPACE::ios;
using _STLP_NEW_IO_NAMESPACE::streamoff;
using _STLP_NEW_IO_NAMESPACE::streamsize;

using _STLP_NEW_IO_NAMESPACE::ios_base;
using _STLP_NEW_IO_NAMESPACE::basic_ios;

// _lib.std.ios.manip_, manipulators:	
using _STLP_NEW_IO_NAMESPACE::boolalpha;
using _STLP_NEW_IO_NAMESPACE::noboolalpha;
using _STLP_NEW_IO_NAMESPACE::showbase;
using _STLP_NEW_IO_NAMESPACE::noshowbase;
using _STLP_NEW_IO_NAMESPACE::showpoint;
using _STLP_NEW_IO_NAMESPACE::noshowpoint;
using _STLP_NEW_IO_NAMESPACE::showpos;
using _STLP_NEW_IO_NAMESPACE::noshowpos;
using _STLP_NEW_IO_NAMESPACE::skipws;
using _STLP_NEW_IO_NAMESPACE::noskipws;
using _STLP_NEW_IO_NAMESPACE::uppercase;
using _STLP_NEW_IO_NAMESPACE::nouppercase;

// _lib.adjustfield.manip_ adjustfield:
using _STLP_NEW_IO_NAMESPACE::internal;
using _STLP_NEW_IO_NAMESPACE::left;
using _STLP_NEW_IO_NAMESPACE::right;

// _lib.basefield.manip_ basefield:
using _STLP_NEW_IO_NAMESPACE::dec;
using _STLP_NEW_IO_NAMESPACE::hex;
using _STLP_NEW_IO_NAMESPACE::oct;

// _lib.floatfield.manip_ floatfield:
using _STLP_NEW_IO_NAMESPACE::fixed;
using _STLP_NEW_IO_NAMESPACE::scientific;

#  endif  /* _STLP_BROKEN_USING_DIRECTIVE */

