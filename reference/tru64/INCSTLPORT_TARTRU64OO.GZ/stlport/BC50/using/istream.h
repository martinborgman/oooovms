
using _STLP_NEW_IO_NAMESPACE::basic_istream;
using _STLP_NEW_IO_NAMESPACE::basic_iostream;

using _STLP_NEW_IO_NAMESPACE::istream;
using _STLP_NEW_IO_NAMESPACE::iostream;

# if !defined (_STLP_NO_NATIVE_WIDE_STREAMS)
using _STLP_NEW_IO_NAMESPACE::wistream;
using _STLP_NEW_IO_NAMESPACE::wiostream;
# endif

#if !(defined (_STLP_MSVC) && (_STLP_MSVC < 1200))
using _STLP_NEW_IO_NAMESPACE::ws;
#endif
