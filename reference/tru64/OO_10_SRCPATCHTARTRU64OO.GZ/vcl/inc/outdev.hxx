/*************************************************************************
 *
 *  $RCSfile: outdev.hxx,v $
 *
 *  $Revision: 1.10 $
 *
 *  last change: $Author: hdu $ $Date: 2001/11/19 16:40:15 $
 *
 *  The Contents of this file are made available subject to the terms of
 *  either of the following licenses
 *
 *         - GNU Lesser General Public License Version 2.1
 *         - Sun Industry Standards Source License Version 1.1
 *
 *  Sun Microsystems Inc., October, 2000
 *
 *  GNU Lesser General Public License Version 2.1
 *  =============================================
 *  Copyright 2000 by Sun Microsystems, Inc.
 *  901 San Antonio Road, Palo Alto, CA 94303, USA
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License version 2.1, as published by the Free Software Foundation.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *  MA  02111-1307  USA
 *
 *
 *  Sun Industry Standards Source License Version 1.1
 *  =================================================
 *  The contents of this file are subject to the Sun Industry Standards
 *  Source License Version 1.1 (the "License"); You may not use this file
 *  except in compliance with the License. You may obtain a copy of the
 *  License at http://www.openoffice.org/license.html.
 *
 *  Software provided under this License is provided on an "AS IS" basis,
 *  WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING,
 *  WITHOUT LIMITATION, WARRANTIES THAT THE SOFTWARE IS FREE OF DEFECTS,
 *  MERCHANTABLE, FIT FOR A PARTICULAR PURPOSE, OR NON-INFRINGING.
 *  See the License for the specific provisions governing your rights and
 *  obligations concerning the Software.
 *
 *  The Initial Developer of the Original Code is: Sun Microsystems, Inc.
 *
 *  Copyright: 2000 by Sun Microsystems, Inc.
 *
 *  All Rights Reserved.
 *
 *  Contributor(s): _______________________________________
 *
 *
 ************************************************************************/

#ifndef _SV_OUTDEV_HXX
#define _SV_OUTDEV_HXX

#ifndef _GEN_HXX
#include <tools/gen.hxx>
#endif
#ifndef _STRING_HXX
#include <tools/string.hxx>
#endif
#ifndef _SV_SV_H
#include <sv.h>
#endif
#ifndef _SV_RC_HXX
#include <rc.hxx>
#endif
#ifndef _SV_COLOR_HXX
#include <color.hxx>
#endif
#ifndef _SV_FONT_HXX
#include <font.hxx>
#endif
#ifndef _SV_REGION_HXX
#include <region.hxx>
#endif
#ifndef _SV_MAPMOD_HXX
#include <mapmod.hxx>
#endif
#ifndef _SV_WALL_HXX
#include <wall.hxx>
#endif
#ifndef _SV_SETTINGS_HXX
#include <settings.hxx>
#endif

struct ImplOutDevData;
struct ImplFontEntry;
struct ImplObjStack;
struct ImplKernPairData;
class ImplFontCache;
class ImplDevFontList;
class ImplGetDevFontList;
class ImplGetDevSizeList;
class ImplMultiTextLineInfo;
class SalGraphics;
class ImplServerGraphics;
class Gradient;
class Hatch;
class Polygon;
class PolyPolygon;
class Bitmap;
class BitmapEx;
class Image;
class TextRectInfo;
class FontInfo;
class FontMetric;
class GDIMetaFile;
class OutDev3D;
class OpenGL;
class List;
class GfxLink;
class Line;
class LineInfo;
class AlphaMask;
class FontCharMap;

#ifndef _COM_SUN_STAR_UNO_REFERENCE_H_
#include <com/sun/star/uno/Reference.h>
#endif

namespace com {
namespace sun {
namespace star {
namespace awt {
    class XGraphics;
} } } }

#ifndef NOOLDSV
#include <gdiobj.hxx>
#endif

// ---------------------
// - OutputDevice-Data -
// ---------------------

struct ImplMapRes
{
    INT32                mnMapOfsX;          // Offset in X Richtung
    INT32                mnMapOfsY;          // Offset in Y Richtung
    INT32                mnMapScNumX;        // Skal.-faktor Zaehler X Richtung
    INT32                mnMapScNumY;        // Skal.-faktor Zaehler Y Richtung
    INT32                mnMapScDenomX;      // Skal.-faktor Nenner X Richtung
    INT32                mnMapScDenomY;      // Skal.-faktor Nenner Y Richtung
};

struct ImplThresholdRes
{
    INT32                mnThresLogToPixX;   // Schwellenwerte fuer Berechnung
    INT32                mnThresLogToPixY;   // mit BigInts
    INT32                mnThresPixToLogX;   // ""
    INT32                mnThresPixToLogY;   // ""
};

// ---------------
// - KerningPair -
// ---------------

struct KerningPair
{
    sal_Unicode         nChar1;
    sal_Unicode         nChar2;
    INT32                nKern;
};

// ----------------------
// - OutputDevice-Types -
// ----------------------

// Flags for Push()
#define PUSH_LINECOLOR                  ((USHORT)0x0001)
#define PUSH_FILLCOLOR                  ((USHORT)0x0002)
#define PUSH_FONT                       ((USHORT)0x0004)
#define PUSH_TEXTCOLOR                  ((USHORT)0x0008)
#define PUSH_MAPMODE                    ((USHORT)0x0010)
#define PUSH_CLIPREGION                 ((USHORT)0x0020)
#define PUSH_RASTEROP                   ((USHORT)0x0040)
#define PUSH_TEXTFILLCOLOR              ((USHORT)0x0080)
#define PUSH_TEXTALIGN                  ((USHORT)0x0100)
#define PUSH_REFPOINT                   ((USHORT)0x0200)
#define PUSH_TEXTLINECOLOR              ((USHORT)0x0400)
#define PUSH_ALLTEXT                    (PUSH_TEXTCOLOR | PUSH_TEXTFILLCOLOR | PUSH_TEXTLINECOLOR | PUSH_TEXTALIGN)
#define PUSH_ALLFONT                    (PUSH_ALLTEXT | PUSH_FONT)
#define PUSH_ALL                        ((USHORT)0xFFFF)

// Flags for DrawText()
#define TEXT_DRAW_DISABLE               ((USHORT)0x0001)
#define TEXT_DRAW_MNEMONIC              ((USHORT)0x0002)
#define TEXT_DRAW_MONO                  ((USHORT)0x0004)
#define TEXT_DRAW_CLIP                  ((USHORT)0x0008)
#define TEXT_DRAW_LEFT                  ((USHORT)0x0010)
#define TEXT_DRAW_CENTER                ((USHORT)0x0020)
#define TEXT_DRAW_RIGHT                 ((USHORT)0x0040)
#define TEXT_DRAW_TOP                   ((USHORT)0x0080)
#define TEXT_DRAW_VCENTER               ((USHORT)0x0100)
#define TEXT_DRAW_BOTTOM                ((USHORT)0x0200)
#define TEXT_DRAW_ENDELLIPSIS           ((USHORT)0x0400)
#define TEXT_DRAW_PATHELLIPSIS          ((USHORT)0x0800)
#define TEXT_DRAW_MULTILINE             ((USHORT)0x1000)
#define TEXT_DRAW_WORDBREAK             ((USHORT)0x2000)
#define TEXT_DRAW_NEWSELLIPSIS          ((USHORT)0x4000)

// Flags for CopyArea()
#define COPYAREA_WINDOWINVALIDATE       ((USHORT)0x0001)

// Flags for DrawImage()
#define IMAGE_DRAW_DISABLE              ((USHORT)0x0001)
#define IMAGE_DRAW_HIGHLIGHT            ((USHORT)0x0002)
#define IMAGE_DRAW_DEACTIVE             ((USHORT)0x0004)
#define IMAGE_DRAW_3DLOOK               0

#define IMAGE_DRAW_BTNLOOK              0

// WaveLine
#define WAVE_FLAT                       1
#define WAVE_SMALL                      2
#define WAVE_NORMAL                     3

// Grid
#define GRID_DOTS                       ((ULONG)0x00000001)
#define GRID_HORZLINES                  ((ULONG)0x00000002)
#define GRID_VERTLINES                  ((ULONG)0x00000004)
#define GRID_LINES                      (GRID_HORZLINES | GRID_VERTLINES)

// DrawModes
#define DRAWMODE_DEFAULT                ((ULONG)0x00000000)
#define DRAWMODE_BLACKLINE              ((ULONG)0x00000001)
#define DRAWMODE_BLACKFILL              ((ULONG)0x00000002)
#define DRAWMODE_BLACKTEXT              ((ULONG)0x00000004)
#define DRAWMODE_BLACKBITMAP            ((ULONG)0x00000008)
#define DRAWMODE_BLACKGRADIENT          ((ULONG)0x00000010)
#define DRAWMODE_GRAYLINE               ((ULONG)0x00000020)
#define DRAWMODE_GRAYFILL               ((ULONG)0x00000040)
#define DRAWMODE_GRAYTEXT               ((ULONG)0x00000080)
#define DRAWMODE_GRAYBITMAP             ((ULONG)0x00000100)
#define DRAWMODE_GRAYGRADIENT           ((ULONG)0x00000200)
#define DRAWMODE_NOFILL                 ((ULONG)0x00000400)
#define DRAWMODE_NOBITMAP               ((ULONG)0x00000800)
#define DRAWMODE_NOGRADIENT             ((ULONG)0x00001000)
#define DRAWMODE_GHOSTEDLINE            ((ULONG)0x00002000)
#define DRAWMODE_GHOSTEDFILL            ((ULONG)0x00004000)
#define DRAWMODE_GHOSTEDTEXT            ((ULONG)0x00008000)
#define DRAWMODE_GHOSTEDBITMAP          ((ULONG)0x00010000)
#define DRAWMODE_GHOSTEDGRADIENT        ((ULONG)0x00020000)
#define DRAWMODE_WHITELINE              ((ULONG)0x00100000)
#define DRAWMODE_WHITEFILL              ((ULONG)0x00200000)
#define DRAWMODE_WHITETEXT              ((ULONG)0x00400000)
#define DRAWMODE_WHITEBITMAP            ((ULONG)0x00800000)
#define DRAWMODE_WHITEGRADIENT          ((ULONG)0x01000000)
#define DRAWMODE_NOTRANSPARENCY         ((ULONG)0x10000000)

// Antialiasing
#define ANTIALIASING_DISABLE_TEXT       ((USHORT)0x0001)

// AddFontSubstitute
#define FONT_SUBSTITUTE_ALWAYS          ((USHORT)0x0001)
#define FONT_SUBSTITUTE_SCREENONLY      ((USHORT)0x0002)

// Default-Font
#define DEFAULTFONT_SANS_UNICODE        ((USHORT)1)
#define DEFAULTFONT_SANS                ((USHORT)2)
#define DEFAULTFONT_SERIF               ((USHORT)3)
#define DEFAULTFONT_FIXED               ((USHORT)4)
#define DEFAULTFONT_SYMBOL              ((USHORT)5)
#define DEFAULTFONT_UI_SANS             ((USHORT)1000)
#define DEFAULTFONT_UI_FIXED            ((USHORT)1001)
#define DEFAULTFONT_LATIN_TEXT          ((USHORT)2000)
#define DEFAULTFONT_LATIN_PRESENTATION  ((USHORT)2001)
#define DEFAULTFONT_LATIN_SPREADSHEET   ((USHORT)2002)
#define DEFAULTFONT_LATIN_HEADING       ((USHORT)2003)
#define DEFAULTFONT_LATIN_DISPLAY       ((USHORT)2004)
#define DEFAULTFONT_LATIN_FIXED         ((USHORT)2005)
#define DEFAULTFONT_CJK_TEXT            ((USHORT)3000)
#define DEFAULTFONT_CJK_PRESENTATION    ((USHORT)3001)
#define DEFAULTFONT_CJK_SPREADSHEET     ((USHORT)3002)
#define DEFAULTFONT_CJK_HEADING         ((USHORT)3003)
#define DEFAULTFONT_CJK_DISPLAY         ((USHORT)3004)
#define DEFAULTFONT_CTL_TEXT            ((USHORT)4000)
#define DEFAULTFONT_CTL_PRESENTATION    ((USHORT)4001)
#define DEFAULTFONT_CTL_SPREADSHEET     ((USHORT)4002)
#define DEFAULTFONT_CTL_HEADING         ((USHORT)4003)
#define DEFAULTFONT_CTL_DISPLAY         ((USHORT)4004)

#define DEFAULTFONT_FLAGS_ONLYONE       ((ULONG)0x00000001)

enum OutDevType { OUTDEV_DONTKNOW, OUTDEV_WINDOW, OUTDEV_PRINTER, OUTDEV_VIRDEV };

// ----------------
// - OutputDevice -
// ----------------

class OutputDevice : public Resource
{
    friend class Window;
    friend class VirtualDevice;
    friend class Printer;
    friend class ImplQPrinter;
    friend class OpenGL;

private:
#ifndef REMOTE_APPSERVER
    SalGraphics*        mpGraphics;
#else
    ImplServerGraphics* mpGraphics;
#endif
    OutputDevice*       mpPrevGraphics;
    OutputDevice*       mpNextGraphics;
    GDIMetaFile*        mpMetaFile;
    ImplFontEntry*      mpFontEntry;
    ImplFontCache*      mpFontCache;
    ImplDevFontList*    mpFontList;
    ImplGetDevFontList* mpGetDevFontList;
    ImplGetDevSizeList* mpGetDevSizeList;
    ImplObjStack*       mpObjStack;
    ImplOutDevData*     mpOutDevData;
    List*               mpUnoGraphicsList;
    OutDev3D*           mp3DContext;
    void*               mpDummy1;
    void*               mpDummy2;
    void*               mpDummy3;
    void*               mpDummy4;
    INT32                mnOutOffX;
    INT32                mnOutOffY;
    INT32                mnOutWidth;
    INT32                mnOutHeight;
    INT32                mnDPIX;
    INT32                mnDPIY;
    INT32                mnTextOffX;
    INT32                mnTextOffY;
    INT32                mnEmphasisAscent;
    INT32                mnEmphasisDescent;
    ULONG               mnDrawMode;
    INT32                mnDummy1;
    INT32                mnDummy2;
    ImplMapRes          maMapRes;
    ImplThresholdRes    maThresRes;
    OutDevType          meOutDevType;
    Region              maRegion;
    Color               maLineColor;
    Color               maFillColor;
    Font                maFont;
    Color               maTextColor;
    Color               maTextFillColorDummy; // For compatibility to SV we work with the font fill color
    Color               maTextLineColor;
    TextAlign           meTextAlign;
    RasterOp            meRasterOp;
    Wallpaper           maBackground;
    AllSettings         maSettings;
    MapMode             maMapMode;
    Point               maRefPoint;
    USHORT              mnAntialiasing;
    USHORT              mnAlignDummy;
    USHORT              mnDummy3;
    USHORT              mnDummy4;
    BOOL                mbMap:1,
                        mbClipRegion:1,
                        mbBackground:1,
                        mbOutput:1,
                        mbDevOutput:1,
                        mbOutputClipped:1,
                        mbLineColor:1,
                        mbFillColor:1,
                        mbInitLineColor:1,
                        mbInitFillColor:1,
                        mbInitFont:1,
                        mbInitTextColor:1,
                        mbInitClipRegion:1,
                        mbClipRegionSet:1,
                        mbKerning:1,
                        mbNewFont:1,
                        mbTextLines:1,
                        mbTextSpecial:1,
                        mbRefPoint:1,
                        mbDummy1:1,
                        mbDummy2:1,
                        mbDummy3:1;

#if _SOLAR__PRIVATE
#include <outdev.imp>
#endif

protected:
                        OutputDevice();

private:
                        OutputDevice( const OutputDevice& rOutDev );
    OutputDevice&       operator =( const OutputDevice& rOutDev );

public:
    virtual             ~OutputDevice();

    OutDevType          GetOutDevType() const { return meOutDevType; }

    void                Set3DContext( OutDev3D* p3DContext ) { mp3DContext = p3DContext; }
    OutDev3D*           Get3DContext() const { return mp3DContext; }
    OpenGL*             GetOpenGL();

    void                DrawTextLine( const Point& rPos, INT32 nWidth,
                                      FontStrikeout eStrikeout,
                                      FontUnderline eUnderline,
                                      BOOL bUnderlineAbove = FALSE );
    static BOOL         IsTextUnderlineAbove( const Font& rFont );

    void                DrawText( const Point& rStartPt, const XubString& rStr,
                                  xub_StrLen nIndex = 0, xub_StrLen nLen = STRING_LEN );
    INT32                GetTextWidth( const XubString& rStr, xub_StrLen nIndex = 0,
                                      xub_StrLen nLen = STRING_LEN ) const;
    INT32                GetTextHeight() const;
    void                DrawTextArray( const Point& rStartPt, const XubString& rStr,
                                       const INT32* pDXAry = NULL,
                                       xub_StrLen nIndex = 0,
                                       xub_StrLen nLen = STRING_LEN );
    INT32                GetTextArray( const XubString& rStr, INT32* pDXAry = NULL,
                                      xub_StrLen nIndex = 0,
                                      xub_StrLen nLen = STRING_LEN ) const;
    void                DrawStretchText( const Point& rStartPt, ULONG nWidth,
                                         const XubString& rStr,
                                         xub_StrLen nIndex = 0, xub_StrLen nLen = STRING_LEN );
    xub_StrLen          GetTextBreak( const XubString& rStr, INT32 nTextWidth,
                                      xub_StrLen nIndex = 0, xub_StrLen nLen = STRING_LEN,
                                      INT32 nCharExtra = 0 ) const;
    xub_StrLen          GetTextBreak( const XubString& rStr, INT32 nTextWidth,
                                      USHORT nExtraChar, xub_StrLen& rExtraCharPos,
                                      xub_StrLen nIndex, xub_StrLen nLen,
                                      INT32 nCharExtra = 0 ) const;
    void                GetCharWidth( sal_Unicode nFirstChar, sal_Unicode nLastChar,
                                      INT32* pWidthAry ) const;
    void                DrawText( const Rectangle& rRect,
                                  const XubString& rStr, USHORT nStyle = 0 );
    Rectangle           GetTextRect( const Rectangle& rRect,
                                     const XubString& rStr, USHORT nStyle = TEXT_DRAW_WORDBREAK,
                                     TextRectInfo* pInfo = NULL ) const;
    XubString           GetEllipsisString( const XubString& rStr, INT32 nMaxWidth,
                                           USHORT nStyle = TEXT_DRAW_ENDELLIPSIS ) const;
    void                DrawCtrlText( const Point& rPos, const XubString& rStr,
                                      xub_StrLen nIndex = 0, xub_StrLen nLen = STRING_LEN,
                                      USHORT nStyle = TEXT_DRAW_MNEMONIC );
    INT32                GetCtrlTextWidth( const XubString& rStr, xub_StrLen nIndex = 0,
                                          xub_StrLen nLen = STRING_LEN,
                                          USHORT nStyle = TEXT_DRAW_MNEMONIC ) const;
    static XubString    GetNonMnemonicString( const XubString& rStr, xub_StrLen& rMnemonicPos );
    static XubString    GetNonMnemonicString( const XubString& rStr )
                            { xub_StrLen nDummy; return GetNonMnemonicString( rStr, nDummy ); }

    ULONG               GetKerningPairCount() const;
    void                GetKerningPairs( ULONG nPairs, KerningPair* pKernPairs ) const;

    BOOL                GetGlyphBoundRect( xub_Unicode cChar, Rectangle& rRect,
                                           BOOL bOptimize = TRUE );
    BOOL                GetGlyphOutline( xub_Unicode cChar, PolyPolygon& rPolyPoly,
                                         BOOL bOptimize = TRUE );


    void                DrawPixel( const Point& rPt );
    void                DrawPixel( const Point& rPt, const Color& rColor );
    void                DrawPixel( const Polygon& rPts, const Color* pColors = NULL );
    void                DrawPixel( const Polygon& rPts, const Color& rColor );

#ifndef NOOLDSV
    void                DrawPoint( const Point& rPt ) { DrawPixel( rPt ); }
    void                InvertRect( const Rectangle& rRect );
    void                HighlightRect( const Rectangle& rRect ) { InvertRect( rRect ); }
#endif

    void                DrawLine( const Point& rStartPt, const Point& rEndPt );
    void                DrawLine( const Point& rStartPt, const Point& rEndPt,
                                  const LineInfo& rLineInfo );
    void                DrawPolyLine( const Polygon& rPoly );
    void                DrawPolyLine( const Polygon& rPoly,
                                      const LineInfo& rLineInfo );
    void                DrawPolygon( const Polygon& rPoly );
    void                DrawPolyPolygon( const PolyPolygon& rPolyPoly );
    void                DrawRect( const Rectangle& rRect );
    void                DrawRect( const Rectangle& rRect,
                                  ULONG nHorzRount, ULONG nVertRound );
    void                DrawEllipse( const Rectangle& rRect );
    void                DrawArc( const Rectangle& rRect,
                                 const Point& rStartPt, const Point& rEndPt );
    void                DrawPie( const Rectangle& rRect,
                                 const Point& rStartPt, const Point& rEndPt );
    void                DrawChord( const Rectangle& rRect,
                                   const Point& rStartPt, const Point& rEndPt );

    void                DrawOutDev( const Point& rDestPt, const Size& rDestSize,
                                    const Point& rSrcPt,  const Size& rSrcSize );
    void                DrawOutDev( const Point& rDestPt, const Size& rDestSize,
                                    const Point& rSrcPt,  const Size& rSrcSize,
                                    const OutputDevice& rOutDev );
    void                CopyArea( const Point& rDestPt,
                                  const Point& rSrcPt,  const Size& rSrcSize,
                                  USHORT nFlags = 0 );

    void                DrawBitmap( const Point& rDestPt,
                                    const Bitmap& rBitmap );
    void                DrawBitmap( const Point& rDestPt, const Size& rDestSize,
                                    const Bitmap& rBitmap );
    void                DrawBitmap( const Point& rDestPt, const Size& rDestSize,
                                    const Point& rSrcPtPixel, const Size& rSrcSizePixel,
                                    const Bitmap& rBitmap );

    void                DrawBitmapEx( const Point& rDestPt,
                                      const BitmapEx& rBitmapEx );
    void                DrawBitmapEx( const Point& rDestPt, const Size& rDestSize,
                                      const BitmapEx& rBitmapEx );
    void                DrawBitmapEx( const Point& rDestPt, const Size& rDestSize,
                                      const Point& rSrcPtPixel, const Size& rSrcSizePixel,
                                      const BitmapEx& rBitmapEx );

    void                DrawMask( const Point& rDestPt,
                                  const Bitmap& rBitmap, const Color& rMaskColor );
    void                DrawMask( const Point& rDestPt, const Size& rDestSize,
                                  const Bitmap& rBitmap, const Color& rMaskColor );
    void                DrawMask( const Point& rDestPt, const Size& rDestSize,
                                  const Point& rSrcPtPixel, const Size& rSrcSizePixel,
                                  const Bitmap& rBitmap, const Color& rMaskColor );

    void                DrawImage( const Point& rPos,
                                   const Image& rImage, USHORT nStyle = 0 );
    void                DrawImage( const Point& rPos, const Size& rSize,
                                   const Image& rImage, USHORT nStyle = 0 );

    void                DrawGradient( const Rectangle& rRect, const Gradient& rGradient );
    void                DrawGradient( const PolyPolygon& rPolyPoly, const Gradient& rGradient );
    void                AddGradientActions( const Rectangle& rRect,
                                            const Gradient& rGradient,
                                            GDIMetaFile& rMtf );

    void                DrawHatch( const PolyPolygon& rPolyPoly, const Hatch& rHatch );
    void                AddHatchActions( const PolyPolygon& rPolyPoly,
                                         const Hatch& rHatch,
                                         GDIMetaFile& rMtf );

    void                DrawWallpaper( const Rectangle& rRect, const Wallpaper& rWallpaper );
    void                DrawWaveLine( const Point& rStartPos, const Point& rEndPos, USHORT nStyle );
    void                DrawGrid( const Rectangle& rRect, const Size& rDist, ULONG nFlags );

    void                DrawTransparent( const PolyPolygon& rPolyPoly,
                                         USHORT nTransparencePercent );
    void                DrawTransparent( const GDIMetaFile& rMtf,
                                         const Point& rPos, const Size& rSize,
                                         const Gradient& rTransparenceGradient );

    Color               GetPixel( const Point& rPt ) const;
    Color*              GetPixel( const Polygon& rPts ) const;

    Bitmap              GetBitmap( const Point& rSrcPt, const Size& rSize ) const;

    void                EnableMapMode( BOOL bEnable = TRUE ) { mbMap = (bEnable != 0); }
    BOOL                IsMapModeEnabled() const { return mbMap; }

    void                SetConnectMetaFile( GDIMetaFile* pMtf ) { mpMetaFile = pMtf; }
    GDIMetaFile*        GetConnectMetaFile() const { return mpMetaFile; }

    void                EnableOutput( BOOL bEnable = TRUE ) { mbOutput = (bEnable != 0); }
    BOOL                IsOutputEnabled() const { return mbOutput; }
    BOOL                IsDeviceOutput() const { return mbDevOutput; }
    BOOL                IsDeviceOutputNecessary() const { return (mbOutput && mbDevOutput); }
    BOOL                IsOutputNecessary() const { return ((mbOutput && mbDevOutput) || (mpMetaFile != NULL)); }

    void                SetClipRegion();
    void                SetClipRegion( const Region& rRegion );
    Region              GetClipRegion() const;
    BOOL                IsClipRegion() const { return mbClipRegion; }
    Region              GetActiveClipRegion() const;

    void                MoveClipRegion( INT32 nHorzMove, INT32 nVertMove );
    void                IntersectClipRegion( const Rectangle& rRect );
    void                IntersectClipRegion( const Region& rRegion );

    void                SetAntialiasing( USHORT nMode =  0 );
    USHORT              GetAntialiasing() const { return mnAntialiasing; }

    void                SetDrawMode( ULONG nDrawMode );
    ULONG               GetDrawMode() const { return mnDrawMode; }

    void                SetRasterOp( RasterOp eRasterOp );
    RasterOp            GetRasterOp() const { return meRasterOp; }

    void                SetLineColor();
    void                SetLineColor( const Color& rColor );
    const Color&        GetLineColor() const { return maLineColor; }
    BOOL                IsLineColor() const { return mbLineColor; }

    void                SetFillColor();
    void                SetFillColor( const Color& rColor );
    const Color&        GetFillColor() const { return maFillColor; }
    BOOL                IsFillColor() const { return mbFillColor; }

    void                SetBackground();
    void                SetBackground( const Wallpaper& rBackground );

    const Wallpaper&    GetBackground() const { return maBackground; }
    BOOL                IsBackground() const { return mbBackground; }

    void                SetFont( const Font& rNewFont );
    const Font&         GetFont() const { return maFont; }
    void                SetTextColor( const Color& rColor );
    const Color&        GetTextColor() const { return maFont.GetColor(); }
    void                SetTextFillColor();
    void                SetTextFillColor( const Color& rColor );

    Color               GetTextFillColor() const;
    BOOL                IsTextFillColor() const { return !maFont.IsTransparent(); }
    void                SetTextLineColor();
    void                SetTextLineColor( const Color& rColor );
    const Color&        GetTextLineColor() const { return maTextLineColor; }
    BOOL                IsTextLineColor() const { return (maTextLineColor.GetTransparency() == 0); }
    void                SetTextAlign( TextAlign eAlign );
    TextAlign           GetTextAlign() const { return maFont.GetAlign(); }

    void                SetSettings( const AllSettings& rSettings ) { maSettings = rSettings; }
    const AllSettings&  GetSettings() const { return maSettings; }

#ifndef NOOLDSV
    void                SetPen( const Pen& rNewPen );
    const Pen&          GetPen() const;

    void                SetFillInBrush( const Brush& rNewBrush );
    const Brush&        GetFillInBrush() const;

    void                SetBackgroundBrush( const Brush& rNewBrush );
    const Brush&        GetBackgroundBrush() const;
#endif

    void                SetMapMode();
    void                SetMapMode( const MapMode& rNewMapMode );
    void                SetRelativeMapMode( const MapMode& rNewMapMode );
    const MapMode&      GetMapMode() const { return maMapMode; }
    BOOL                IsMapMode() const { return mbMap; }

    void                SetRefPoint();
    void                SetRefPoint( const Point& rRefPoint );
    const Point&        GetRefPoint() const { return maRefPoint; }
    BOOL                IsRefPoint() const { return mbRefPoint; }

    Point               LogicToPixel( const Point& rLogicPt ) const;
    Size                LogicToPixel( const Size& rLogicSize ) const;
    Rectangle           LogicToPixel( const Rectangle& rLogicRect ) const;
    Polygon             LogicToPixel( const Polygon& rLogicPoly ) const;
    PolyPolygon         LogicToPixel( const PolyPolygon& rLogicPolyPoly ) const;
    Region              LogicToPixel( const Region& rLogicRegion )const;
    Point               LogicToPixel( const Point& rLogicPt,
                                      const MapMode& rMapMode ) const;
    Size                LogicToPixel( const Size& rLogicSize,
                                      const MapMode& rMapMode ) const;
    Rectangle           LogicToPixel( const Rectangle& rLogicRect,
                                      const MapMode& rMapMode ) const;
    Polygon             LogicToPixel( const Polygon& rLogicPoly,
                                      const MapMode& rMapMode ) const;
    PolyPolygon         LogicToPixel( const PolyPolygon& rLogicPolyPoly,
                                      const MapMode& rMapMode ) const;
    Region              LogicToPixel( const Region& rLogicRegion,
                                      const MapMode& rMapMode ) const;
    Point               PixelToLogic( const Point& rDevicePt ) const;
    Size                PixelToLogic( const Size& rDeviceSize ) const;
    Rectangle           PixelToLogic( const Rectangle& rDeviceRect ) const;
    Polygon             PixelToLogic( const Polygon& rDevicePoly ) const;
    PolyPolygon         PixelToLogic( const PolyPolygon& rDevicePolyPoly ) const;
    Region              PixelToLogic( const Region& rDeviceRegion ) const;
    Point               PixelToLogic( const Point& rDevicePt,
                                      const MapMode& rMapMode ) const;
    Size                PixelToLogic( const Size& rDeviceSize,
                                      const MapMode& rMapMode ) const;
    Rectangle           PixelToLogic( const Rectangle& rDeviceRect,
                                      const MapMode& rMapMode ) const;
    Polygon             PixelToLogic( const Polygon& rDevicePoly,
                                      const MapMode& rMapMode ) const;
    PolyPolygon         PixelToLogic( const PolyPolygon& rDevicePolyPoly,
                                      const MapMode& rMapMode ) const;
    Region              PixelToLogic( const Region& rDeviceRegion,
                                      const MapMode& rMapMode ) const;

    Point               LogicToLogic( const Point&      rPtSource,
                                      const MapMode*    pMapModeSource,
                                      const MapMode*    pMapModeDest ) const;
    Size                LogicToLogic( const Size&       rSzSource,
                                      const MapMode*    pMapModeSource,
                                      const MapMode*    pMapModeDest ) const;
    Rectangle           LogicToLogic( const Rectangle&  rRectSource,
                                      const MapMode*    pMapModeSource,
                                      const MapMode*    pMapModeDest ) const;
    INT32*               LogicToLogic( INT32*             pX,
                                      USHORT            nCount,
                                      const MapMode*    pMapModeSource,
                                      const MapMode*    pMapModeDest ) const;
    static Point        LogicToLogic( const Point&      rPtSource,
                                      const MapMode&    rMapModeSource,
                                      const MapMode&    rMapModeDest );
    static Size         LogicToLogic( const Size&       rSzSource,
                                      const MapMode&    rMapModeSource,
                                      const MapMode&    rMapModeDest );
    static Rectangle    LogicToLogic( const Rectangle&  rRectSource,
                                      const MapMode&    rMapModeSource,
                                      const MapMode&    rMapModeDest );
    static INT32         LogicToLogic( INT32              nLongSource,
                                      MapUnit           eUnitSource,
                                      MapUnit           eUnitDest );

    Size                GetOutputSizePixel() const
                            { return Size( mnOutWidth, mnOutHeight ); }
    Size                GetOutputSize() const
                            { return PixelToLogic( GetOutputSizePixel() ); }

    void                Erase();
    void                Erase( const Rectangle& rRect ) { DrawWallpaper( rRect, GetBackground() ); }

    USHORT              GetDevFontCount() const;
    FontInfo            GetDevFont( USHORT nDevFont ) const;
    USHORT              GetDevFontSizeCount( const Font& rFont ) const;
    Size                GetDevFontSize( const Font& rFont, USHORT nSize ) const;
    BOOL                IsFontAvailable( const XubString& rFontName ) const;

    FontMetric          GetFontMetric() const;
    FontMetric          GetFontMetric( const Font& rFont ) const;
    BOOL                GetFontCharMap( FontCharMap& rFontCharMap ) const;

    xub_StrLen          HasGlyphs( const Font& rFont, const String& rStr,
                            xub_StrLen nIndex = 0, xub_StrLen nLen = STRING_LEN ) const;

#ifndef NOOLDSV
    Color               GetSolidColor( const Color& rColor ) const;
#endif

    USHORT              GetBitCount() const;
    ULONG               GetColorCount() const;

    void                Push( USHORT nFlags = PUSH_ALL );
    void                Pop();

    void                DrawEPS( const Point& rPt, const Size& rSz,
                                 const GfxLink& rGfxLink, GDIMetaFile* pSubst = NULL );

    ::com::sun::star::uno::Reference< ::com::sun::star::awt::XGraphics >    CreateUnoGraphics();
    List*               GetUnoGraphicsList() const      { return mpUnoGraphicsList; }
    List*               CreateUnoGraphicsList()         { mpUnoGraphicsList = new List; return mpUnoGraphicsList; }

    static void         BeginFontSubstitution();
    static void         EndFontSubstitution();
    static void         AddFontSubstitute( const XubString& rFontName,
                                           const XubString& rReplaceFontName,
                                           USHORT nFlags = 0 );
    static void         RemoveFontSubstitute( USHORT n );
    static USHORT       GetFontSubstituteCount();
    static void         GetFontSubstitute( USHORT n,
                                           XubString& rFontName,
                                           XubString& rReplaceFontName,
                                           USHORT& rFlags );

    static Font         GetDefaultFont( USHORT nType,
                                        LanguageType eLang,
                                        ULONG nFlags,
                                        const OutputDevice* pOutDev = NULL );
};

#endif // _SV_OUTDEV_HXX
