/*************************************************************************
 *
 *  $RCSfile$
 *
 *  $Revision: 1.2 $
 *
 *  last change: $Author: svesik $ $Date: 2001/02/19 15:53:21 $
 *
 *  The Contents of this file are made available subject to the terms of
 *  either of the following licenses
 *
 *         - GNU Lesser General Public License Version 2.1
 *         - Sun Industry Standards Source License Version 1.1
 *
 *  Sun Microsystems Inc., October, 2000
 *
 *  GNU Lesser General Public License Version 2.1
 *  =============================================
 *  Copyright 2000 by Sun Microsystems, Inc.
 *  901 San Antonio Road, Palo Alto, CA 94303, USA
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License version 2.1, as published by the Free Software Foundation.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *  MA  02111-1307  USA
 *
 *
 *  Sun Industry Standards Source License Version 1.1
 *  =================================================
 *  The contents of this file are subject to the Sun Industry Standards
 *  Source License Version 1.1 (the "License"); You may not use this file
 *  except in compliance with the License. You may obtain a copy of the
 *  License at http://www.openoffice.org/license.html.
 *
 *  Software provided under this License is provided on an "AS IS" basis,
 *  WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING,
 *  WITHOUT LIMITATION, WARRANTIES THAT THE SOFTWARE IS FREE OF DEFECTS,
 *  MERCHANTABLE, FIT FOR A PARTICULAR PURPOSE, OR NON-INFRINGING.
 *  See the License for the specific provisions governing your rights and
 *  obligations concerning the Software.
 *
 *  The Initial Developer of the Original Code is: Sun Microsystems, Inc.
 *
 *  Copyright: 2000 by Sun Microsystems, Inc.
 *
 *  All Rights Reserved.
 *
 *  Contributor(s): _______________________________________
 *
 *
 ************************************************************************/

#ifndef _RTL_STRING_HXX_
#include <rtl/string.hxx>
#endif
#include <typeinfo>

typedef struct _uno_Any uno_Any;
typedef struct _uno_Mapping uno_Mapping;

//
// According to the Alpha Calling Standard, the usage of the general purpose 
// (r) and floating point (f) registers are as follows:
//
//	r16-r21	Argument registers for nonfloating-point items of the argument
//		list
//	f16-f21 Argument registers for floating-point items of the argument
//		list
//	r0	Function value register that returns a nonfloating-point value
//	f0	Function value register that returns a floating-point value
//
// If the function has to return a complex data structure directly, r16 will
// contains the memory address to which the data structure should be copied.
// There will then be only five registers left for argument passing. The
// extra arguments that cannot be put into the registers are put into the
// stack.
//
// For a simple return, r16 or f16 will be used for passing the first argument.
// r17 or f17 will be used for passing the second argument, etc. No packing
// is done to fill out all the available argument registers. So no matter
// what the combination of floating and nonfloating arguments, only the first
// six arguments will be passed in the registers.
//
// Since the XInterface class contains only virtual functions and it is the
// the base class of all the UNO objects. So in both the ANSI and ARM object 
// models of DEC CXX, the first member of an UNO object should be a vptr
// pointing to a vtable for the following format:
//
//	+---------------------------------------+
//	| Pointer to RTTI information		|
//	+---------------------------------------+
//	| Virtual function 1 address		| <-- vptr
//	+---------------------------------------+
//			:
//	+---------------------------------------+
//	| Virtual function n address		|
//	+---------------------------------------+
//
#define	NUM_ARGREGS	6	/* Number of argument registers */

//
// The RTTI pointer in the virtual function table points to a variable of type
// typeinfo.
//
struct base_class_spec;
struct typeinfo {
    void       *vptr ;	// vptr of type_info from <typeinfo> header file
    const char *name ;	// Name of the type
    char       *Id   ;	// Id object pointer - COMMON storage for equality
			// comparisons
#ifdef	__MODEL_ARM
    void       *dtor ;	// ARM object model only
#endif
    base_class_spec *bc;	// Pointer to base class array
};

//
// In the ARM object model, the vptr[-1] points to a structure containing
// the offset to the top of the object and a pointer to the typeinfo variable.
//
struct arm_typedata {
    long	offset;
    typeinfo   *tinfo ;
} ;

//
// The base_class_spec type points to the accessible base classes and 
// how to convert to each.
//
struct base_class_spec {
    typeinfo	*tinfo;	// typeinfo for base class
    long	offset;	// The offset of the base class in the derived class
			// or the index of the virtual base class in vtable.
    unsigned char flags;// Flags
};

//
// Flags definition
//
#define	BCS_LAST	0x2	// TRUE if last base class spec in array
#define	BCS_DIRECT	0x10	// TRUE if is a direct base class

//
// The ANSI C++ object model uses a new throw specification using RTTI 
// to describe the type to throw and catch.
//
struct exception_type_spec {
    typeinfo	 *tinfo;	// A pointer to the RTTI type above
    unsigned int  flags;
    unsigned int *ptr_flags;
};

extern "C" {
	int __cxx_get_caught_object_info(void** , char*);
	int  _callVirtualMethod(void *, void **, double *, void **, double *, void *, int);
	void _SnippetExecutor();
}

//##################################################################################################
//#### exceptions ##################################################################################
//##################################################################################################

namespace CPPU_CURRENT_NAMESPACE {

void deccxx_tru64_alpha_raiseException( uno_Any * pUnoExc, uno_Mapping * pUno2Cpp );
void deccxx_tru64_alpha_fillUnoException( void*, const sal_Char *, uno_Any*, uno_Mapping * pCpp2Uno );
}

