/*************************************************************************
 *
 *  $RCSfile: except.cxx,v $
 *
 *  $Revision: 1.7 $
 *
 *  last change: $Author: pl $ $Date: 2001/07/05 14:36:39 $
 *
 *  The Contents of this file are made available subject to the terms of
 *  either of the following licenses
 *
 *         - GNU Lesser General Public License Version 2.1
 *         - Sun Industry Standards Source License Version 1.1
 *
 *  Sun Microsystems Inc., October, 2000
 *
 *  GNU Lesser General Public License Version 2.1
 *  =============================================
 *  Copyright 2000 by Sun Microsystems, Inc.
 *  901 San Antonio Road, Palo Alto, CA 94303, USA
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License version 2.1, as published by the Free Software Foundation.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *  MA  02111-1307  USA
 *
 *
 *  Sun Industry Standards Source License Version 1.1
 *  =================================================
 *  The contents of this file are subject to the Sun Industry Standards
 *  Source License Version 1.1 (the "License"); You may not use this file
 *  except in compliance with the License. You may obtain a copy of the
 *  License at http://www.openoffice.org/license.html.
 *
 *  Software provided under this License is provided on an "AS IS" basis,
 *  WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING,
 *  WITHOUT LIMITATION, WARRANTIES THAT THE SOFTWARE IS FREE OF DEFECTS,
 *  MERCHANTABLE, FIT FOR A PARTICULAR PURPOSE, OR NON-INFRINGING.
 *  See the License for the specific provisions governing your rights and
 *  obligations concerning the Software.
 *
 *  The Initial Developer of the Original Code is: Sun Microsystems, Inc.
 *
 *  Copyright: 2000 by Sun Microsystems, Inc.
 *
 *  All Rights Reserved.
 *
 *  Contributor(s): _______________________________________
 *
 *
 ************************************************************************/

#include <dlfcn.h>
#include <new.h>
#include <typeinfo>
#include <list>
#include <map>
#include <strings.h>
#include <alloca.h>
#ifndef _RTL_ALLOC_H_
#include <rtl/alloc.h>
#endif
#ifndef _OSL_DIAGNOSE_H_
#include <osl/diagnose.h>
#endif

#ifndef _BRIDGES_CPP_UNO_BRIDGE_HXX_
#include <bridges/cpp_uno/bridge.hxx>
#endif
#ifndef _TYPELIB_TYPEDESCRIPTION_HXX_
#include <typelib/typedescription.hxx>
#endif
#ifndef _COM_SUN_STAR_UNO_ANY_HXX_
#include <com/sun/star/uno/Any.hxx>
#endif

#ifndef _RTL_STRBUF_HXX_
#include <rtl/strbuf.hxx>
#endif

#include "deccxx_tru64_alpha.hxx"
#include "except.h"

using namespace std;
using namespace osl;
using namespace rtl;
using namespace com::sun::star::uno;

static long id ;

#ifdef	__MODEL_ANSI
#define	TYPE_INFO_VPTR	__7__vtbl_Q2_3std9type_info
#else	// __MODEL_ARM
#define	TYPE_INFO_VPTR	__vtbl_3std9type_info__3std
#endif
extern void *TYPE_INFO_VPTR;

// need a += operator for OString and sal_Char
namespace rtl
{
	inline OString& operator+=( OString& rString, sal_Char cAdd )
	{
		sal_Char add[2];
		add[0] = cAdd;
		add[1] = 0;
		return rString += add;
	}
}

namespace CPPU_CURRENT_NAMESPACE
{

//==================================================================================================
//
// Look for name in the RTTI data structure of the format "com::sun::..." 
// and convert "::" to ".".
//
static OString toUNOname( const sal_Char *pRTTI )
{
	OString aRet;

	const sal_Char* pName = pRTTI;
	const sal_Char* pLast ;
#if 0
	if (pRTTI->bc && (strchr(pName, ':') == NULL))
	{
	    // Find a direct base class with "::"
	    for (int idx = 0 ; 1 ; idx++)
	    {
	        if ((pRTTI->bc[idx].flags & BCS_DIRECT) && 
		     strchr(pRTTI->bc[idx].tinfo->name, ':'))
		{
		    pName = pRTTI->bc[idx].tinfo->name ;
		    break ;
		}
		if (pRTTI->bc[idx].flags & BCS_LAST)
		    break ;
	    }
	}
	// Extract the part within <>, if presence
	if ((pLast = strchr(pName, '<')) != NULL)
	{
	    pName = ++pLast ;	// Skip to after '<'
	    pLast = strchr(pName, '>') ;
	}
	else
#endif
	    pLast = pName + strlen(pName) ;
	// Skip leading ::
	while (*pName == ':') pName++ ;

	while( pName < pLast )
	{
		if (*pName == ':')
		{
		    aRet += ".";
		    while (*pName == ':') pName++ ;
		}
		else
		    aRet += *pName++ ;
	}

	return aRet;
}
//==================================================================================================
static OString toRTTIname( const OString & rUNOname )
{
    OStringBuffer aRet( rUNOname.getLength()*2 );

    sal_Int32 nIndex = 0;
    do
    {
        if( nIndex > 0 )
            aRet.append( "::" );
        aRet.append( rUNOname.getToken( 0, '.', nIndex ) );
    } while( nIndex != -1 );

    return aRet.makeStringAndClear();
}
 
//==================================================================================================
static void fillExceptionTypeSpec(typelib_CompoundTypeDescription* pCompTypeDescr, exception_type_spec *pExc, typeinfo *pRTTI)
{
	OString aUNOCompTypeName( OUStringToOString( pCompTypeDescr->aBase.pTypeName, RTL_TEXTENCODING_ASCII_US ) );
	OString aRTTICompTypeName( toRTTIname( aUNOCompTypeName ) );
	// type_info virtual function pointer

	pRTTI->vptr = TYPE_INFO_VPTR;
	pRTTI->name = strdup(aRTTICompTypeName.getStr()) ;
	pRTTI->Id   = (char *)&id ;
	pRTTI->bc   = NULL ;
#ifdef	__MODEL_ARM
	pRTTI->dtor = NULL ;
#endif

	pExc->tinfo	= pRTTI ;
	pExc->flags	= 0 ;
	pExc->ptr_flags = 0 ;
}

//__________________________________________________________________________________________________

//##################################################################################################
//#### exported ####################################################################################
//##################################################################################################

void deccxx_tru64_alpha_raiseException( uno_Any * pUnoExc, uno_Mapping * pUno2Cpp )
{
	typelib_TypeDescription * pTypeDescr = 0;
	// will be released by deleteException
	typelib_typedescriptionreference_getDescription( &pTypeDescr, pUnoExc->pType );
	OString aUNOCompTypeName( OUStringToOString( ((typelib_CompoundTypeDescription *)pTypeDescr)->aBase.pTypeName, RTL_TEXTENCODING_ASCII_US ) );
	OString aRTTICompTypeName( toRTTIname( aUNOCompTypeName ) );
	const sal_Char *exctype = aRTTICompTypeName.getStr() ;
	void	       *pCppExc = alloca( pTypeDescr->nSize );

	uno_copyAndConvertData( pCppExc, pUnoExc->pData, pTypeDescr, pUno2Cpp );
	
	// destruct uno exception
	uno_any_destruct( pUnoExc, 0 );

#include "except_throw.cxx"

	// Should not reach here
	printf("### deccxx: Unknown UNO exception - %s\n", exctype) ;
}

void deccxx_tru64_alpha_fillUnoException(
	void* pCppExc,
	const sal_Char *pRTTI,
	uno_Any* pExc,
	uno_Mapping * pCpp2Uno )
{
	OUString aName( OStringToOUString( toUNOname( pRTTI ), RTL_TEXTENCODING_ASCII_US ) );
	typelib_TypeDescription * pExcTypeDescr = 0;
	typelib_typedescription_getByName(
		&pExcTypeDescr,
		aName.pData );
	if (pExcTypeDescr)
	{
		// construct cpp exception any
		Any aAny( pCppExc, pExcTypeDescr ); // const_cast
		typelib_typedescription_release( pExcTypeDescr );
		// construct uno exception any
		typelib_TypeDescription* pAnyDescr = 0;
		getCppuType( (const Any *)0 ).getDescription( &pAnyDescr );
		uno_copyAndConvertData( pExc, &aAny, pAnyDescr, pCpp2Uno );
		typelib_typedescription_release( pAnyDescr );
	}
}

}

