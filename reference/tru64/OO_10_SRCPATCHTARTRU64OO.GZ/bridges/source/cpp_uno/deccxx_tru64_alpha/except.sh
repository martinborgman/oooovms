#!/bin/sh
#
# This script finds out all the exception type defined under com/sun/star/*
# generates three source files to be included by the bridge code to handle
# exception catching and throwing.
#
# Usage: ./except.sh
#
[ -z "$SOLARVERSION" ] && {
    echo "SOLARVERSION variable not defined!"
    exit 1
}
INC=$SOLARVERSION/unxt64.pro/inc
EXCEPTIONS=`cd $INC; find com/sun/star -name "*Exception.hdl" -print |\
	    sed -e "/\/Exception.hdl/d;s/\.hdl//"`
#
# Reorder the exception list so that the all the derived exception classes will
# be listed before their base exception classes. Exceptions that include
# sequence.h are currently excluded.
#
rm -f except.list
touch except.list
for EXC in $EXCEPTIONS
do
    SUFFIX=.hdl
    grep -q $EXC except.list
    [ $? -ne 0 ] && {
	BASE_EXCS=`grep "[^/]Exception.hdl" $INC/${EXC}.hdl | \
		   sed -e "s#.*<##;s#>##;s/\.hdl//"`
	[ -n "$BASE_EXCS" ] && {
	    for BEXC in $BASE_EXCS
	    do
		BBEXCS=`grep "[^/]Exception.hdl" $INC/${BEXC}${SUFFIX} |\
			sed -e "s#.*<##;s#>##;s/\.hdl//"`
		[ -n "$BBEXCS" ] && {
		    for BBEXC in $BBEXCS
		    do
			grep -q $BBEXC except.list
			[ $? -ne 0 ] && echo ${BBEXC}${SUFFIX} >> except.list
		    done
		}
		grep -q $BEXC except.list
		[ $? -ne 0 ] && {
		    (echo ${BEXC}${SUFFIX}; cat except.list) >> except.list2
		    mv except.list2 except.list
		}
	    done
	}
	#
	# For hdl file that include Sequence.h, change it to hpp
	#
	grep -q "Sequence\.h" $INC/${EXC}.hdl
	[ $? -eq 0 ] && SUFFIX=.hpp

	(echo ${EXC}${SUFFIX}; cat except.list) > except.list2
	mv except.list2 except.list
    }
done
echo "com/sun/star/uno/Exception.hdl" >> except.list

rm -f except.h except_catch.cxx except_throw.cxx
for EXC in `cat except.list`
do
DEF=`echo $EXC | tr '[:lower:]' '[:upper:]' |\
     sed -e 's#/#_#g;s#\.#_#;s#^#_#;s#$#_#'`
TYPE=`echo $EXC | sed -e 's#/#::#g;s#\.h..$##'`

echo "
#ifndef $DEF
#include <$EXC>
#endif" >> except.h

echo "
	if (strcmp(exctype, \"$TYPE\") == 0)
	    throw *($TYPE *)pCppExc;" >> except_throw.cxx

echo "
	catch (::$TYPE CppExc) {
	    deccxx_tru64_alpha_fillUnoException(&CppExc, \"$TYPE\", 
				*ppUnoExc, &pThis->pBridge->aCpp2Uno) ;
	}" >> except_catch.cxx
done
rm -f except.list
