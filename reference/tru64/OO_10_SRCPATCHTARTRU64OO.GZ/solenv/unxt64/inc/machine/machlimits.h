#ifndef _MACH_MACHLIMITS_H_
#include "/usr/include/machine/machlimits.h"

/*
 * Change LONG_MAX, LONG_MIN & ULONG_MAX to *INT*
 */
#undef	LONG_MAX
#define	LONG_MAX	INT_MAX
#undef	LONG_MIN
#define	LONG_MIN	INT_MIN
#undef	ULONG_MAX
#define	ULONG_MAX	UINT_MAX
#endif
