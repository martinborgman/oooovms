/*************************************************************************
 *
 *  $RCSfile: sockets.cxx,v $
 *
 *  $Revision: 1.2 $
 *
 *  last change: $Author: jl $ $Date: 2001/03/14 10:01:12 $
 *
 *  The Contents of this file are made available subject to the terms of
 *  either of the following licenses
 *
 *         - GNU Lesser General Public License Version 2.1
 *         - Sun Industry Standards Source License Version 1.1
 *
 *  Sun Microsystems Inc., October, 2000
 *
 *  GNU Lesser General Public License Version 2.1
 *  =============================================
 *  Copyright 2000 by Sun Microsystems, Inc.
 *  901 San Antonio Road, Palo Alto, CA 94303, USA
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License version 2.1, as published by the Free Software Foundation.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *  MA  02111-1307  USA
 *
 *
 *  Sun Industry Standards Source License Version 1.1
 *  =================================================
 *  The contents of this file are subject to the Sun Industry Standards
 *  Source License Version 1.1 (the "License"); You may not use this file
 *  except in compliance with the License. You may obtain a copy of the
 *  License at http://www.openoffice.org/license.html.
 *
 *  Software provided under this License is provided on an "AS IS" basis,
 *  WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING,
 *  WITHOUT LIMITATION, WARRANTIES THAT THE SOFTWARE IS FREE OF DEFECTS,
 *  MERCHANTABLE, FIT FOR A PARTICULAR PURPOSE, OR NON-INFRINGING.
 *  See the License for the specific provisions governing your rights and
 *  obligations concerning the Software.
 *
 *  The Initial Developer of the Original Code is: Sun Microsystems, Inc.
 *
 *  Copyright: 2000 by Sun Microsystems, Inc.
 *
 *  All Rights Reserved.
 *
 *  Contributor(s): _______________________________________
 *
 *
 ************************************************************************/
#ifdef GCC   
#define __PUT_STATIC_DATA_MEMBERS_HERE
#endif

#include <stdio.h>
#include <stdlib.h>
#include <iostream.h>
#include <string.h>
#include <errno.h>

#include <vos/socket.hxx>
#include <vos/thrdsrv.hxx>
#include <vos/ref.hxx>
#include <vos/thread.hxx>
#include <vos/profile.hxx>
#include <vos/process.hxx>
#include <vos/timer.hxx>

#ifndef _OSL_TIME_H_
#include <osl/time.h>
#endif
#ifndef _VOS_NO_NAMESPACE
using namespace vos;
#endif

//typedef enum { sal_False, sal_True } sal_Bool;


#define PORT   10001

class OSender : public NAMESPACE_VOS(OExecutable)
{
public:
	sal_Bool execute()
	{
		cout << "creating sender socket" << endl;
		NAMESPACE_VOS(OConnectorSocket) Socket;

		cout << "Binding sender socket to any available address." << endl;

		NAMESPACE_VOS(OInetSocketAddr) Addr; 
		if(!Socket.bind(Addr))
		{
			char err[80];
			rtl::OUString	err_str;
			Socket.getError(err_str); rtl::OString ostr(err_str.getStr(), err_str.getLength(), RTL_TEXTENCODING_UTF8);
			strcpy (err, ostr.getStr());
			cout << "binding sender failed with error: " << err << endl;
			return sal_False;
		}

//		cout << "connecting to: " << flush;
		cout << "connecting to: " << endl;

		rtl::OUString   hostName1, local_str1("localhost", 9, RTL_TEXTENCODING_UTF8);
		NAMESPACE_VOS(OInetSocketAddr) AddrTarget(local_str1, PORT);
		
		AddrTarget.getHostname(hostName1);
		char tmpStr1[16]; sprintf(tmpStr1, "%d", AddrTarget.getPort());
		rtl::OString ostr1(hostName1.getStr(), hostName1.getLength(), RTL_TEXTENCODING_UTF8);
		cout << ostr1.getStr() << " Port: " << tmpStr1 << endl;

		if(Socket.connect(AddrTarget) != OSocket::TResult_Ok) 
		{
			char err[80];
                        rtl::OUString   err_str;
                        Socket.getError(err_str); rtl::OString ostr(err_str.getStr(), err_str.getLength(), RTL_TEXTENCODING_UTF8);
                        strcpy (err, ostr.getStr());
			cout << "connect failed with error: " << err << endl;
			return sal_False;
		}

		NAMESPACE_VOS(OInetSocketAddr) PeerAddr;
		cout << "Check getPeerAddr(), getPeerHost(), getPeerPort()." << endl 
			 << "All addresses should be equal." << endl << endl;
		Socket.getPeerAddr(PeerAddr);
		rtl::OUString	hostName2, dottedAd2;
                PeerAddr.getHostname(hostName2);
		PeerAddr.getDottedAddr(dottedAd2);
                rtl::OString ostr2(hostName2.getStr(), hostName2.getLength(), RTL_TEXTENCODING_UTF8);
                rtl::OString ostr3(dottedAd2.getStr(), dottedAd2.getLength(), RTL_TEXTENCODING_UTF8);
                sprintf(tmpStr1, "%d", PeerAddr.getPort());

		cout << "getPeerAddr().getHostName(): " << ostr2.getStr() << endl 
			 << "getPeerAddr().getDottedAddr(): " << ostr3.getStr() << endl
			 << "getPeerAddr().getPort(): " << tmpStr1 << endl;
		cout << endl;
		rtl::OUString	peerHost1;
		Socket.getPeerHost(peerHost1);
		rtl::OString ostr4(peerHost1.getStr(), peerHost1.getLength(), RTL_TEXTENCODING_UTF8);
		sprintf(tmpStr1, "%d", Socket.getPeerPort());
		cout << "Socket.getPeerHost(): " << ostr4.getStr() << endl
			 << "Socket.getPeerPort(): " << tmpStr1 << endl;


		cout << endl << "Sending data (Hallo)" << endl;

		if(Socket.send("Hallo", 5) != 5)
		{
			char err[80];
                        rtl::OUString   err_str;
                        Socket.getError(err_str); rtl::OString ostr(err_str.getStr(), err_str.getLength(), RTL_TEXTENCODING_UTF8);
                        strcpy (err, ostr.getStr());
			cout << "send failed with error: " << err << endl;
			return sal_False;
		}

		cout << "Closing sender" << endl;
		if(!Socket.shutdown()) 
		{
			char err[80];
                        rtl::OUString   err_str;
                        Socket.getError(err_str); rtl::OString ostr(err_str.getStr(), err_str.getLength(), RTL_TEXTENCODING_UTF8);
                        strcpy (err, ostr.getStr());
			cout << "shutdown failed with error: " << err << endl;
			return sal_False;
		}

		cout << "Sender done." << endl;

		return sal_False;
	}
};

class OReceiver : public NAMESPACE_VOS(OExecutable)
{
public:
	sal_Bool execute()
	{

		cout << "creating receiver-socket" << endl;
		NAMESPACE_VOS(OAcceptorSocket) Socket;
		rtl::OUString   local_str2("localhost", 9, RTL_TEXTENCODING_UTF8);
		NAMESPACE_VOS(OInetSocketAddr) Addr(local_str2, PORT);
		rtl::OUString	hostName3, dottedAd3;
                Addr.getHostname(hostName3);
                Addr.getDottedAddr(dottedAd3);
		char tmpStr1[16]; sprintf(tmpStr1, "%d", Addr.getPort());
                rtl::OString ostr5(hostName3.getStr(), hostName3.getLength(), RTL_TEXTENCODING_UTF8);
                rtl::OString ostr6(dottedAd3.getStr(), dottedAd3.getLength(), RTL_TEXTENCODING_UTF8);
  		cout << "Receiver Addr is: Host: " << ostr5.getStr() << " IP: " << ostr6.getStr() << " Port: " << tmpStr1 << endl;

		cout << endl << "binding receiver socket: " << endl;
		Socket.setReuseAddr(1);

		if(!Socket.bind(Addr))
		{
			char err[80];
                        rtl::OUString   err_str;
                        Socket.getError(err_str); rtl::OString ostr(err_str.getStr(), err_str.getLength(), RTL_TEXTENCODING_UTF8);
                        strcpy (err, ostr.getStr());
			cout << "binding receiver failed with error: " << err << endl;
			return sal_False;
		}

		NAMESPACE_VOS(OInetSocketAddr) LocalAddr;
		cout << "check getLocalAddr(), getLocalHost(), getLocalPort()." << endl 
			 << "All addresses should be equal." << endl << endl;

		//
		Socket.getLocalAddr(LocalAddr);
		rtl::OUString	hostName4, dottedAd4, localHostName;
                LocalAddr.getHostname(hostName4);
                LocalAddr.getLocalHostname(localHostName);
                LocalAddr.getDottedAddr(dottedAd4);
		cout << "getLocalAddr().getHostName(): "; 
                rtl::OString ostr7(hostName4.getStr(), hostName4.getLength(), RTL_TEXTENCODING_UTF8);
                rtl::OString ostr8(dottedAd4.getStr(), dottedAd4.getLength(), RTL_TEXTENCODING_UTF8);
                rtl::OString ostr9(localHostName.getStr(), localHostName.getLength(), RTL_TEXTENCODING_UTF8);
		cout << ostr7.getStr() << endl;
		cout << "getLocalAddr().getDottedAddr(): " << ostr8.getStr() << endl;
		sprintf(tmpStr1, "%d", LocalAddr.getPort());
		cout << "getLocalAddr().getPort(): " << tmpStr1 << endl;
		cout << endl;
		cout << "Socket.getLocalHost(): " << ostr9.getStr() << endl;
		sprintf(tmpStr1, "%d", Socket.getLocalPort());
		cout << "Socket.getLocalPort(): " << tmpStr1 << endl;

		cout << endl << "prep for accept" << endl << endl;

		if(!Socket.listen())
		{
			char err[80];
                        rtl::OUString   err_str;
                        Socket.getError(err_str); rtl::OString ostr(err_str.getStr(), err_str.getLength(), RTL_TEXTENCODING_UTF8);
                        strcpy (err, ostr.getStr());
			cout << "listen failed with error: " << err << endl;
			return sal_False;
		}

		TimeValue Tv = { 5, 0 };

		if(Socket.isRecvReady(&Tv)) 
		{
			cout << "Ready" << endl;
		} 
		else 
		{
			cout << "still not ready" << endl;
			char err[80];
                        rtl::OUString   err_str;
                        Socket.getError(err_str); rtl::OString ostr(err_str.getStr(), err_str.getLength(), RTL_TEXTENCODING_UTF8);
                        strcpy (err, ostr.getStr());
			cout << ": " << err << endl;
		}


		NAMESPACE_VOS(OInetSocketAddr) PeerAddr;
		NAMESPACE_VOS(OStreamSocket) Connection;
		
		
		if(Socket.acceptConnection(Connection, PeerAddr) != OSocket::TResult_Ok)
		{
			char err[80];
                        rtl::OUString   err_str;
                        Socket.getError(err_str); rtl::OString ostr(err_str.getStr(), err_str.getLength(), RTL_TEXTENCODING_UTF8);
                        strcpy (err, ostr.getStr());
			cout << "accept failed with error: " << err << endl;
			return sal_False;
		}
		rtl::OUString hostName5, dottedAd5;
                PeerAddr.getHostname(hostName5);
                PeerAddr.getDottedAddr(dottedAd5);
		cout << "Connected to: " << endl;
		sprintf(tmpStr1, "%d", PeerAddr.getPort());
                rtl::OString ostr10(hostName5.getStr(), hostName5.getLength(), RTL_TEXTENCODING_UTF8);
                rtl::OString ostr11(dottedAd5.getStr(), dottedAd5.getLength(), RTL_TEXTENCODING_UTF8);
		cout << "PeerAddr.getHostName(): " << ostr10.getStr() << endl 
			 << "PeerAddr.getDottedAddr(): " << ostr11.getStr() << endl
			 << "PeerAddr.getPort(): " << tmpStr1 << endl;
		
//		cout << endl <<  "Receiver got valid connection. Reading: " << flush;
		cout << endl <<  "Receiver got valid connection. Reading: " << endl;

		char Buffer[80];
		memset(Buffer, 0, sizeof(Buffer));
		if(Connection.recv(Buffer, 5) != 5)
		{
			char err[80];
                        rtl::OUString   err_str;
                        Socket.getError(err_str); rtl::OString ostr(err_str.getStr(), err_str.getLength(), RTL_TEXTENCODING_UTF8);
                        strcpy (err, ostr.getStr());
			cout << "recv failed with error: " << err << endl;
			return sal_False;
		}
		
		cout << Buffer << endl;

		cout << endl << "Receiver closes connection." << endl;

		if(!Connection.shutdown()) 
		{
			char err[80];
                        rtl::OUString   err_str;
                        Socket.getError(err_str); rtl::OString ostr(err_str.getStr(), err_str.getLength(), RTL_TEXTENCODING_UTF8);
                        strcpy (err, ostr.getStr());
			cout << "shutdown failed with error: " << err << endl;
			return sal_False;
		}

		Connection.close();
		cout << "Connection closed" << endl;


		cout << "Closing acceptor" << endl;
		Socket.close();
		cout << "Receiver done" << endl;

		return sal_False;
	}
};


class OQuietSender : public NAMESPACE_VOS(OExecutable)
{
public:
	sal_Bool execute()
	{
		NAMESPACE_VOS(OConnectorSocket) Socket;
		NAMESPACE_VOS(OInetSocketAddr) Addr; 

		if(!Socket.bind(Addr))
		{
			char err[80];
                        rtl::OUString   err_str;
                        Socket.getError(err_str); rtl::OString ostr(err_str.getStr(), err_str.getLength(), RTL_TEXTENCODING_UTF8);
                        strcpy (err, ostr.getStr());
			cout << "binding sender failed with error: " << err << endl;
			return sal_False;
		}
		cout << "connecting. " << endl;

		rtl::OUString   local_str3("localhost", 9, RTL_TEXTENCODING_UTF8);
		NAMESPACE_VOS(OInetSocketAddr) AddrTarget(local_str3, PORT);

		if(Socket.connect(AddrTarget) != OSocket::TResult_Ok) 
		{
			char err[80];
                        rtl::OUString   err_str;
                        Socket.getError(err_str); rtl::OString ostr(err_str.getStr(), err_str.getLength(), RTL_TEXTENCODING_UTF8);
                        strcpy (err, ostr.getStr());
			cout << "connect failed with error: " << err << endl;
			return sal_False;
		}

		if(Socket.send("Hallo", 5) != 5)
		{
			char err[80];
                        rtl::OUString   err_str;
                        Socket.getError(err_str); rtl::OString ostr(err_str.getStr(), err_str.getLength(), RTL_TEXTENCODING_UTF8);
                        strcpy (err, ostr.getStr());
			cout << "send failed with error: " << err << endl;
			return sal_False;
		}

		if(!Socket.shutdown()) 
		{
			char err[80];
                        rtl::OUString   err_str;
                        Socket.getError(err_str); rtl::OString ostr(err_str.getStr(), err_str.getLength(), RTL_TEXTENCODING_UTF8);
                        strcpy (err, ostr.getStr());
			cout << "shutdown failed with error: " << err << endl;
			return sal_False;
		}

		return sal_False;
	}
};

class OAbortedSender : public NAMESPACE_VOS(OExecutable)
{
public:

	NAMESPACE_VOS(OConnectorSocket) m_Socket;

	sal_Bool execute()
	{
		NAMESPACE_VOS(OInetSocketAddr) Addr; 
		if(!m_Socket.bind(Addr))
		{
			char err[80];
                        rtl::OUString   err_str;
                        m_Socket.getError(err_str); rtl::OString ostr(err_str.getStr(), err_str.getLength(), RTL_TEXTENCODING_UTF8);
                        strcpy (err, ostr.getStr());
			cout << "binding sender failed with error: " << err << endl;
			return sal_False;
		}
		cout << "connecting: waiting to be aborted " << endl;

		rtl::OUString   local_str4("141.99.128.50", 13, RTL_TEXTENCODING_UTF8);
		NAMESPACE_VOS(OInetSocketAddr) AddrTarget(local_str4, PORT);

		OSocket::TResult Result= m_Socket.connect(AddrTarget);
		switch(Result)
		{
		case OSocket::TResult_Ok:
			cout << "connected: which shouldn't have happened here!" << endl;
			break;
		case OSocket::TResult_TimedOut:
			cout << "connect timed-out: which shouldn't have happened here!" << endl;
			break;
		case OSocket::TResult_Interrupted:
			cout << "connect interrupted, like expected." << endl;
			return sal_False;
		case OSocket::TResult_Error:
			char err[128];
                        rtl::OUString   err_str;
                        m_Socket.getError(err_str); rtl::OString ostr(err_str.getStr(), err_str.getLength(), RTL_TEXTENCODING_UTF8);
                        strcpy (err, ostr.getStr());
			cout << "connect failed with error: " << err << endl;
			cout << "this wasn't expected, but is not entirely false." << endl;
			return sal_False;
		}

		if(!m_Socket.shutdown()) 
		{
			char err[80];
                        rtl::OUString   err_str;
                        m_Socket.getError(err_str); rtl::OString ostr(err_str.getStr(), err_str.getLength(), RTL_TEXTENCODING_UTF8);
                        strcpy (err, ostr.getStr());
			cout << "shutdown failed with error: " << err << endl;
			return sal_False;
		}

		return sal_False;
	}
};

class OQuietReceiver : public NAMESPACE_VOS(OExecutable)
{
public:
	sal_Bool execute()
	{

		cout << "creating receiver-socket" << endl;
		NAMESPACE_VOS(OAcceptorSocket) Socket;
		rtl::OUString   local_str5("localhost", 9, RTL_TEXTENCODING_UTF8);
		NAMESPACE_VOS(OInetSocketAddr) Addr(local_str5, PORT);

		Socket.setReuseAddr(1);

		if(!Socket.bind(Addr))
		{
			char err[80];
                        rtl::OUString   err_str;
                        Socket.getError(err_str); rtl::OString ostr(err_str.getStr(), err_str.getLength(), RTL_TEXTENCODING_UTF8);
                        strcpy (err, ostr.getStr());
			cout << "binding receiver failed with error: " << err << endl;
			return sal_False;
		}

		cout << endl << "Is ready to accept?" << endl << endl;

		if(!Socket.listen())
		{
			char err[80];
                        rtl::OUString   err_str;
                        Socket.getError(err_str); rtl::OString ostr(err_str.getStr(), err_str.getLength(), RTL_TEXTENCODING_UTF8);
                        strcpy (err, ostr.getStr());
			cout << "listen failed with error: " << err << endl;
			return sal_False;
		}

		TimeValue Tv = { 5, 0 };

		if(Socket.isRecvReady(&Tv)) 
		{
			cout << "ready" << endl;
		} else {
			cout << "still not ready" << endl;
		}


		NAMESPACE_VOS(OInetSocketAddr) PeerAddr;
		NAMESPACE_VOS(OStreamSocket) Connection;
		

		if(Socket.acceptConnection(Connection, PeerAddr) != OSocket::TResult_Ok)
		{
			char err[80];
                        rtl::OUString   err_str;
                        Socket.getError(err_str); rtl::OString ostr(err_str.getStr(), err_str.getLength(), RTL_TEXTENCODING_UTF8);
                        strcpy (err, ostr.getStr());
			cout << "accept failed with error: " << err << endl;
			return sal_False;
		}
		rtl::OUString	dottedAd6;
		PeerAddr.getDottedAddr(dottedAd6);
		char tmpStr1[16]; sprintf(tmpStr1, "%d", PeerAddr.getPort());
                rtl::OString ostr12(dottedAd6.getStr(), dottedAd6.getLength(), RTL_TEXTENCODING_UTF8);
		cout << "Accepted: " << ostr12.getStr() << " Port: " << tmpStr1 << endl;
		
		char Buffer[80];
		memset(Buffer, 0, sizeof(Buffer));
		if(Connection.recv(Buffer, 5) != 5)
		{
			char err[80];
                        rtl::OUString   err_str;
                        Socket.getError(err_str); rtl::OString ostr(err_str.getStr(), err_str.getLength(), RTL_TEXTENCODING_UTF8);
                        strcpy (err, ostr.getStr());
			cout << "recv failed with error: " << err << endl;
			return sal_False;
		}
		
		cout << Buffer << endl;

		cout << endl << "Receiver closes connection." << endl;

		if(!Connection.shutdown()) 
		{
			char err[80];
                        rtl::OUString   err_str;
                        Socket.getError(err_str); rtl::OString ostr(err_str.getStr(), err_str.getLength(), RTL_TEXTENCODING_UTF8);
                        strcpy (err, ostr.getStr());
			cout << "shutdown failed with error: " << err << endl;
			return sal_False;
		}

		Connection.close();
		cout << "Connection closed" << endl;


		cout << "Closing acceptor" << endl;
		Socket.close();
		cout << "Receiver done" << endl;

		return sal_False;
	}
};

#ifdef UNX
int main()
#else
int _cdecl main()
#endif
{
	cout << "Test socket: " << endl;

	cout << "Some test on InetSocketAddr:" << endl;

	rtl::OUString   local_str6("localhost", 9, RTL_TEXTENCODING_UTF8);
	NAMESPACE_VOS(OInetSocketAddr) Addr(local_str6, PORT);

	// getFamily()
	if(Addr.getFamily() != osl_Socket_FamilyInet)
	{
		cout << "Family of OInetSocketAddr is not Socket_FamilyInet as expected!" << endl;
	}
	
	// getServicePort()
	int	portNum = NAMESPACE_VOS(OInetSocketAddr)::getServicePort(::rtl::OUString::createFromAscii("ftp"), ::rtl::OUString::createFromAscii("tcp"));
	char	tmpStr[16];
	sprintf (tmpStr, "%d", portNum);
	cout << "Service-Port for FTP (21): " << tmpStr << endl;

	// getPort()/setPort
	int Port= 21;
	VOS_VERIFY(Addr.setPort(Port));
	if(Addr.getPort() != Port) 
	{
		cout << "OInetSocketAddr: setPort()/getPort() difference!" << endl;
	}

	// Socket: getType()
	NAMESPACE_VOS(OSocket) Socket(OSocket::TType_Stream);
	if(Socket.getType() != OSocket::TType_Stream) 
	{
		cout << "Expected socket to be of type sock_stream!" << endl;
	}

	cout << endl;

	// create sender/receiver-threads
	ORef<NAMESPACE_VOS(OThreadingServer)> server(new NAMESPACE_VOS(OThreadingServer));

	printf("--------------------------------------------------------------\n");

	server->add(new OReceiver);
	server->add(new OSender);

	server->complete();


	printf("--------------------------------------------------------------\n");

	// testing timeout (read)
	cout << endl << "timeout-test 1: after 4 seconds receiver should say 'ready' and proceed connecting." << endl;
	server->add(new OQuietReceiver);
	NAMESPACE_VOS(OThread)::wait(TTimeValue(3000));
	server->add(new OQuietSender);

	server->complete();

	printf("--------------------------------------------------------------\n");

	cout << endl << "timeout-test 2: after 5 seconds receiver should say 'still not ready'." << endl;
	server->add(new OQuietReceiver);
	NAMESPACE_VOS(OThread)::wait(TTimeValue(6000));
	server->add(new OQuietSender);

	server->complete();

	cout << "------------------------------------------------------------------" << endl;

	ORef<OAbortedSender> sender(new OAbortedSender);

	server->add(sender.getBodyPtr());
	NAMESPACE_VOS(OThread)::wait(TTimeValue(1000));
	cout << "closing connecting socket from another thread." << endl;
	cout << "Be patient, it may take the system some time to notice an invalid socket.";
	cout << endl;

	sender->m_Socket.close();

	server->complete();

	return 0;
}



