/*************************************************************************
 *
 *  $RCSfile: fields.hxx,v $
 *
 *  $Revision: 1.23 $
 *
 *  last change: $Author: dv $ $Date: 2001/11/30 12:44:27 $
 *
 *  The Contents of this file are made available subject to the terms of
 *  either of the following licenses
 *
 *         - GNU Lesser General Public License Version 2.1
 *         - Sun Industry Standards Source License Version 1.1
 *
 *  Sun Microsystems Inc., October, 2000
 *
 *  GNU Lesser General Public License Version 2.1
 *  =============================================
 *  Copyright 2000 by Sun Microsystems, Inc.
 *  901 San Antonio Road, Palo Alto, CA 94303, USA
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License version 2.1, as published by the Free Software Foundation.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *  MA  02111-1307  USA
 *
 *
 *  Sun Industry Standards Source License Version 1.1
 *  =================================================
 *  The contents of this file are subject to the Sun Industry Standards
 *  Source License Version 1.1 (the "License"); You may not use this file
 *  except in compliance with the License. You may obtain a copy of the
 *  License at http://www.openoffice.org/license.html.
 *
 *  Software provided under this License is provided on an "AS IS" basis,
 *  WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING,
 *  WITHOUT LIMITATION, WARRANTIES THAT THE SOFTWARE IS FREE OF DEFECTS,
 *  MERCHANTABLE, FIT FOR A PARTICULAR PURPOSE, OR NON-INFRINGING.
 *  See the License for the specific provisions governing your rights and
 *  obligations concerning the Software.
 *
 *  The Initial Developer of the Original Code is: Sun Microsystems, Inc.
 *
 *  Copyright: 2000 by Sun Microsystems, Inc.
 *
 *  All Rights Reserved.
 *
 *  Contributor(s): _______________________________________
 *
 *
 ************************************************************************/

#ifndef __SETUP_FIELDS_HXX
#define __SETUP_FIELDS_HXX

extern char const VALUE_APPSERVER[];
extern char const VALUE_ACTIVEX[];
extern char const VALUE_ARCHIVE[];
extern char const VALUE_AFTERWARDS[];
extern char const VALUE_BEFORE[];
extern char const VALUE_EXECINST_BEFORE[];
extern char const VALUE_EXECDEINST_BEFORE[];
extern char const VALUE_EXECINST_AFTER[];
extern char const VALUE_EXECDEINST_AFTER[];
extern char const VALUE_BIND_DLL[];
extern char const VALUE_CD[];
extern char const VALUE_CHECK_TIMESTAMP[];
extern char const VALUE_CHECK_VERSION[];
extern char const VALUE_COMP_BY_SETUP[];
extern char const VALUE_CREATE[];
extern char const VALUE_DISKETTE[];
extern char const VALUE_DELETE_ALL[];
extern char const VALUE_DELETE_ONLY[];
extern char const VALUE_DONT_DELETE[];
extern char const VALUE_DONT_INSTALL[];
extern char const VALUE_DONT_OVERWRITE[];
extern char const VALUE_DONT_RECOVER[];
extern char const VALUE_DONT_SELECT_BY_USER[];
extern char const VALUE_EXEC_SCRIPT[];
extern char const VALUE_EXEC_APP[];
extern char const VALUE_EXEC_SHELL[];
extern char const VALUE_FONT[];
extern char const VALUE_FONT_WARN_IF_EXISTS[];
extern char const VALUE_INSTALL[];
extern char const VALUE_INSTALL_INFO[];
extern char const VALUE_PRE_SELECT_MODULES[];
extern char const VALUE_LANGUAGE_SELECT_MODULES[];
extern char const VALUE_HARDDISK[];
extern char const VALUE_HIDESTANDARD[];
extern char const VALUE_HEX_VALUE[];
extern char const VALUE_YES[];
extern char const VALUE_YES_IF_SINIX_MIPS[];
extern char const VALUE_YES_IF_SOLARIS_SPARC[];
extern char const VALUE_YES_IF_SOLARIS_X86[];
extern char const VALUE_YES_IF_HPUX_HP9000[];
extern char const VALUE_YES_IF_AIX_RS6000[];
extern char const VALUE_YES_IF_LINUX_X86[];
extern char const VALUE_YES_IF_TRU64_ALPHA[];
extern char const VALUE_KEEP_OLD_VERSION[];
extern char const VALUE_NETWORK[];
extern char const VALUE_NO[];
extern char const VALUE_NULL[];
extern char const VALUE_OLD_VERSION_REQUIRED[];
extern char const VALUE_OS2_MODIFY_PATH[];
extern char const VALUE_OVERWRITE_ONLY[];
extern char const VALUE_OVERWRITE[];
extern char const VALUE_PACKED[];
extern char const VALUE_README[];
extern char const VALUE_REGISTRATION_REQUIRED[];
extern char const VALUE_SD_HELP[];
extern char const VALUE_SETUP[];
extern char const VALUE_SETUPZIP[];
extern char const VALUE_STANDALONE[];
extern char const VALUE_UNINSTALL[];
extern char const VALUE_UNIX_SOFTLINK[];
extern char const VALUE_UNPACKED[];
extern char const VALUE_WIN_REQUIRES_SHARE[];
extern char const VALUE_WORKSTATION[];
extern char const VALUE_WORKSTATION_ONLY[];
extern char const VALUE_AGENTLOADER[];
extern char const VALUE_PROCESSGUARD[];
extern char const VALUE_INI_MIGRATION[];
extern char const VALUE_MIGRATION[];
extern char const VALUE_HIDDENROOT[];
extern char const VALUE_HIDDENROOT_RECURSIVE[];
extern char const VALUE_SUBSTITUTE[];
extern char const VALUE_SERVER_INI[];
extern char const VALUE_REBOOT[];
extern char const VALUE_RELATIVE[];
extern char const VALUE_REPAIRABLE[];
extern char const VALUE_UNOCOMPONENT[];
extern char const VALUE_DOCLANG[];
extern char const VALUE_STRING[];
extern char const VALUE_NUMERIC[];
extern char const VALUE_BOOLEAN[];
extern char const VALUE_STRINGLIST[];
extern char const VALUE_BINARY[];
extern char const VALUE_WEB_ONLY[];
extern char const VALUE_NOWEB[];
extern char const VALUE_ONLYCUSTOM[];
extern char const VALUE_NEEDCONFIG_SERVER[];
extern char const VALUE_RESPONSEFILEWIZARD[];
extern char const VALUE_NOTIMESTAMP[];
extern char const VALUE_NOUPDATE[];
extern char const VALUE_NOWARNIFNOTEXISTS[];
extern char const VALUE_EXECMODIFY_BEFORE[];
extern char const VALUE_EXECMODIFY_AFTER[];
extern char const VALUE_KEEP_ALIVE[];
extern char const VALUE_PATCH_SO_NAME[];
extern char const VALUE_FORCE_REPAIR[];

extern char const * ALL_VALUES[];

extern char const PROPERTY_ARCHIVE[];
extern char const PROPERTY_ARCHIVEFILES[];
extern char const PROPERTY_ARCHIVESIZE[];
extern char const PROPERTY_CARRIER[];
extern char const PROPERTY_CLIENTROOTPATH[];
extern char const PROPERTY_CLIENTPOSTFIX[];
extern char const PROPERTY_CLIENTLIST[];
extern char const PROPERTY_CODE[];
extern char const PROPERTY_COMPANYNAME[];
extern char const PROPERTY_COPY[];
extern char const PROPERTY_CONTAINS[]; // Feld der Inst-DB
extern char const PROPERTY_CRC[];
extern char const PROPERTY_CUSTOMS[];
extern char const PROPERTY_DATE[];
extern char const PROPERTY_DEFAULT[];
extern char const PROPERTY_DEFAULTDESTPATH[];
extern char const PROPERTY_DESTPATH[];
extern char const PROPERTY_DELETE_KEY[];
extern char const PROPERTY_DESCRIPTION[];
extern char const PROPERTY_DIR[];
extern char const PROPERTY_DIRS[];
extern char const PROPERTY_DISKNO[];
extern char const PROPERTY_DLL[];
extern char const PROPERTY_DOSNAME[];
extern char const PROPERTY_EXECTYPE[];
extern char const PROPERTY_EXECCOMMAND[];
extern char const PROPERTY_FADESPEED[];
extern char const PROPERTY_FADETYPE[];
extern char const PROPERTY_FLATLOADERZIP[];
extern char const PROPERTY_FOLLOWAPP[];
extern char const PROPERTY_FOLLOW_EXECTYPE[];
extern char const PROPERTY_FOLLOW_EXECCOMMAND[];
extern char const PROPERTY_FILEID[];
extern char const PROPERTY_FILENAME[];
extern char const PROPERTY_FILES[];
extern char const PROPERTY_FLAGS[];
extern char const PROPERTY_FOLDERID[];
extern char const PROPERTY_FOLDERITEMS[];
extern char const PROPERTY_FONTNAME[];
extern char const PROPERTY_FORCEOVERWRITE[];
extern char const PROPERTY_FROMKEY[];
extern char const PROPERTY_TEXTHEIGHT[];
extern char const PROPERTY_HOSTNAME[];
extern char const PROPERTY_ICON[];
extern char const PROPERTY_ICONDIR[];
extern char const PROPERTY_ID[];
extern char const PROPERTY_INSTALLED[];		 // Feld der Inst-DB
extern char const PROPERTY_INSTALLFROMNET[]; // Feld der Inst-DB
extern char const PROPERTY_ITEMCOUNT[];		 // Feld der Inst-DB
extern char const PROPERTY_KEY[];
extern char const PROPERTY_LONGVALUE[];
extern char const PROPERTY_SEQ_VALUE[];
extern char const PROPERTY_MAC_CREATOR[];
extern char const PROPERTY_MAXSELECT[];
extern char const PROPERTY_MINIMAL[];
extern char const PROPERTY_MODE[];
extern char const PROPERTY_MODULEID[];
extern char const PROPERTY_MODULEIDS[];
extern char const PROPERTY_MODULELISTS[];
extern char const PROPERTY_NAME[];
extern char const PROPERTY_NETDIR[];
extern char const PROPERTY_ONDESELECT[];
extern char const PROPERTY_ONSELECT[];
extern char const PROPERTY_OPENSUBST[];
extern char const PROPERTY_OUPDATEDONE[];
extern char const PROPERTY_ORDER[];
extern char const PROPERTY_OS2_CREATORID[];
extern char const PROPERTY_OS2_CLASSID[];
extern char const PROPERTY_OS2_CLOSEICON[];
extern char const PROPERTY_OS2_EAFILE[];
extern char const PROPERTY_OS2_FILTERS[];
extern char const PROPERTY_OS2_ID[];
extern char const PROPERTY_OS2_OPENICON[];
extern char const PROPERTY_OS2_REFERENCEID[];
extern char const PROPERTY_OVERWRITEMSG[];
extern char const PROPERTY_PACKEDNAME[];
extern char const PROPERTY_PARAMETER[];
extern char const PROPERTY_PARENTID[];
extern char const PROPERTY_PART[];
extern char const PROPERTY_PARTS[];
extern char const PROPERTY_PARTOF[];
extern char const PROPERTY_PRODUCTNAME[];
extern char const PROPERTY_PRODUCTVERSION[];
extern char const PROPERTY_INTERNALPRODUCTVERSION[];
extern char const PROPERTY_BMPPOSX[];
extern char const PROPERTY_BMPPOSY[];
extern char const PROPERTY_PROCEDURES[];
extern char const PROPERTY_PROCNAME[];
extern char const PROPERTY_PROFILEID[];
extern char const PROPERTY_REGISTRYID[];
extern char const PROPERTY_SECTION[];
extern char const PROPERTY_SCRIPTVERSION[];
extern char const PROPERTY_SIZE[];
extern char const PROPERTY_DOWNLOAD_SIZE[];
extern char const PROPERTY_SOURCEPATH[];
extern char const PROPERTY_SPECIAL_VERSION[];
extern char const PROPERTY_SUBKEY[];
extern char const PROPERTY_TEXT[];
extern char const PROPERTY_TIME[];
extern char const PROPERTY_TOKEY[];
extern char const PROPERTY_TRANSMITTER[];
extern char const PROPERTY_TYPE[];
extern char const PROPERTY_VALUE[];
extern char const PROPERTY_WORKSTATIONVALUE[];
extern char const PROPERTY_UIPROC[];
extern char const PROPERTY_UNIX_RIGHTS[];
extern char const PROPERTY_USERNAME[];
extern char const PROPERTY_SUITENAME[];
extern char const PROPERTY_SCPUNIX_RIGHTS[];
extern char const PROPERTY_UPDATENAME[];
extern char const PROPERTY_UPDATESIZE[];
extern char const PROPERTY_UPDATEFOR[];
extern char const PROPERTY_UPGRADEFOR[];
extern char const PROPERTY_TEXTWIDTH[];
extern char const PROPERTY_FONTSIZE[];
extern char const PROPERTY_BITMAP[];
extern char const PROPERTY_VENDORBITMAP[];
extern char const PROPERTY_VENDORNAME[];
extern char const PROPERTY_VENDORVERSION[];
extern char const PROPERTY_WAVE[];
extern char const PROPERTY_LANGUAGES[];
extern char const PROPERTY_DEFLANGUAGE[];
extern char const PROPERTY_INST_LANGUAGES[];
extern char const PROPERTY_PATH[];
extern char const PROPERTY_TEMPLATEFILE[];
extern char const VALUE_RECURSIVE[];

#endif // __SETUP_FIELDS_HXX


