/*************************************************************************
 *
 *  $RCSfile: agentdlg.cxx,v $
 *
 *  $Revision: 1.4 $
 *
 *  last change: $Author: ok $ $Date: 2001/05/29 15:35:02 $
 *
 *  The Contents of this file are made available subject to the terms of
 *  either of the following licenses
 *
 *         - GNU Lesser General Public License Version 2.1
 *         - Sun Industry Standards Source License Version 1.1
 *
 *  Sun Microsystems Inc., October, 2000
 *
 *  GNU Lesser General Public License Version 2.1
 *  =============================================
 *  Copyright 2000 by Sun Microsystems, Inc.
 *  901 San Antonio Road, Palo Alto, CA 94303, USA
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License version 2.1, as published by the Free Software Foundation.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *  MA  02111-1307  USA
 *
 *
 *  Sun Industry Standards Source License Version 1.1
 *  =================================================
 *  The contents of this file are subject to the Sun Industry Standards
 *  Source License Version 1.1 (the "License"); You may not use this file
 *  except in compliance with the License. You may obtain a copy of the
 *  License at http://www.openoffice.org/license.html.
 *
 *  Software provided under this License is provided on an "AS IS" basis,
 *  WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING,
 *  WITHOUT LIMITATION, WARRANTIES THAT THE SOFTWARE IS FREE OF DEFECTS,
 *  MERCHANTABLE, FIT FOR A PARTICULAR PURPOSE, OR NON-INFRINGING.
 *  See the License for the specific provisions governing your rights and
 *  obligations concerning the Software.
 *
 *  The Initial Developer of the Original Code is: Sun Microsystems, Inc.
 *
 *  Copyright: 2000 by Sun Microsystems, Inc.
 *
 *  All Rights Reserved.
 *
 *  Contributor(s): _______________________________________
 *
 *
 ************************************************************************/

#ifndef _DEBUG_HXX //autogen
#include <tools/debug.hxx>
#endif

#ifndef _SV_GRAPH_HXX //autogen
#include <vcl/graph.hxx>
#endif

#include "agentdlg.hxx"
#include "agentdlg.hrc"
#if defined(TRU64) && !defined(long)
#define	long	int
#endif

#define DEF_BUTTON_SPACE	20

////////////////////////////////////////////////////////////////////////////////
// Model
//

Model::Model( USHORT nId, CreateFnc pCreateFnc )
{
	m_nId = nId;
	m_nProperty = PROP_NOTSET;
	m_pCreateFnc = pCreateFnc;
	m_bIsSmallPage = SMALL_PAGE;
}

Model::~Model()
{
	for( USHORT i = 0; i < m_aRules.Count(); ++i )
		delete m_aRules.GetObject(i);
}

Rule* Model::GetRuleFor( USHORT nRetVal )
{
	for( USHORT i = 0; i < m_aRules.Count(); ++i )
		if( m_aRules.GetObject(i)->m_nRetVal == nRetVal )
			return m_aRules.GetObject(i);
	return NULL;
}

void Model::InsertRule( USHORT nRetVal, USHORT nNextResId )
{
	Rule* pRule = GetRuleFor(nRetVal);
	if( pRule )
	{
		m_aRules.Remove(pRule);
		delete pRule;
	}

	if( !nNextResId )
		return ;

	pRule			 = new Rule;
	pRule->m_nRetVal = nRetVal;
	pRule->m_nResId	 = nNextResId;

	m_aRules.Insert( pRule, m_aRules.Count() );
}

USHORT Model::GetNext( USHORT nRetVal )
{
	Rule* pRule = GetRuleFor( nRetVal );

	if( !pRule && m_aRules.Count() >= 1 )
		pRule = m_aRules.GetObject(1);

	return pRule->m_nResId;
}

////////////////////////////////////////////////////////////////////////////////
// SvAgentDlg
//

SvAgentDlg::SvAgentDlg( Window* pParent, ResMgr* pMgr, USHORT nLogoResId, BOOL bAnim ) :
	ModelessDialog	( pParent, ResId(RC_AGENTDLG, pMgr) ),
	m_aFLDelim		( this, ResId(RESID_DLG_AGENT_FL_DELIM, pMgr) ),
	m_aPBCancel		( this, ResId(RESID_DLG_AGENT_PB_CANCEL, pMgr) ),
	m_aPBNext		( this, ResId(RESID_DLG_AGENT_PB_NEXT, pMgr) ),
	m_aPBBack		( this, ResId(RESID_DLG_AGENT_PB_BACK, pMgr) ),
	m_aPBHelp		( this, ResId(RESID_DLG_AGENT_PB_HELP, pMgr) ),
	m_aHelpEdit		( this, ResId(RESID_DLG_AGENT_README, pMgr) ),
	m_aStrNext		( ResId(RESID_DLG_AGENT_STR_NEXT, pMgr) ),
	m_aStrBack		( ResId(RESID_DLG_AGENT_STR_BACK, pMgr) ),
	m_aStrFinal		( ResId(RESID_DLG_AGENT_STR_FINAL, pMgr) ),
	m_aStrInstall	( ResId(RESID_DLG_AGENT_STR_INSTALL, pMgr) ),
	m_aStrUninstall	( ResId(RESID_DLG_AGENT_STR_UNINSTALL, pMgr) ),
	m_aStrRepair	( ResId(RESID_DLG_AGENT_STR_REPAIR, pMgr) ),
	m_aStrModify	( ResId(RESID_DLG_AGENT_STR_MODIFY, pMgr) ),
	m_pFBLogo		( NULL ),
	pAnimCD			( NULL ),
	bAnimCD			( bAnim )
{
	FreeResource();

	m_pFBLogo = new FixedBitmap( this, ResId(nLogoResId, pMgr) );
	m_pFBLogo->Show();

	pResMgr			= pMgr;
	m_nStartId		= 0;
	m_nButtonState	= 0;
	m_pActivPage	= NULL;
	m_pActivModel	= NULL;
	m_pModel		= new ModelList;
	m_pUserPath		= new UserList;
	bInEndDialog	= FALSE;
	bInPerformNext	= FALSE;
	bInHelp			= FALSE;
	bHelpAvailable	= FALSE;

	m_aPBHelp.SetClickHdl( LINK(this, SvAgentDlg, ClickHdl) );
	m_aPBHelp.Hide();
	m_aHelpEdit.Hide();

	m_aPBNext.SetClickHdl( LINK(this, SvAgentDlg, ClickHdl) );
	m_aPBBack.SetClickHdl( LINK(this, SvAgentDlg, ClickHdl) );
	m_aPBCancel.SetClickHdl( LINK(this, SvAgentDlg, ClickHdl) );

	m_aDefBackPos = m_aPBBack.GetPosPixel();
	m_aDefNextPos = m_aPBNext.GetPosPixel();
	m_aDefBackSz  = m_aPBBack.GetSizePixel();
	m_aDefNextSz  = m_aPBNext.GetSizePixel();

	Point aWinPos( LogicToPixel(Point(90, 7), MapMode(MAP_APPFONT)) );
	Size aWinSz( LogicToPixel(Size(205, 160), MapMode(MAP_APPFONT)) );
	Size aBmpSz( m_pFBLogo->GetSizePixel() );

	if( aWinPos.X() < aBmpSz.Width() + 5 )
		m_pFBLogo->SetSizePixel( Size(aWinPos.X() - 14, aBmpSz.Height() ));
	aBmpSz = m_pFBLogo->GetSizePixel();
	if( aWinSz.Height() < aBmpSz.Height() )
		m_pFBLogo->SetSizePixel( Size(aBmpSz.Width(), aWinSz.Height() ));

	Point aActBmpPos( m_pFBLogo->GetPosPixel() );
	Size aBmpArea( aWinPos.X() - aActBmpPos.X(), m_aFLDelim.GetPosPixel().Y() - aActBmpPos.Y());
	aBmpSz = m_pFBLogo->GetSizePixel();
	if( aBmpArea.Width() > aBmpSz.Width() )
		aActBmpPos.X() += ((aBmpArea.Width() - aBmpSz.Width()) / 2);
	if( aBmpArea.Height() > aBmpSz.Height() )
		aActBmpPos.Y() += ((aBmpArea.Height() - aBmpSz.Height()) / 2);
	m_pFBLogo->SetPosPixel(aActBmpPos);
}

SvAgentDlg::~SvAgentDlg()
{
	if( m_pActivPage )
		delete m_pActivPage;

	delete m_pModel;
	delete m_pUserPath;
	delete m_pFBLogo;
}

Model* SvAgentDlg::GetModel( USHORT nResId )
{
	Model* pReturn;
	for( USHORT i = 0; i < m_pModel->Count(); ++i )
		if( (pReturn = m_pModel->GetObject(i)) &&
			pReturn->GetId() == nResId )
			return pReturn;
	return NULL;
}

void SvAgentDlg::SetButtonState( USHORT nNewState )
{
	m_nButtonState = nNewState;
	UpdateButton();

	if( m_pActivModel->IsFinal() )
		m_aPBNext.SetText( m_aStrFinal );
	else
		m_aPBNext.SetText( m_aStrNext );
}

IMPL_LINK(SvAgentDlg, StartAnimHdl, void*, pEmpty)
{
	if( !bAnimCD )
		return 1;

	SvMemoryStream	aStrm;
	BinaryResLoader aLoader( aStrm, ResId(RESID_DLG_AGENT_ANIMATE_CD, pResMgr) );

	if( pAnimCD )
		delete pAnimCD;

	pAnimCD = new Graphic;
	aStrm.Seek( STREAM_SEEK_TO_BEGIN );

	BOOL bSucc = ImportGIF( aStrm, *pAnimCD, NULL );
	if( bSucc )
		pAnimCD->StartAnimation( m_pFBLogo, Point(3, 3) );

	return 1;
}

void SvAgentDlg::StartAnimCD()
{
	aStartAnimTimer.SetTimeout( 1500 );
	aStartAnimTimer.SetTimeoutHdl( LINK(this, SvAgentDlg, StartAnimHdl) );
	aStartAnimTimer.Start();
}

void SvAgentDlg::StopAnimCD()
{
	if( !bAnimCD )
		return ;
	if( pAnimCD )
	{
		pAnimCD->StopAnimation();
		delete pAnimCD;
		pAnimCD = NULL;
	}
}

void SvAgentDlg::UpdateButton()
{
	// default
	if( m_pActivModel->GetId() == m_nStartId )
	{
		m_aPBBack.Hide();
		m_aPBNext.GrabFocus();
	}
	else
		m_aPBBack.Show();
	m_aPBNext.Show();
	m_aPBCancel.Enable(TRUE);

	// uebersteuern
	if( m_nButtonState & BSTATE_SHOW_NEXT )
		m_aPBNext.Show();
	if( m_nButtonState & BSTATE_HIDE_NEXT )
	{
		m_aPBBack.GrabFocus();
		m_aPBNext.Hide();
	}
	if( m_nButtonState & BSTATE_ENABLE_NEXT )
		m_aPBNext.Enable();
	if( m_nButtonState & BSTATE_DISABLE_NEXT )
	{
		m_aPBBack.GrabFocus();
		m_aPBNext.Enable(FALSE);
	}

	if( m_nButtonState & BSTATE_SHOW_BACK )
		m_aPBBack.Show();
	if( m_nButtonState & BSTATE_HIDE_BACK )
	{
		m_aPBNext.GrabFocus();
		m_aPBBack.Hide();
	}

	if( m_nButtonState & BSTATE_ENABLE_BACK )
		m_aPBBack.Enable();
	if( m_nButtonState & BSTATE_DISABLE_BACK )
	{
		m_aPBNext.GrabFocus();
		m_aPBBack.Enable(FALSE);
	}

	if( m_nButtonState & BSTATE_ENABLE_CANCEL )
		m_aPBCancel.Enable();
	if( m_nButtonState & BSTATE_DISABLE_CANCEL )
	{
		m_aPBNext.GrabFocus();
		m_aPBCancel.Enable(FALSE);
	}
}

void SvAgentDlg::SetPage( USHORT nResId )
{
	BOOL bPrevPageSmall = m_pActivModel? m_pActivModel->IsSmallPage() : FALSE;

	if( m_pActivPage )
	{
		m_pActivPage->Hide();
		if( m_pActivPage->HasChildPathFocus() )
			m_aPBNext.GrabFocus();
		delete m_pActivPage;
	}

	ResId aResId( nResId, pResMgr );

	m_pActivModel = GetModel( nResId );

	m_aPBNext.SetPosSizePixel( m_aDefNextPos, m_aDefNextSz );
	m_aPBBack.SetPosSizePixel( m_aDefBackPos, m_aDefBackSz );

	if( m_pActivModel->IsFinal() )
		m_aPBNext.SetText( m_aStrFinal );
	else
		m_aPBNext.SetText( m_aStrNext );
	m_aPBBack.SetText( m_aStrBack );

	if( m_pActivModel->IsSmallPage() )
	{
		if( !bPrevPageSmall )
		{
			m_pFBLogo->Show();
			StartAnimCD();
		}
	}
	else
	{
		m_pFBLogo->Hide();
		StopAnimCD();
	}

	SetText( UniString::CreateFromAscii("") );

	m_pActivPage 	= m_pActivModel->GetCreateFnc()( this, aResId );
	m_nButtonState	= 0;
	bHelpAvailable	= FALSE;

	UpdateButton();
	// formatiert die Button's
	SetNextText(UniString::CreateFromAscii(""));
	SetBackText(UniString::CreateFromAscii(""));

	m_pActivPage->InitProperty( m_pActivModel->GetProperty() );

	if( m_aInitLink.IsSet() )
		m_aInitLink.Call(m_pActivPage);

	if( !bHelpAvailable )
		m_aPBHelp.Hide();

	if( m_pActivModel->IsFinal() )
		m_aPBNext.GrabFocus();

	m_pActivPage->Show();
}

void SvAgentDlg::StartAgentDlg()
{
	DBG_ASSERT( m_nStartId != 0, "Agent: StartPageId wurde nicht gesetzt!" );
	SetPage( m_nStartId );
}

void SvAgentDlg::AddAllPages()
{
}

void SvAgentDlg::SetHelpAvailable(const String& rHelpText)
{
	if( !m_pActivPage )
		return ;

	bHelpAvailable = TRUE;
	aHelpText = rHelpText;

	m_aPBHelp.Show();
}

void SvAgentDlg::InsertPage( USHORT nResId, CreateFnc pCreateFnc,
							 BOOL bIsSmall, BOOL bStartPage )
{
	Model* pNew = new Model( nResId, pCreateFnc );
	if( bIsSmall )
		pNew->SetSmallPage( SMALL_PAGE );
	else
		pNew->SetSmallPage( LARGE_PAGE );
	m_pModel->Insert( pNew, m_pModel->Count() );

	if( bStartPage )
	{
		DBG_ASSERT(m_nStartId == 0, "Agent: StartPageId wurde schon gesetzt!" );
		m_nStartId = nResId;
	}
}

void SvAgentDlg::RuleIf( USHORT nResId, USHORT nRetVal, USHORT nNextResId )
{
	Model* pModel = GetModel( nResId );
	DBG_ASSERT( pModel, "Agent: TabPageModel nicht gefunden!" );

	pModel->InsertRule( nRetVal, nNextResId );
}

void SvAgentDlg::Rule( USHORT nResId, USHORT nNextResId )
{
	Model* pModel = GetModel( nResId );
	DBG_ASSERT( pModel, "Agent: TabPageModel nicht gefunden!" );
	pModel->InsertRule( USHRT_MAX, nNextResId );
}

void SvAgentDlg::PerformNext()
{
	bInPerformNext = TRUE;
	m_aPBNext.Click();
}

void SvAgentDlg::PerformBack()
{
	bInPerformNext = TRUE;
	m_aPBBack.Click();
}

void SvAgentDlg::SetNextText(const String& rText)
{
	String aBtnText = rText.Len()? rText : m_aPBNext.GetText();

	long nWidth = m_aPBNext.GetTextWidth( aBtnText );
	long nHeight = m_aPBNext.GetTextHeight();

	nWidth += DEF_BUTTON_SPACE;
	if( nWidth > m_aPBNext.GetSizePixel().Width() )
	{
		Point aNewPos( m_aDefNextPos );
		aNewPos.X() -= nWidth - m_aDefNextSz.Width();
		m_aPBNext.SetPosSizePixel(aNewPos, Size(nWidth, m_aPBNext.GetSizePixel().Height()));
	}
	m_aPBNext.SetText( aBtnText );

	if( m_aDefBackPos.X() + m_aPBBack.GetSizePixel().Width() > m_aPBBack.GetPosPixel().X() )
	{
		m_aPBBack.SetPosPixel( Point(m_aPBNext.GetPosPixel().X() - m_aPBBack.GetSizePixel().Width(),
			m_aPBBack.GetPosPixel().Y()) );
	}
}

void SvAgentDlg::SetBackText(const String& rText)
{
	String aBtnText = rText.Len()? rText : m_aPBBack.GetText();

	long nWidth = m_aPBBack.GetTextWidth( aBtnText );
	long nHeight = m_aPBBack.GetTextHeight();

	nWidth += DEF_BUTTON_SPACE;
	if( nWidth > m_aPBBack.GetSizePixel().Width() )
	{
		// immer erst den NextText setzten, dann den BackText,
		// damit hier richtig angeordnet wird
		Point aNewPos( m_aPBNext.GetPosPixel() );
		aNewPos.X() -= nWidth;
		m_aPBBack.SetPosSizePixel(aNewPos, Size(nWidth, m_aPBBack.GetSizePixel().Height()));
	}
	m_aPBBack.SetText( aBtnText );
}

void SvAgentDlg::ShowHelp()
{
	bInHelp = TRUE;

	m_aPBCancel.Hide();
	m_aPBHelp.Hide();
	m_aPBNext.Hide();

	m_aPBBack.Show();
	m_aPBBack.Enable( TRUE );
	m_aPBBack.SetPosPixel( m_aPBHelp.GetPosPixel() );

	m_pActivPage->Hide();
	if( m_pActivModel->IsSmallPage() )
		m_pFBLogo->Hide();

	m_aHelpEdit.SetText( aHelpText );
	m_aHelpEdit.Show();

	m_aPBBack.GrabFocus();
}

void SvAgentDlg::HideHelp()
{
	bInHelp = FALSE;

	m_aPBHelp.Show();
	m_aPBCancel.Show();
	m_aHelpEdit.Hide();

	m_pActivPage->Show();
	if( m_pActivModel->IsSmallPage() )
	{
		m_pFBLogo->Show();
		StartAnimCD();
	}

	m_aPBNext.SetPosSizePixel( m_aDefNextPos, m_aDefNextSz );
	m_aPBBack.SetPosSizePixel( m_aDefBackPos, m_aDefBackSz );

	UpdateButton();
}

IMPL_LINK(SvAgentDlg, ClickHdl, Control*, pCtrl)
{
	if( pCtrl == &m_aPBHelp )
	{
		ShowHelp();
		return 0;
	}
	else
	if( pCtrl == &m_aPBBack && bInHelp )
	{
		HideHelp();
		return 0;
	}

	if( !bInPerformNext &&
		((m_nButtonState & BSTATE_HIDE_NEXT ||
		 m_nButtonState & BSTATE_DISABLE_NEXT) &&
		(m_nButtonState & BSTATE_HIDE_BACK ||
		 m_nButtonState & BSTATE_DISABLE_BACK) &&
		 m_nButtonState & BSTATE_DISABLE_CANCEL) )
		 return 0;
	bInPerformNext = FALSE;

	if( bInEndDialog )
		return 1;

	if( pCtrl == &m_aPBNext )
	{
		if( m_pActivModel->IsFinal() )
		{
			if( m_pActivPage->AllowNext() )
			{
				m_pActivPage->NotifyNext();
				m_pActivPage->GetReturnVal();
				m_pActivPage->GetProperty();
				bInEndDialog = TRUE;
				EndAgentDlg(TRUE);
			}
			return 1;
		}
		if( m_pActivPage->AllowNext() )
		{
			USHORT nNextId = m_pActivModel->GetNext(m_pActivPage->
							 GetReturnVal());
			if( m_pActivPage->NotifyNext() )
			{
				m_pActivModel->SetProperty( m_pActivPage->GetProperty() );
				m_pUserPath->Insert( m_pActivModel->GetId(), (unsigned long)m_pUserPath->Count() );
				SetPage( nNextId );
			}
		}
	}
	else if( pCtrl == &m_aPBBack )
	{
		USHORT nNextId = (USHORT) m_pUserPath->GetObject(m_pUserPath->Count()-1);
		if( m_pActivPage->NotifyBack() )
		{
			m_pActivModel->SetProperty( m_pActivPage->GetProperty() );
			m_pUserPath->Remove((unsigned long)m_pUserPath->Count()-1);
			SetPage( nNextId );
		}
	}
	else if( pCtrl == &m_aPBCancel )
	{
		if( !(GetButtonState() & BSTATE_DISABLE_CANCEL) )
		{
			bInEndDialog = TRUE;
			bInEndDialog = EndAgentDlg(FALSE);
		}
		return 1;
	}
	return 1;
}

////////////////////////////////////////////////////////////////////////////////
//	BinaryResLoader()

BinaryResLoader::BinaryResLoader( SvMemoryStream& rStrm, const ResId& rId )
	: Resource ( rId )
{
	char*  pStr;
	USHORT nStrLen;
	USHORT nBytesLeft;

	nStrLen = *((USHORT*)GetClassRes());
	IncrementRes( sizeof( short ) );

	nBytesLeft = GetRemainSizeRes();

	while( nBytesLeft )
	{
		USHORT nOut = Min( nStrLen, nBytesLeft );
		USHORT nInc = Min( (USHORT)(nStrLen+2), nBytesLeft );

		pStr = (char*)GetClassRes();
		rStrm.Write( pStr, nOut );
		IncrementRes( nInc );
		nBytesLeft = (nInc != nBytesLeft) ? GetRemainSizeRes() : 0;
	}
}

#if defined(TRU64) && defined(long)
#undef long
#endif
