/*************************************************************************
 *
 *  $RCSfile: fields.cxx,v $
 *
 *  $Revision: 1.23 $
 *
 *  last change: $Author: dv $ $Date: 2001/11/30 12:47:25 $
 *
 *  The Contents of this file are made available subject to the terms of
 *  either of the following licenses
 *
 *         - GNU Lesser General Public License Version 2.1
 *         - Sun Industry Standards Source License Version 1.1
 *
 *  Sun Microsystems Inc., October, 2000
 *
 *  GNU Lesser General Public License Version 2.1
 *  =============================================
 *  Copyright 2000 by Sun Microsystems, Inc.
 *  901 San Antonio Road, Palo Alto, CA 94303, USA
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License version 2.1, as published by the Free Software Foundation.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *  MA  02111-1307  USA
 *
 *
 *  Sun Industry Standards Source License Version 1.1
 *  =================================================
 *  The contents of this file are subject to the Sun Industry Standards
 *  Source License Version 1.1 (the "License"); You may not use this file
 *  except in compliance with the License. You may obtain a copy of the
 *  License at http://www.openoffice.org/license.html.
 *
 *  Software provided under this License is provided on an "AS IS" basis,
 *  WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING,
 *  WITHOUT LIMITATION, WARRANTIES THAT THE SOFTWARE IS FREE OF DEFECTS,
 *  MERCHANTABLE, FIT FOR A PARTICULAR PURPOSE, OR NON-INFRINGING.
 *  See the License for the specific provisions governing your rights and
 *  obligations concerning the Software.
 *
 *  The Initial Developer of the Original Code is: Sun Microsystems, Inc.
 *
 *  Copyright: 2000 by Sun Microsystems, Inc.
 *
 *  All Rights Reserved.
 *
 *  Contributor(s): _______________________________________
 *
 *
 ************************************************************************/

#include "fields.hxx"
#include <tools/solar.h>

//const char VALUE[] = "";
char const VALUE_APPSERVER[]			= "APPSERVER";
char const VALUE_ACTIVEX[] 				= "ACTIVEX";
char const VALUE_ARCHIVE[]          	= "ARCHIVE";
char const VALUE_BIND_DLL[]				= "NT_BIND";
char const VALUE_AFTERWARDS[]      		= "AFTER_INST";
char const VALUE_BEFORE[]              	= "BEFORE_INST";
char const VALUE_EXECINST_BEFORE[]		= "EXEC_INST_BEFORE";
char const VALUE_EXECDEINST_BEFORE[]	= "EXEC_DEINST_BEFORE";
char const VALUE_EXECINST_AFTER[]		= "EXEC_INST_AFTER";
char const VALUE_EXECDEINST_AFTER[]     = "EXEC_DEINST_AFTER";
char const VALUE_CD[]               	= "CD";
char const VALUE_CHECK_TIMESTAMP[]		= "CHECK_TIMESTAMP";
char const VALUE_CHECK_VERSION[]		= "CHECK_VERSION";
char const VALUE_COMP_BY_SETUP[]		= "COMPILED_BY_SETUP";
char const VALUE_CREATE[]  				= "CREATE";
char const VALUE_DISKETTE[]         	= "DISKETTE";
char const VALUE_DELETE_ALL[]			= "DELETE_ALL";
char const VALUE_DELETE_ONLY[]			= "DELETE_ONLY";
char const VALUE_DONT_DELETE[]			= "DONT_DELETE";
char const VALUE_DONT_INSTALL[]			= "DONT_INSTALL";
char const VALUE_DONT_OVERWRITE[]		= "DONT_OVERWRITE";
char const VALUE_DONT_RECOVER[]			= "DONT_RECOVER";
char const VALUE_DONT_SELECT_BY_USER[]	= "DONT_SELECT_BY_USER";
char const VALUE_FONT[]             	= "FONT";
char const VALUE_FONT_WARN_IF_EXISTS[]	= "FONT_WARN_IF_EXISTS";
char const VALUE_EXEC_SCRIPT[]			= "SCRIPT";
char const VALUE_EXEC_APP[]	 			= "APP";
char const VALUE_EXEC_SHELL[]			= "SHELL";
char const VALUE_INSTALL[]				= "INSTALL";
char const VALUE_INSTALL_INFO[]			= "INSTALL_INFO";
char const VALUE_PRE_SELECT_MODULES[]	= "PRE_SELECT_MODULE";
char const VALUE_LANGUAGE_SELECT_MODULES[] = "LANGUAGE_SELECT_MODULE";
char const VALUE_HARDDISK[]         	= "HARDDISK";
char const VALUE_HIDESTANDARD[]			= "HIDESTANDARD";
char const VALUE_HEX_VALUE[]         	= "HEX_VALUE";
char const VALUE_YES[]              	= "YES";
char const VALUE_YES_IF_SINIX_MIPS[]	= "YES_IF_SINIX_MIPS";
char const VALUE_YES_IF_SOLARIS_SPARC[]	= "YES_IF_SOLARIS_SPARC";
char const VALUE_YES_IF_SOLARIS_X86[]	= "YES_IF_SOLARIS_X86";
char const VALUE_YES_IF_HPUX_HP9000[]	= "YES_IF_HPUX_HP9000";
char const VALUE_YES_IF_AIX_RS6000[]	= "YES_IF_AIX_RS6000";
char const VALUE_YES_IF_LINUX_X86[]	= "YES_IF_LINUX_X86";
char const VALUE_YES_IF_TRU64_ALPHA[]	= "YES_IF_TRU64_ALPHA";
char const VALUE_KEEP_OLD_VERSION[]     = "KEEP_OLD_VERSION";
char const VALUE_NETWORK[]              = "NETWORK";
char const VALUE_NO[]               	= "NO";
char const VALUE_NULL[]               	= "NULL";
char const VALUE_OLD_VERSION_REQUIRED[] = "OLD_VERSION_REQUIRED";
char const VALUE_OS2_MODIFY_PATH[]      = "OS2_MODIFY_PATH";
char const VALUE_OVERWRITE[]			= "OVERWRITE";
char const VALUE_OVERWRITE_ONLY[]		= "OVERWRITE_ONLY";
char const VALUE_PACKED[]           	= "PACKED";
char const VALUE_README[]				= "README";
char const VALUE_REGISTRATION_REQUIRED[]= "REGISTRATION_REQUIRED";
char const VALUE_SD_HELP[]				= "SD_HELP";
char const VALUE_SETUP[]				= "SETUP";
char const VALUE_SETUPZIP[]				= "SETUPZIP";
char const VALUE_STANDALONE[]           = "STANDALONE";
char const VALUE_UNINSTALL[]			= "UNINSTALL";
char const VALUE_UNIX_SOFTLINK[]		= "UNIX_SOFTLINK";
char const VALUE_UNPACKED[]         	= "UNPACKED";
char const VALUE_WIN_REQUIRES_SHARE[]	= "WIN_REQUIRES_SHARE";
char const VALUE_WORKSTATION[]      	= "WORKSTATION";
char const VALUE_WORKSTATION_ONLY[]		= "WORKSTATION_ONLY";
char const VALUE_AGENTLOADER[]			= "AGENT_LOADER";
char const VALUE_PROCESSGUARD[]			= "PROCESS_GUARD";
char const VALUE_INI_MIGRATION[]		= "INI_MIGRATION";
char const VALUE_MIGRATION[]	 		= "MIGRATION";
char const VALUE_HIDDENROOT[]			= "HIDDEN_ROOT";
char const VALUE_HIDDENROOT_RECURSIVE[]	= "HIDDEN_ROOT_RECURSIVE";
char const VALUE_SUBSTITUTE[]			= "SUBSTITUTE";
char const VALUE_SERVER_INI[]			= "SERVER_INI";
char const VALUE_REBOOT[]				= "REBOOT";
char const VALUE_REPAIRABLE[]			= "REPAIRABLE";
char const VALUE_RELATIVE[]				= "RELATIVE";
char const VALUE_UNOCOMPONENT[]			= "UNO_COMPONENT";
char const VALUE_DOCLANG[]				= "DOCLANG";
char const VALUE_STRING[]				= "CFG_STRING";
char const VALUE_NUMERIC[]				= "CFG_NUMERIC";
char const VALUE_BOOLEAN[]				= "CFG_BOOLEAN";
char const VALUE_STRINGLIST[] 			= "CFG_STRINGLIST";
char const VALUE_BINARY[]				= "CFG_BINARY";
char const VALUE_WEB_ONLY[]				= "WEBONLY";
char const VALUE_NOWEB[]				= "NOWEB";
char const VALUE_ONLYCUSTOM[]			= "CUSTOMONLY";
char const VALUE_NEEDCONFIG_SERVER[]	= "NEED_CFG_SERVER";
char const VALUE_RESPONSEFILEWIZARD[]	= "RESPONSEFILE_WIZARD";
char const VALUE_NOTIMESTAMP[]			= "NOTIMESTAMP";
char const VALUE_NOUPDATE[]				= "NOUPDATE";
char const VALUE_NOWARNIFNOTEXISTS[]	= "NO_WARNING_IF_NOT_EXISTS";
char const VALUE_RECURSIVE[]            = "RECURSIVE";
char const VALUE_EXECMODIFY_BEFORE[]    = "EXEC_MODIFY_BEFORE";
char const VALUE_EXECMODIFY_AFTER[]     = "EXEC_MODIFY_AFTER";
char const VALUE_KEEP_ALIVE[]           = "KEEP_ALIVE";
char const VALUE_PATCH_SO_NAME[]        = "PATCH_SO_NAME";
char const VALUE_FORCE_REPAIR[]         = "FORCE_REPAIR";

char const * ALL_VALUES[] =
{
	VALUE_NULL,
	VALUE_YES,
	VALUE_NO,
	VALUE_APPSERVER,
	VALUE_ACTIVEX,
	VALUE_NETWORK,
	VALUE_WORKSTATION,
	VALUE_WORKSTATION_ONLY,
	VALUE_STANDALONE,
	VALUE_OS2_MODIFY_PATH,
	VALUE_WIN_REQUIRES_SHARE,
	VALUE_ARCHIVE,
	VALUE_PACKED,
	VALUE_UNPACKED,
	VALUE_FONT,
	VALUE_FONT_WARN_IF_EXISTS,
	VALUE_CHECK_VERSION,
	VALUE_CREATE,
	VALUE_DELETE_ALL,
	VALUE_DELETE_ONLY,
	VALUE_DOCLANG,
	VALUE_DONT_DELETE,
	VALUE_DONT_INSTALL,
	VALUE_DONT_OVERWRITE,
	VALUE_DONT_RECOVER,
	VALUE_DONT_SELECT_BY_USER,
	VALUE_OVERWRITE,
	VALUE_OVERWRITE_ONLY,
	VALUE_UNIX_SOFTLINK,
	VALUE_INSTALL_INFO,
	VALUE_PRE_SELECT_MODULES,
	VALUE_HEX_VALUE,
	VALUE_DISKETTE,
	VALUE_CD,
	VALUE_INSTALL,
	VALUE_UNINSTALL,
	VALUE_README,
	VALUE_SD_HELP,
	VALUE_SETUP,
	VALUE_SETUPZIP,
	VALUE_KEEP_OLD_VERSION,
	VALUE_OLD_VERSION_REQUIRED,
	VALUE_AFTERWARDS,
	VALUE_BEFORE,
	VALUE_COMP_BY_SETUP,
	VALUE_REGISTRATION_REQUIRED,
	VALUE_AGENTLOADER,
	VALUE_PROCESSGUARD,
	VALUE_INI_MIGRATION,
	VALUE_MIGRATION,
	VALUE_HIDDENROOT,
	VALUE_HIDDENROOT_RECURSIVE,
	VALUE_SUBSTITUTE,
	VALUE_SERVER_INI,
	VALUE_EXEC_SCRIPT,
	VALUE_EXEC_APP,
	VALUE_EXEC_SHELL,
	VALUE_REBOOT,
	VALUE_RELATIVE,
	VALUE_UNOCOMPONENT,
	VALUE_EXECINST_BEFORE,
	VALUE_EXECDEINST_BEFORE,
	VALUE_EXECINST_AFTER,
	VALUE_EXECDEINST_AFTER,
	VALUE_REPAIRABLE,
	VALUE_STRING,
	VALUE_NUMERIC,
	VALUE_BOOLEAN,
	VALUE_STRINGLIST,
	VALUE_BINARY,
	VALUE_ONLYCUSTOM,
	VALUE_NEEDCONFIG_SERVER,
	VALUE_NOTIMESTAMP,
	VALUE_NOUPDATE,
	VALUE_NOWARNIFNOTEXISTS,
    VALUE_RECURSIVE,
    VALUE_EXECMODIFY_BEFORE,
    VALUE_EXECMODIFY_AFTER,
    VALUE_KEEP_ALIVE,
    VALUE_PATCH_SO_NAME,
    VALUE_FORCE_REPAIR,
	NULL // Ende
};

char const PROPERTY_ARCHIVE[]       = "Archive";
char const PROPERTY_ARCHIVEFILES[]  = "ArchiveFiles";
char const PROPERTY_ARCHIVESIZE[]   = "ArchiveSize";
char const PROPERTY_CARRIER[]       = "Carrier";
char const PROPERTY_CLIENTROOTPATH[]= "ClientROOTPath";
char const PROPERTY_CLIENTLIST[]	= "ClientList";
char const PROPERTY_CLIENTPOSTFIX[]	= "ClientPostfix";
char const PROPERTY_CODE[]			= "Code";
char const PROPERTY_COMPANYNAME[]	= "CompanyName";
char const PROPERTY_COPY[]			= "Copy";
char const PROPERTY_CONTAINS[]		= "Contains"; // Feld der Inst-DB
char const PROPERTY_CRC[]			= "CRC";
char const PROPERTY_CUSTOMS[]		= "Customs";
char const PROPERTY_DATE[]          = "Date";
char const PROPERTY_DEFAULT[]       = "Default";
char const PROPERTY_DEFAULTDESTPATH[] = "DefaultDestPath";
char const PROPERTY_DESTPATH[]		= "DestPath";
char const PROPERTY_DELETE_KEY[]	= "DeleteKey";
char const PROPERTY_DESCRIPTION[]   = "Description";
char const PROPERTY_DIR[]           = "Dir";
char const PROPERTY_DIRS[]          = "Dirs";
char const PROPERTY_DISKNO[]        = "DiskNo";
char const PROPERTY_DLL[]           = "DLL";
char const PROPERTY_DOSNAME[]       = "DosName";
char const PROPERTY_EXECTYPE[]		= "ExecType";
char const PROPERTY_EXECCOMMAND[]	= "ExecCommand";
char const PROPERTY_FADESPEED[]		= "FadeSpeed";
char const PROPERTY_FADETYPE[]		= "FadeType";
char const PROPERTY_FLATLOADERZIP[] = "FlatLoaderZip";
char const PROPERTY_FOLLOWAPP[]		= "FollowApp";
char const PROPERTY_FOLLOW_EXECTYPE[] = "FollowExecType";
char const PROPERTY_FOLLOW_EXECCOMMAND[] = "FollowExecCommand";
char const PROPERTY_FILEID[]        = "FileID";
char const PROPERTY_FILENAME[]      = "FileName";
char const PROPERTY_FILES[]         = "Files";
char const PROPERTY_FLAGS[]         = "Styles";
char const PROPERTY_FOLDERID[]      = "FolderID";
char const PROPERTY_FOLDERITEMS[]   = "FolderItems";
char const PROPERTY_FONTNAME[]      = "FontName";
char const PROPERTY_FORCEOVERWRITE[]= "ForceOverwrite";
char const PROPERTY_FROMKEY[]		= "FromKey";
char const PROPERTY_TEXTHEIGHT[]	= "TextHeight";
char const PROPERTY_HOSTNAME[]      = "HostName";
char const PROPERTY_ICON[]          = "Icon";
char const PROPERTY_ICONDIR[]       = "IconDir";
char const PROPERTY_ID[]            = "ID";
char const PROPERTY_INSTALLED[]     = "Installed";		// Feld der Inst-DB
char const PROPERTY_INSTALLFROMNET[]= "InstallFromNet"; // Feld der Inst-DB
char const PROPERTY_ITEMCOUNT[]     = "ItemCount";		// Feld der Inst-DB
char const PROPERTY_KEY[]           = "Key";
char const PROPERTY_LONGVALUE[]		= "LongValue";
char const PROPERTY_SEQ_VALUE[]		= "SeqValue";
char const PROPERTY_MAC_CREATOR[]	= "MacCreator";
char const PROPERTY_MAXSELECT[]		= "MaxSelect";
char const PROPERTY_MINIMAL[]       = "Minimal";
char const PROPERTY_MODE[]			= "Mode";
char const PROPERTY_MODULEID[]      = "ModuleID";
char const PROPERTY_MODULEIDS[]     = "ModuleIDs";
char const PROPERTY_MODULELISTS[]   = "ModuleLists";
char const PROPERTY_NAME[]          = "Name";
char const PROPERTY_NETDIR[]        = "NetDir";
char const PROPERTY_ONDESELECT[]    = "OnDeselect";
char const PROPERTY_ONSELECT[]      = "OnSelect";
char const PROPERTY_OPENSUBST[]		= "OpenSubst";
char const PROPERTY_OUPDATEDONE[]	= "OnlineUpdate";
char const PROPERTY_ORDER[]			= "Order";
char const PROPERTY_OS2_CREATORID[] = "Os2CreatorID";
char const PROPERTY_OS2_CLASSID[]   = "Os2ClassID";
char const PROPERTY_OS2_CLOSEICON[] = "Os2CloseIcon";
char const PROPERTY_OS2_EAFILE[]	= "Os2EAFile";
char const PROPERTY_OS2_FILTERS[]   = "Os2Filters";
char const PROPERTY_OS2_ID[]        = "Os2ID";
char const PROPERTY_OS2_OPENICON[]  = "Os2OpenIcon";
char const PROPERTY_OS2_REFERENCEID[] = "Os2ReferenceID";
char const PROPERTY_OVERWRITEMSG[]	= "OverwriteMsg";
char const PROPERTY_PACKEDNAME[]    = "PackedName";
char const PROPERTY_PARAMETER[]     = "Parameter";
char const PROPERTY_PARENTID[]      = "ParentID";
char const PROPERTY_PART[]          = "Part";
char const PROPERTY_PARTS[]			= "Parts";
char const PROPERTY_PARTOF[]        = "PartOf";
char const PROPERTY_PRODUCTNAME[]	= "ProductName";
char const PROPERTY_PRODUCTVERSION[] = "ProductVersion";
char const PROPERTY_INTERNALPRODUCTVERSION[] = "InternalVersion";
char const PROPERTY_BMPPOSX[]  		= "BitmapPosX";
char const PROPERTY_BMPPOSY[]  		= "BitmapPosY";
char const PROPERTY_PROCEDURES[]    = "Procedures";
char const PROPERTY_PROCNAME[]		= "ProcName";
char const PROPERTY_PROFILEID[]     = "ProfileID";
char const PROPERTY_REGISTRYID[]    = "RegistryID";
char const PROPERTY_SCRIPTVERSION[]	= "ScriptVersion";
char const PROPERTY_SECTION[]       = "Section";
char const PROPERTY_SUBKEY[]        = "Subkey";
char const PROPERTY_SIZE[]          = "Size";
char const PROPERTY_DOWNLOAD_SIZE[]	= "DownloadSize";
char const PROPERTY_SOURCEPATH[]    = "SourcePath";
char const PROPERTY_SPECIAL_VERSION[] = "SpecialVersion";
char const PROPERTY_TEXT[]          = "Text";
char const PROPERTY_TIME[]          = "Time";
char const PROPERTY_TOKEY[]			= "ToKey";
char const PROPERTY_TRANSMITTER[]	= "Transmitter";
char const PROPERTY_TYPE[]          = "Type";
char const PROPERTY_VALUE[]         = "Value";
char const PROPERTY_WORKSTATIONVALUE[] = "WorkstationValue";
char const PROPERTY_UIPROC[]		= "UiProc";
char const PROPERTY_UNIX_RIGHTS[]   = "UnixRights";
char const PROPERTY_USERNAME[]		= "UserName";
char const PROPERTY_SUITENAME[]		= "SuiteName";
char const PROPERTY_SCPUNIX_RIGHTS[] = "ScpUnixRights";
char const PROPERTY_UPDATENAME[]	= "UpdateName";
char const PROPERTY_UPDATESIZE[]	= "UpdateSize";
char const PROPERTY_UPDATEFOR[]		= "UpdateFor";
char const PROPERTY_UPGRADEFOR[]	= "UpgradeFor";
char const PROPERTY_TEXTWIDTH[]	 	= "TextWidth";
char const PROPERTY_FONTSIZE[]		= "FontSize";
char const PROPERTY_VENDORBITMAP[]	= "VendorBitmap";
char const PROPERTY_VENDORNAME[]	= "VendorName";
char const PROPERTY_VENDORVERSION[]	= "VendorVersion";
char const PROPERTY_BITMAP[]		= "Bitmap";
char const PROPERTY_WAVE[]			= "Wave";
char const PROPERTY_LANGUAGES[]		= "Languages";
char const PROPERTY_DEFLANGUAGE[]	= "DefaultLanguage";
char const PROPERTY_INST_LANGUAGES[]= "InstLanguages";
char const PROPERTY_PATH[]			= "Path";
char const PROPERTY_TEMPLATEFILE[] 	= "TemplateFile";


