/*************************************************************************
 *
 *  $RCSfile: loader.c,v $
 *
 *  $Revision: 1.25.2.1 $
 *
 *  last change: $Author: mh $ $Date: 2002/04/24 15:59:00 $
 *
 *  The Contents of this file are made available subject to the terms of
 *  either of the following licenses
 *
 *         - GNU Lesser General Public License Version 2.1
 *         - Sun Industry Standards Source License Version 1.1
 *
 *  Sun Microsystems Inc., October, 2000
 *
 *  GNU Lesser General Public License Version 2.1
 *  =============================================
 *  Copyright 2000 by Sun Microsystems, Inc.
 *  901 San Antonio Road, Palo Alto, CA 94303, USA
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License version 2.1, as published by the Free Software Foundation.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *  MA  02111-1307  USA
 *
 *
 *  Sun Industry Standards Source License Version 1.1
 *  =================================================
 *  The contents of this file are subject to the Sun Industry Standards
 *  Source License Version 1.1 (the "License"); You may not use this file
 *  except in compliance with the License. You may obtain a copy of the
 *  License at http://www.openoffice.org/license.html.
 *
 *  Software provided under this License is provided on an "AS IS" basis,
 *  WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING,
 *  WITHOUT LIMITATION, WARRANTIES THAT THE SOFTWARE IS FREE OF DEFECTS,
 *  MERCHANTABLE, FIT FOR A PARTICULAR PURPOSE, OR NON-INFRINGING.
 *  See the License for the specific provisions governing your rights and
 *  obligations concerning the Software.
 *
 *  The Initial Developer of the Original Code is: Sun Microsystems, Inc.
 *
 *  Copyright: 2000 by Sun Microsystems, Inc.
 *
 *  All Rights Reserved.
 *
 *  Contributor(s): _______________________________________
 *
 *
 ************************************************************************/
#include <stdio.h>
#include <stdlib.h>

#include <sys/types.h>
#include <limits.h>
#include <dirent.h>

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xos.h>
#include <X11/Xatom.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <math.h>

#ifdef LINUX
# include <sys/vfs.h>
# define statvfs statfs
#elif defined(NETBSD) || defined(FREEBSD) || defined(MACOSX)
# include <sys/param.h>
# include <sys/mount.h>
# define statvfs statfs
#else
# include <sys/statvfs.h>
#endif

#include "bitmap"
#include "logo.xpm"

#include "svunzip.h"

#include <sys/types.h>
#include <sys/wait.h>

/* */

#include <string.h>
#include <stdlib.h>

#ifndef _LOADER_CXX
#include <tools/solar.h>
#else
#undef BOOL
#define BOOL unsigned char
#ifndef ULONG
#define ULONG unsigned long
#endif
#ifndef USHORT
#define USHORT unsigned short
#endif
#endif

#include <stdio.h>

#ifdef UNX
#define stricmp strcasecmp
#endif

#define MAX_ENTRYS              10000
#define MAX_ARCH_PATH           255
#define BUF_SZ                  32000
#define ARCH_ACTUAL_VERSION     1

#ifndef WIN
#ifndef WNT
#define CALLTYPE
#else
#define CALLTYPE            __cdecl
#endif
#else
#define PASCAL              _pascal
#define FAR                 _far
#define CALLTYPE            FAR PASCAL
#endif

void ConvertXpm( Display* pDisplay, char *xpm[], Pixmap* aPixmap, Pixmap* aMask, int* nWidth, int* nHeight );

typedef const char* (*FncFindArch)(const char* pDefSource, const char* pDefName);

#ifdef UNX
#define MASTER_EXTENSION    "bin"
#define JUNK_EXTENSION      "bin"
#else
#define MASTER_EXTENSION    "exe"
#define JUNK_EXTENSION      "bin"
#endif

BOOL m_bNoJunk = FALSE;
BOOL m_bUseX = TRUE;

typedef struct EventData
{
    long              nEvent;
    struct EventData* pNextEvent;
} EventData;

EventData* m_pEventList = NULL;

typedef struct _ArchEntry
{
    ULONG   nOffset;
    ULONG   nSize;
    char*   pName;
} ArchEntry;

typedef struct _ArchDirectory
{
    FILE*       pArch;
    ULONG       nArchSize;
    FncFindArch fncFindArch;

    char        cDelim;
    char        pSourceDir[MAX_ARCH_PATH];
    char        pMasterArch[MAX_ARCH_PATH];

    ULONG       nArchVersion;
    ULONG       nDirOffset;
    ULONG       nDataOffset;

    ULONG       nDirCount;
    ArchEntry*  pDirectory[MAX_ENTRYS];
} ArchDirectory;

void ArchDirectory_Init( ArchDirectory* p )
{
    p->pArch            = NULL;
    p->fncFindArch      = NULL;
    p->nDirOffset       = 0L;
    p->nDataOffset      = 0L;
    p->nDirCount        = 0L;
    p->nArchSize        = 0L;

    #if defined(MAC)
    p->cDelim           = ':';
    #elif defined(UNX)
    p->cDelim           = '/';
    #else
    p->cDelim           = '\\';
    #endif
}

void ArchDirectory_Deinit( ArchDirectory* p )
{
    ULONG n;
    if( p->pArch )
        fclose( p->pArch );

    for( n = 0; n < p->nDirCount; ++ n )
    {
        ArchEntry* pEntry = p->pDirectory[n];
        free( pEntry->pName );
        free( pEntry );
    }
}

void ArchDirectory_GetArchFileName( ArchDirectory* p, USHORT nSegment, char* pBuffer )
{
    char pDelim[2];
    char pExtension[10];
    unsigned short i;

    pDelim[0] = p->cDelim;
    pDelim[1] = 0x00;

    strcpy( pBuffer, p->pSourceDir );
    if( pBuffer[strlen(pBuffer)-1] != p->cDelim )
        strcat( pBuffer, pDelim );
    strcat( pBuffer, p->pMasterArch );

    if( !m_bNoJunk )
    {
        if( nSegment != 0 )
            sprintf( pExtension, "-%03ld.%s", nSegment, JUNK_EXTENSION );
        else
            sprintf( pExtension, "-%03ld.%s", nSegment, MASTER_EXTENSION );

        strcat( pBuffer, pExtension );
    }
}

BOOL ArchDirectory_ReadDirectory( ArchDirectory* p )
{
    USHORT  i;
    char    cChar;
    int     nIdx = 0;

    int nErr = fseek( p->pArch, p->nDirOffset, SEEK_SET );
    if( nErr )
        return FALSE;

    p->nDirCount = 0;

    fread( &(p->nArchVersion), sizeof(ULONG), 1, p->pArch );
    fread( &(p->nDirCount), sizeof(ULONG), 1, p->pArch );

    for( i = 0; i < p->nDirCount; ++i )
    {
        ArchEntry*  pNew = (ArchEntry*)malloc( sizeof(ArchEntry) );

        pNew->pName = (char*) malloc( MAX_ARCH_PATH );

        fread( &(pNew->nOffset), sizeof(ULONG), 1, p->pArch );
        fread( &(pNew->nSize), sizeof(ULONG), 1, p->pArch );

        for( nIdx = 0; (cChar = fgetc(p->pArch)) != 0x00; ++nIdx )
            pNew->pName[nIdx] = cChar;
        pNew->pName[nIdx] = 0x00;

        p->pDirectory[i] = pNew;
    }

    p->nDataOffset = ftell( p->pArch );
    return TRUE;
}

void ArchDirectory_SetFindArchHdl( ArchDirectory* p, FncFindArch fncNew )
{
    p->fncFindArch = fncNew;
}

BOOL ArchDirectory_SetArchFile( ArchDirectory* p, const char* pBigFile )
{
    USHORT nLen;
//  USHORT i;
    BOOL  bFnd = FALSE;
    char* pBuf = NULL;
    long i;
    char  aSrch1[5] = "BIGF";
    char  aSrch2[5] = "ILE:";
    char  aSrchStr[9];
    BOOL bReturn;
    USHORT nJunks;
    char cBuffer[MAX_ARCH_PATH];
    FILE* pTest;
    BOOL bAllFiles = TRUE;

    p->nArchSize = 0L;
    p->nDataOffset  = 0L;

    p->pArch = fopen( pBigFile, "rb" );
    if( !p->pArch )
        return FALSE;

    fseek( p->pArch, 0L, SEEK_END );
    p->nArchSize = ftell( p->pArch );
    fseek( p->pArch, 0L, SEEK_SET );


    pBuf = (char*) malloc(BUF_SZ);

    strcpy( aSrchStr, aSrch1 );
    strcat( aSrchStr, aSrch2 );

    while( !feof(p->pArch) && !bFnd )
    {
        ULONG nRead = fread( pBuf, sizeof(char), BUF_SZ, p->pArch );
        for( i = 0; i < nRead; ++i )
            if( pBuf[i] == 'B' )
                if( strncmp(&(pBuf[i]), aSrchStr, 8) == 0)
                {
                    p->nDirOffset = atol(&(pBuf[i+8]));
                    if( !p->nDirOffset )
                    {
                        fclose(p->pArch);
                        free( pBuf );
                        return FALSE;
                    }
                    bFnd = TRUE;
                    break;
                }
    }
    free( pBuf );

    if( !bFnd )
    {
        fclose(p->pArch);
        return FALSE;
    }

    bReturn = ArchDirectory_ReadDirectory( p );
    nJunks = (USHORT) ceil( ((double)(p->pDirectory[p->nDirCount-1]->nOffset + p->pDirectory[p->nDirCount-1]->nSize) + p->nDataOffset) / (double)p->nArchSize );
    nJunks = nJunks - 1;

    fclose(p->pArch);

    nLen = strlen(pBigFile);
    memset(p->pSourceDir, 0, MAX_ARCH_PATH );
    memset(p->pMasterArch, 0, MAX_ARCH_PATH );

    for( i = nLen; i >= 0; --i)
        if(pBigFile[i] == p->cDelim)
        {
            strncpy(p->pSourceDir, pBigFile, i+1);
            strcpy(p->pMasterArch, &(pBigFile[i+1]));
            break;
        }

    if( nJunks )
    {
        nLen = strlen(p->pMasterArch);
        for( i = nLen; i >= 0; --i )
            if( p->pMasterArch[i] == '-' )
            {
                p->pMasterArch[i] = 0x00;
                break;
            }
    }

    if( !nJunks )
        m_bNoJunk = TRUE;
    else
    for( i = 0; i <= nJunks; ++i )
    {
        ArchDirectory_GetArchFileName( p, i, cBuffer );
        pTest = fopen( cBuffer, "rb" );
        if( pTest )
            fclose( pTest );
        else
        {
            bAllFiles = FALSE;
            fprintf( stderr, "\nfile not found '%s'", cBuffer );
        }

    }

    if( !bAllFiles )
    {
        fprintf( stderr, "\n\nerror: One or more files are missing! Please ensure that all necessary files are present.\n\n" );
        exit( -1 );
    }

    return bReturn;
}

const ArchEntry* ArchDirectory_ExistsFile( ArchDirectory* p, const char* pFileName )
{
    USHORT i;

    ArchEntry* pEntry = NULL;
    for( i = 0; i < p->nDirCount; ++i )
        if( stricmp(pFileName, p->pDirectory[i]->pName) == 0 )
        {
            pEntry = p->pDirectory[i];
            break;
        }
    return pEntry;
}

BOOL ArchDirectory_GetFile( ArchDirectory* p, const char* pFileName, const char* pDestDir )
{
    char pDestFileName[MAX_ARCH_PATH];
    char pDelim[2];
    const ArchEntry* pEntry = ArchDirectory_ExistsFile( p, pFileName );
    char pArchFileName[MAX_ARCH_PATH];
    USHORT nSplitArchNr;
    const char* pReturn;
    FILE* pDestFile;
    ULONG nStartPos;
    int nErr;
    ULONG nReadSz = 0;
    char* pBuf;
    ULONG nToRead;
    ULONG nRead;

    if( !pEntry )
        return FALSE;

    pDelim[0] = p->cDelim;
    pDelim[1] = 0x00;

    strcpy( pDestFileName, pDestDir );
    strcat( pDestFileName, pDelim );
    strcat( pDestFileName, pEntry->pName );

    nSplitArchNr = (USHORT)((pEntry->nOffset + p->nDataOffset) / p->nArchSize);
    ArchDirectory_GetArchFileName( p, nSplitArchNr, pArchFileName );

    pDestFile = fopen( pDestFileName, "wb" );
    if( !pDestFile )
        return FALSE;

DO_RETRY_FIRST:
    p->pArch = fopen( pArchFileName, "rb" );
    if( !p->pArch )
    {
        if( !p->fncFindArch )
        {
        EXIT_RETRY_FIRST:
            fclose( pDestFile );
            return FALSE;
        }
        pReturn = p->fncFindArch( p->pSourceDir, pArchFileName );
        if( !pReturn )
            goto EXIT_RETRY_FIRST;
        strcpy( p->pSourceDir, pReturn );
        ArchDirectory_GetArchFileName( p, nSplitArchNr, pArchFileName );
        goto DO_RETRY_FIRST;
    }


    nStartPos = (pEntry->nOffset - (nSplitArchNr * p->nArchSize)) + p->nDataOffset;
    nErr = fseek( p->pArch, nStartPos, SEEK_SET );
    if( nErr )
        return FALSE;

    pBuf = (char*) malloc(BUF_SZ);

    while( nReadSz < pEntry->nSize )
    {
        if( feof(p->pArch) )
        {
            fclose( p->pArch );
            nSplitArchNr += 1;
        DO_RETRY:
            ArchDirectory_GetArchFileName( p, nSplitArchNr, pArchFileName );
            p->pArch = fopen( pArchFileName, "rb" );
            if( !p->pArch )
            {
                if( !p->fncFindArch )
                {
                EXIT_RETRY:
                    fclose( pDestFile );
                    fclose( p->pArch );
                    free( pBuf );
                    return FALSE;
                }
                pReturn = p->fncFindArch( p->pSourceDir, pArchFileName);
                if( !pReturn )
                    goto EXIT_RETRY;
                strcpy( p->pSourceDir, pReturn );
                goto DO_RETRY;
            }
        }

        nToRead = BUF_SZ;
        if( nReadSz + nToRead > pEntry->nSize )
            nToRead = pEntry->nSize - nReadSz;

        nRead = fread( pBuf, sizeof(char), nToRead, p->pArch );
        fwrite( pBuf, sizeof(char), nRead, pDestFile );

        nReadSz += nRead;
    }

    fclose( pDestFile );
    fclose( p->pArch );
    free( pBuf );

    return TRUE;
}


ULONG ArchDirectory_GetCount( ArchDirectory* p )
{
    return p->nDirCount;
}

ArchEntry** ArchDirectory_GetRawList( ArchDirectory* p )
{
    return (ArchEntry**) p->pDirectory;
}

void ArchDirectory_ExtractAll( ArchDirectory* p, const char* pDirname )
{
    ULONG i;
    ULONG nCnt          = ArchDirectory_GetCount(p);
    ArchEntry** ppRaw   = ArchDirectory_GetRawList(p);

    for( i = 0; i < nCnt; ++i ) {
        ArchEntry* pEntry = (ArchEntry*)ppRaw[i];
        ArchDirectory_GetFile( p, pEntry->pName, "." );
    }
    #ifdef UNX
    chmod( "setup", S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH );
    #endif
}

#ifdef _LOADER_CXX
#undef BOOL
#endif

/* */

#define PROGRESS_HEIGHT                     12
#define PROGRESS_WIDTH                     200
#define PROGRESS_OFFSET                     10
#define IMAGE_OFFSET                        10

#define __MAX_PATH                          1024
#define MAX_BLOCK                           32000
#define KBYTE                               1024
#define LD_LIBRARY_PATH                     "LD_LIBRARY_PATH"

#define SETUP_EVENT_TIME_TO_START           1L
#define SETUP_EVENT_INSTALL_SETUP           2L
#define SETUP_EVENT_KILL_LOADER_WINDOW      3L
#define SETUP_EVENT_START_SETUP             4L
#define SETUP_EVENT_EXIT_LOADER             5L
#define SETUP_EVENT_EXPOSE                  6L

Display*            gpDisplay;
Window              gaWin;
GC                  gaGC;
int                 screen_num;
char*               display_name = NULL;

unsigned int        screen_width;
unsigned int        screen_height;

unsigned int        gnWindowWidth;
unsigned int        gnWindowHeight;

BOOL                bExtractBIG = FALSE;
ULONG               nMinTempSize = 0;

long                gnTotalSize = 0;
long                gnLastPercent = -1;
long                gnLastBytesWritten = 0;
long                gnTotalBytesWritten = 0;

static char*        progname;
static char         strTmpPath[__MAX_PATH];
static char         strInitPath[__MAX_PATH];
static char         strAbsBinaryName[__MAX_PATH];
static char         strSetupBIN[__MAX_PATH];
static char         strExtractPath[__MAX_PATH];

static const char   strExePatch[] = "BIGFILE:patchpatchpatch";
unsigned long       nSetupSize = 0;

void SendEvent(long);
BOOL __getFullPath(const char* pszFilename, char* pszPath, unsigned long MaxLen);
void DrawProgress( long nPercent );

static char strStartupShellScript[] =
{
"#!/bin/sh\n" \
"#\n" \
"# StarOffice setup script\n" \
"# (c) 1997, Star Division GmbH\n" \
"cd `dirname $0`\n" \
"sd_archive_path=`pwd`\n" \
"sd_setup_binary=setup.bin\n" \
"sd_platform=`uname -s`\n" \
"# some platforms may need an additional search path for X11 shared libraries\n" \
"case $sd_platform in\n" \
"  SunOS)\n" \
"    AL_IGNOREXERRORS=1\n" \
"    export SAL_IGNOREXERRORS\n" \
"    LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/usr/openwin/lib:.:./lib\n" \
"    export LD_LIBRARY_PATH\n" \
"    ;;\n" \
"  Linux)\n" \
"    LD_LIBRARY_PATH=.:./lib:$LD_LIBRARY_PATH\n" \
"    export LD_LIBRARY_PATH\n" \
"    ;;\n" \
"      *)\n" \
"    ;;\n" \
"esac\n" \
"   export SAL_FONTPATH XPPATH\n" \
"# execute setup binary\n" \
"exec $sd_archive_path/$sd_setup_binary $*\n"
};


#define POPEN_COMMAND                   "/sbin/ldconfig -v -X -N 2> /dev/null"

#define MAX_BUF                         32000
#define BUF_OVERFLOW_SPOOL_BACK         30

typedef struct _Library
{
    int     nFnd;
    char*   pName;
} Library;

#define MAX_FILENAMES                  (sizeof(staticLibCheckList)/sizeof(staticLibCheckList[0]))
Library staticLibCheckList[] = {
    { 0, "libc.so.6" }
};

#define SUSE_RELEASE_FILE "/etc/SuSE-release"

void ChopNewline( char* pLine )
{
    while( *pLine && *pLine != '\n' && *(pLine+1) != 0 )
        pLine++;
    if( *pLine == '\n' )
        *pLine = 0;
}

char* CheckSuSE()
{
    FILE* fp;
    static char aVersion[1024];
    int         nMajor = 0, nMinor = 0;
    struct stat aStat;

    if( stat( SUSE_RELEASE_FILE, &aStat ) )
        return NULL;
    fp = fopen( SUSE_RELEASE_FILE, "r" );
    if( ! fp )
        return NULL;

    aVersion[0] = 0;
    fgets( aVersion, sizeof( aVersion ), fp );
    fscanf( fp, "VERSION = %d.%d", &nMajor, &nMinor );
    fclose( fp );
    if( nMajor < 6 )
        return NULL;

    ChopNewline( aVersion );
    return aVersion;
}

void check_system()
{
    int i;
    char* pLDPath;
    FILE* pFile;
    int nAllOK = 1;
    struct stat aStat;
    char* pName;
    char cAnswer;

    FILE* pOut = popen( POPEN_COMMAND, "r" );
    if( pOut )
    {
        char pBuf[MAX_BUF];
        while( !feof(pOut) )
        {
            size_t nRead = fread( pBuf, 1, MAX_BUF, pOut );

            for( i = 0; i < MAX_FILENAMES; ++i )
                if( staticLibCheckList[i].nFnd == 0 )
                    if( strstr(pBuf, staticLibCheckList[i].pName) != NULL )
                        staticLibCheckList[i].nFnd = 1;

            if( !feof(pOut) )
            {
                nRead -= BUF_OVERFLOW_SPOOL_BACK;
                fseek( pOut, 0, nRead );
            }
        }
        fclose( pOut );

        pLDPath = getenv( LD_LIBRARY_PATH );
        if( pLDPath )
        {
            char* pToken = strtok( pLDPath, ":" );
            while( pToken != NULL )
            {
                if( strlen(pToken) != 0 )
                {
                    for( i = 0; i < MAX_FILENAMES; ++i )
                        if( staticLibCheckList[i].nFnd == 0 )
                        {
                            char cFilename[MAX_BUF];
                            strcpy( cFilename, pToken );
                            strcat( cFilename, "/" );
                            strcat( cFilename, staticLibCheckList[i].pName );

                            pFile = fopen( cFilename, "r" );
                            if( pFile )
                            {
                                staticLibCheckList[i].nFnd = 1;
                                fclose( pFile );
                            }
                        }
                }
                pToken = strtok( NULL, ":" );
            }
        }

        for( i = 0; i < MAX_FILENAMES; ++i )
            if( staticLibCheckList[i].nFnd == 0 )
            {
                if( nAllOK )
                    printf( "\nERROR: setup system check failed:\n\n" );
                printf( "\t%s   library not found\n", staticLibCheckList[i].pName );
                nAllOK = 0;
            }

        if( nAllOK )
            return;

        printf( "\nStarOffice 5.0 uses the new glibc2 (=libc6).\n" );
        printf( "The libraries above could not be found.\n\n" );
        printf( "The glibc_inst.tar package includes a README file which describes\n" );
        printf( "how to install these libraries. It will be made available on the StarDivision\n" );
        printf( "ftp mirror sites in the same directory as the StarOffice installation files.\n\n" );


        if( stat( "/lib/ld-linux.so.2", &aStat ) )
        {
            printf( "Since there is no /lib/ld-linux.so.2 your system probably\ndoes not support glibc2. Please install the glibc_inst.tar package.\n" );
            exit( -1 );
        }

        pName = CheckSuSE();
        if( pName )
        {
            printf( "Since you seem to use\n\t\"%s\"\nas distribution this is probably not a problem.\n\n", pName );
        }
        else
        {
            printf( "You can try to run setup (and StarOffice) anyway. If it does\nnot work or you experience strange crashes or get unresolved symbol errors\nwe recommend installing the glibc_inst.tar package.\n" );
            printf( "\nDo you want to proceed anyway ? <y/n> " );

            cAnswer = (char)fgetc( stdin );
            if( cAnswer == 'n' || cAnswer == 'N' )
                exit( 1 );
        }
    }
}


#ifdef LINUX
#include <dlfcn.h>
void check_glibc()
{
    void *handle;
    void * (*pverfunc)(void);
    char *pvstr;

    handle      = dlopen("libc.so.6", RTLD_LAZY);

    /* new API for glibc-2.1, not available in glibc-2.0.7 */
    pverfunc    = dlsym(handle, "gnu_get_libc_version");
    /* old API for glibc-2.0.7,  no longer available in glibc-2.1 */
    pvstr       = dlsym(handle, "__libc_version");

    if ( pverfunc ) {
        printf("glibc version: %s\n", pverfunc());
        return ;
    }

    printf("error: wrong glibc version, you need 2.1.1\n" );
    exit(1);
}
#endif

Bool b_xerror = False;

int
NewErrorHandler(Display *p_display, XErrorEvent *p_event)
{
    b_xerror = True;
    return 0;
}

int (*OldErrorHandler)(Display* p_display, XErrorEvent *p_event);

Bool
check_fontpath (Display *p_display)
{
    Bool   b_anyxerror = False;
    int    n_oldfp;
    char** pp_oldfp;

    if (p_display == NULL)
        return 0;

    OldErrorHandler = XSetErrorHandler (NewErrorHandler);

    // rehash the fontpath

    pp_oldfp = XGetFontPath (p_display, &n_oldfp);

    b_xerror = False;
    XSetFontPath (p_display, pp_oldfp, n_oldfp);
    XSync (p_display, False);

    // in case of an error check each fontpath element separately

    if (b_xerror)
    {
        int i;
        int n_newfp = n_oldfp;
        char** pp_newfp = (char**)malloc(n_newfp * sizeof(char*));

        for (i = 0, n_newfp = 0; i < n_oldfp; i++)
        {
            pp_newfp[ n_newfp ] = pp_oldfp[i];
            b_xerror = False;
            XSetFontPath (p_display, pp_newfp, n_newfp + 1);
            XSync (p_display, False);

            // in case of an error remove the pathelement from fontpath
            if (b_xerror)
                b_anyxerror = True;
            else
                n_newfp++;
        }

        free (pp_newfp);
    }
    XFreeFontPath (pp_oldfp);

    XSetErrorHandler (OldErrorHandler);

    return b_anyxerror;
}

BOOL CopyFile( const char* pSource, const char* pDest )
{
    int hSourceHdl  = open( pSource, O_RDONLY );
    int hDestHdl    = open( pDest, O_CREAT | O_WRONLY );
    unsigned long   nTotalSize;
    unsigned long   nRead;
    char*           pBuffer = (char*)malloc(MAX_BLOCK);

    if( hSourceHdl == -1 || hDestHdl == -1 )
        return FALSE;


    nTotalSize = lseek( hSourceHdl, 0L, SEEK_END );
    lseek( hSourceHdl, 0L, SEEK_SET );

    do {
        nRead = read( hSourceHdl, pBuffer, MAX_BLOCK );
        if( nRead )
            write( hDestHdl, pBuffer, nRead );
    } while( nRead != 0 );

    close( hSourceHdl );
    close( hDestHdl );

    chmod( pDest, S_IRWXU );

    return TRUE;
}

void KillSetupDir()
{
    DIR* pDir = opendir( strTmpPath );
    struct dirent* pFile;

    if( !pDir )
        return ;

    while( (pFile = readdir(pDir)) != NULL )
    {
        unlink( pFile->d_name );
    }

    chdir( strInitPath );
    rmdir( strTmpPath );
}

void makeSymLink( char* s )
{
    char pFile[__MAX_PATH];
    char * ptr;
    int i = 0;
    char tmp[2];
    char dest[__MAX_PATH];
    char src[__MAX_PATH];

    strcpy( pFile, s );

    while( ptr = strrchr(pFile,'.') )
    {
        char c = *(ptr+1);

        if ( c < 48 || c > 57 )
            break;
        else if ( ++i == 3 )
            break;
        *ptr = '\0';
    }

    /*
     * i==2: for external libs: libabc.so.1 -> abc.so.1.2
     * i==3: our own versioning: libabc.so.1 -> abc.so.1.2.3
     */
    if( i == 2 || i == 3 )
    {
        if ( i == 2 )
            pFile[ strlen( pFile ) ] = '.';

        strcpy( src, strTmpPath );
        strcat( src, "/" );
        strcat( src, s );

        strcpy( dest, strTmpPath );
        strcat( dest, "/" );
        strcat( dest, pFile );

        symlink( src, dest );
    }
}

char* GetTempPath(char* pBuf)
{
	int nLen;
    char* pTmp = getenv( "TMP" );
	
    if( !pTmp )
        pTmp = getenv( "TEMP" );

    if( pTmp )
        strcpy( pBuf, pTmp );
    else
    {
		pTmp = P_tmpdir;
		nLen = strlen(pTmp);
		if (pTmp[ nLen - 1] == '/')
		{
			strncpy( pBuf, pTmp, nLen - 1 );
			// #95475#
			pBuf[nLen - 1] = '\0';
		}
		else
		{
			strcpy( pBuf, pTmp );
		}
		// strcpy( pBuf, "/tmp" );
	}
	
    return pBuf;
}

void GetTempFile(char* pBuf)
{
    char*       ret_val;
    size_t      i;
    char        sBuf[__MAX_PATH];
    unsigned    u;

    char        pfx[6];
    char        ext[5];
    struct stat aStat;

    strcpy( pfx, "sv" );
    strcpy( ext, ".tmp" );

    if ( !GetTempPath(sBuf) )
        return;

    i = strlen(sBuf);
    ret_val = (char*) malloc(i+2  + 8  + 4 );
    if (ret_val)
    {
        strcpy(ret_val,sBuf);

        if( i>0 && ret_val[i-1] != '\\' && ret_val[i-1] != '/' && ret_val[i-1] != ':' )
            ret_val[i++] = '/';

        strncpy(ret_val + i, pfx, 5);
        ret_val[i + 5] = '\0';
        i = strlen(ret_val);

        for (u = 1; u < 26*26*26; u++)
        {
            sprintf(ret_val+i, "%03u", u);

            strcat(ret_val,ext);

            if ( stat( ret_val, &aStat ) )
            {
                strcpy( pBuf, ret_val );
                break;
            }
        }
        free( ret_val);
        ret_val = 0;
    }
}

void __EnumFilesCallBack( char *pFile, ULONG nSize, void *pObject )
{
    nMinTempSize += nSize;
    gnTotalSize  += nSize;
}

void __UnzipCallback( long lBytesWritten )
{
    long nPercent;

    if ( gnTotalSize == 0 )
        return;

    if ( lBytesWritten <= gnLastBytesWritten )
        gnTotalBytesWritten += gnLastBytesWritten;
    
    gnLastBytesWritten = lBytesWritten;
    
    nPercent = ( ( gnTotalBytesWritten + lBytesWritten ) / ( gnTotalSize / 100 ) );
    
    DrawProgress( nPercent );
}

void UnpackBIG2Temp( ArchDirectory* pBigDir, BOOL bSize )
{
    ArchEntry* pEntry;
    ULONG i;

    for( i = 0; i < pBigDir->nDirCount; ++i )
    {
        pEntry = (ArchEntry*)pBigDir->pDirectory[i];
        if( strncmp(pEntry->pName, "f0_", 3) == 0 )
            if( bSize )
            {
// 				nMinTempSize += pEntry->nSize;
                ArchDirectory_GetFile( pBigDir, pEntry->pName, strTmpPath );
                SVUnzipEnumFiles( pEntry->pName, "*", (UnzipEnumFilesCallBack*) __EnumFilesCallBack, NULL );
                unlink( pEntry->pName );
			}
            else
            {
                ArchDirectory_GetFile( pBigDir, pEntry->pName, strTmpPath );
                SVUnzip( pEntry->pName, "*", (const char*)"qq", (UnzipCallBack*) __UnzipCallback );
                unlink( pEntry->pName );
            }
    }
}


void Unpack2Temp( BOOL bSize )
{
    char            file[16*1024];
    struct dirent*  pFile;
    DIR*            pDir = opendir( strInitPath );

    if( !pDir ) return ;
    while( (pFile = readdir(pDir)) != NULL )
    {
        if( strncmp(pFile->d_name, "f0_", 3) == 0 )
        {
            strcpy( file, strInitPath );
            strcat( file, "/" );
            strcat( file, pFile->d_name );

            if( bSize )
                SVUnzipEnumFiles( file, "*", (UnzipEnumFilesCallBack*) __EnumFilesCallBack, NULL );
            else
                SVUnzip( file, "*", (const char*)"qq", (UnzipCallBack*) __UnzipCallback );
        }
    }
}

void InstallSetupFile( ArchDirectory* pBigDir )
{
    int nErr = 0;
    char    strSetupOrgZIP[__MAX_PATH];
    char    strSetupZIP[__MAX_PATH];
    char    strSetupINI[__MAX_PATH];
	char	strUnoINI[__MAX_PATH];

    FILE*   pFile;
    struct  statvfs buf;
    ULONG   nSize = 0;
    DIR* pDir;
    struct dirent* pDirFile;

    GetTempFile( strTmpPath );

    if( strTmpPath[0] != '\0' )
        nErr = mkdir( strTmpPath, S_IRWXU );
    else
    {
        (void)  fprintf( stderr, "%s: cannot find temppath!\n",
                         progname );
        exit( -1 );
    }

    if( nErr == -1 )
    {
        (void)  fprintf( stderr, "%s: could not create temporary directory (%s)\n",
                         progname, strTmpPath );
        exit( -1 );
    }

    if( chdir(strTmpPath) == -1 )
    {
        (void)  fprintf( stderr, "%s: could not change to temporary directory (%s)\n",
                         progname, strTmpPath );
        exit( -1 );
    }

    if( !pBigDir )
    {
        Unpack2Temp( TRUE );
        nMinTempSize += 512000;
    }
    else
    {
        UnpackBIG2Temp( pBigDir, TRUE );
        nMinTempSize += 8192000;
    }
    nMinTempSize /= KBYTE;

    statvfs( strTmpPath, &buf);
    #if defined(LINUX) || defined(NETBSD) || defined(FREEBSD) || defined(MACOSX) || defined(TRU64)
    nSize = buf.f_bsize;
    #else
    nSize = (buf.f_frsize ? buf.f_frsize : buf.f_bsize);
    #endif
    if( nSize < KBYTE )
        nSize = buf.f_bavail / (KBYTE / nSize);
    else if( nSize > KBYTE )
        nSize = buf.f_bavail * (nSize / KBYTE);
    else
        nSize = buf.f_bavail;

    if( nSize < nMinTempSize )
    {
        (void)  fprintf( stderr, "%s: The temporary directory is full. (%s)\n",
                         progname, strTmpPath );
        exit( -1 );
    }

    if( !pBigDir )
        Unpack2Temp( FALSE );
    else
        UnpackBIG2Temp( pBigDir, FALSE );

    if ( nErr )
    {
        (void)  fprintf( stderr, "%s: Could not unpack file '%s'\n",
                         progname, strSetupZIP );
        exit( -1 );
    }
    else
        DrawProgress( 100 );


/* --------------------------------- setup.ini --------------------------------- */

    strcpy( strSetupINI, strTmpPath );
    strcat( strSetupINI, "/setup.ini" );

    pFile = fopen( strSetupINI, "w+" );

    if( pFile )
    {
        fprintf( pFile, "[source]\n" );
        if( pBigDir )
        {
            fprintf( pFile, "path=%s\n", strAbsBinaryName );
            fprintf( pFile, "big=1\n" );
            fprintf( pFile, "offset=%ld\n", nSetupSize );
        }
        else
                fprintf( pFile, "path=%s\n", strInitPath );

        fclose( pFile );
    }


/* ---------------------------------- uno.ini ---------------------------------- */

/* #91782# */
    strcpy( strUnoINI, strTmpPath );
    strcat( strUnoINI, "/unorc" );

    pFile = fopen( strUnoINI, "w+" );

    if( pFile )
    {
		fprintf( pFile, "[bootstrap]\n");
		fprintf( pFile, "UNO_TYPES = applicat.rdb\n");
		fprintf( pFile, "UNO_SERVICES = setup_services.rdb" );
		fclose( pFile );
	}

/* ----------------------------------------------------------------------------- */
    strcpy( strSetupBIN, strTmpPath );
    strcat( strSetupBIN, "/setup.bin" );
    chmod( strSetupBIN, S_IRWXU );

    strcpy( strSetupBIN, strTmpPath );
    strcat( strSetupBIN, "/sopatchlevel.sh" );
    chmod( strSetupBIN, S_IRWXU );

    strcpy( strSetupBIN, strTmpPath );
    strcat( strSetupBIN, "/sorev" );
    chmod( strSetupBIN, S_IRWXU );

    strcpy( strSetupBIN, strTmpPath );
    strcat( strSetupBIN, "/setup" );
    chmod( strSetupBIN, S_IRWXU );

    pDir = opendir( strTmpPath );
    if( pDir )
        while( (pDirFile = readdir(pDir)) != NULL )
            if( strcmp(pDirFile->d_name, ".") != 0 &&
                strcmp(pDirFile->d_name, "..") != 0 )
            makeSymLink( pDirFile->d_name );
    closedir( pDir );

    SendEvent( SETUP_EVENT_KILL_LOADER_WINDOW );
}

void InstallBigSetupFile()
{
    ArchDirectory aDir;
    ArchDirectory_Init( &aDir );

    if( !ArchDirectory_SetArchFile(&aDir, strAbsBinaryName) )
    {
        (void)  fprintf( stderr, "%s: cannot open archivefile %s\n",
                         progname, strAbsBinaryName );
        exit( -1 );
    }

    if( bExtractBIG )
    {
        USHORT nLen = strlen(strExtractPath);
        if( nLen ) {
            if( chdir(strExtractPath) == -1 ) {
                (void) fprintf( stderr, "%s: could not change directory (%s)\n",
                                progname, strExtractPath );
                exit( -1 );
            }
        }
        else strcpy( strExtractPath, "." );

        fprintf( stderr, " extracting files please wait...\n" );
        ArchDirectory_ExtractAll( &aDir, strExtractPath );
        exit( 0 );
    }
    else
        InstallSetupFile( &aDir );
}

void load_font(XFontStruct **font_info)
{
    char *fontname = "9x15";
    if( (*font_info = XLoadQueryFont( gpDisplay, fontname )) == NULL )
    {
        (void) fprintf( stderr, "%s: Cannot open 9x15 font\n",
               progname);
        exit( -1 );
    }
}

/*
void draw_text(Window win, GC gc, XFontStruct *font_info, unsigned int win_width,
    unsigned int win_height)
{
    char*   strText = "Initializing installation program...";
    int     nLen,
            nWidth;
    char    cd_height[50];
    int     font_height;

    nLen        = strlen( strText );
    nWidth      = XTextWidth( font_info, strText, nLen );
    font_height = font_info->ascent + font_info->descent;

    XDrawString( gpDisplay, win, gc, (win_width - nWidth)/2,
                 (win_height - font_height) / 2, strText, nLen );
}*/

void SendEvent( long nEvent )
{
    if ( m_bUseX )
    {
        XEvent aClient;
        memset( &aClient, 0, sizeof(XEvent) );

        (&(aClient.xclient))->type          = ClientMessage;
        (&(aClient.xclient))->display       = gpDisplay;
        (&(aClient.xclient))->window        = gaWin;
        (&(aClient.xclient))->message_type  = (Atom) nEvent;
        (&(aClient.xclient))->format        = 32;
        (&(aClient.xclient))->data.l[0]     = nEvent;

        XSendEvent( gpDisplay, gaWin, False, 0, &aClient );
    }
    else
    {
        EventData *pEvent = (EventData*) malloc( sizeof( EventData ) );
        pEvent->nEvent = nEvent;
        pEvent->pNextEvent = NULL;

        if ( m_pEventList == 0 )
            m_pEventList = pEvent;
        else
        {
            EventData *pData = m_pEventList;
            while ( pData->pNextEvent )
                pData = pData->pNextEvent;
            pData->pNextEvent = pEvent;
        }
    }
}

long NextEvent()
{
    XEvent  report;
    long    nRet = 0;

    if ( m_bUseX )
    {
        XNextEvent( gpDisplay, &report );

        switch( report.type )
        {
            case ClientMessage :
                nRet = report.xclient.message_type;
                break;

            case Expose:
                if (report.xexpose.count != 0)
                    break;
                nRet = SETUP_EVENT_EXPOSE;
                break;
        }
    }
    else
    {
        EventData* pEvent = m_pEventList;

        if ( m_pEventList == NULL )
            return SETUP_EVENT_EXIT_LOADER;

        m_pEventList = pEvent->pNextEvent;
        nRet = pEvent->nEvent;

        free( pEvent );
    }
    
    return nRet;
}

BOOL MayUseX( int argc, char** argv )
{
    int i;

    for ( i=1; i<argc; i++ )
    {
        if ( ( strncmp(argv[i], "-r:", 3) == 0 ) ||
             ( strncmp(argv[i], "-rsp1", 5) == 0 ) ||
             ( strncmp(argv[i], "-rsp2", 5) == 0 ) )
        {
            return FALSE;
        }
    }
    return TRUE;
}

int main(int argc, char**argv)
{
    int             x, y;
    unsigned int    display_width,
                    display_height;
    int             nWidth, nHeight;
    int             nMask;
    Pixmap          aImage;
    Pixmap          aMask;
    GC              gc;
    GC              aCopyGC;
    XFontStruct*    font_info;
    int             nIdx;
    int             i;
    long            nEvent;
    XGCValues       aValues;
    XSetWindowAttributes aAttr;
    XColor aColor;
    Colormap aColorMap;

// #90613#
    int bReturnValueSet = 0;
    int nReturnValue = 1;
    pid_t pid;
    int nWaitpidValue;
    int nStatus;
    int nCheckForX = 1;

#if defined LINUX
    check_system();
    check_glibc();
#endif

    progname = argv[0];

    if( argc > 1 && strncmp(argv[1], "-extract", 8) == 0 )
    {
        bExtractBIG = TRUE;
        if( argc > 2 )
            strcpy( strExtractPath, argv[2] );
    }

    if( !__getFullPath(progname, strAbsBinaryName, __MAX_PATH) )
    {
        fprintf( stderr, "%s: absolute programpath cannot be found.\n", progname );
        exit(0);
    }

    for ( i=1 ; i<argc; i++ )
    {
        if ( ( strncasecmp( argv[i], "-r:", 3 ) == 0 ) ||
             ( strncasecmp( argv[i], "-rsp1:", 6 ) == 0 ) ||
             ( strncasecmp( argv[i], "-rsp2:", 6 ) == 0 ) )
        {
            nCheckForX = 0;
            break;
        }
    }

    if ( nCheckForX == 1 )
        m_bUseX = MayUseX( argc, argv );
    else
        m_bUseX = FALSE;

    nIdx = strlen( strAbsBinaryName );
    while( strAbsBinaryName[nIdx] != '/' )
    {
        if( nIdx == 0)
            break;
        else
            nIdx--;
    }
    strncpy( strInitPath, strAbsBinaryName, nIdx );

    if ( m_bUseX )
    {
        if ( (gpDisplay = XOpenDisplay( display_name )) == NULL )
        {
            (void) fprintf( stderr, "%s: cannot connect to X server %s\n",
                            progname, XDisplayName(display_name) );
            exit( -1 );
        }
        
        if ( check_fontpath( gpDisplay ) )
        {
        #ifdef DEBUG
            fprintf(stderr, "%s: error in fontpath (salvaged)\n", progname);
        #endif
        }

        screen_num      = DefaultScreen(gpDisplay);
        display_width   = DisplayWidth(gpDisplay, screen_num);
        display_height  = DisplayHeight(gpDisplay, screen_num);
	    aColorMap = DefaultColormap( gpDisplay, screen_num );
        ConvertXpm( gpDisplay, logo_xpm, &aImage, &aMask, &nWidth, &nHeight );

        gnWindowWidth = nWidth + ( 2 * PROGRESS_OFFSET ) + PROGRESS_WIDTH + IMAGE_OFFSET;
        if ( nHeight + 2*IMAGE_OFFSET > ( ( 2 * PROGRESS_OFFSET ) + PROGRESS_HEIGHT ) )
            gnWindowHeight = nHeight + 2*IMAGE_OFFSET;
        else
            gnWindowHeight = ( 2 * PROGRESS_OFFSET ) + PROGRESS_HEIGHT;
        
        x = (display_width - gnWindowWidth) / 2;
        y = (display_height - gnWindowHeight) / 2;

		/* Add some space for the border, too */
        gnWindowWidth += 2;
        gnWindowHeight += 2;
        x -= 1;
        y -= 1;
        
        XAllocNamedColor( gpDisplay,
						  aColorMap,
						  "lightgrey",
                          &aColor, &aColor );
        aAttr.background_pixel = aColor.pixel;
        aAttr.override_redirect = True;
        aAttr.event_mask = ExposureMask;
        gaWin = XCreateWindow( gpDisplay,
                             DefaultRootWindow( gpDisplay ),
                             x, y, gnWindowWidth, gnWindowHeight, 0,
                             DefaultDepth( gpDisplay, DefaultScreen( gpDisplay ) ),
                             InputOutput,
                             DefaultVisual( gpDisplay, DefaultScreen( gpDisplay ) ),
                             CWOverrideRedirect | CWBackPixel | CWEventMask,
                             &aAttr );

        nMask = GCFunction|GCForeground;
        aValues.foreground	= 0xffffffff;
        aValues.function	= GXcopy;

        if( aMask != None )
        {
            aValues.clip_mask		= aMask;
            aValues.clip_x_origin	= IMAGE_OFFSET+1;
            aValues.clip_y_origin	= IMAGE_OFFSET+1;
            nMask |= GCClipMask | GCClipXOrigin | GCClipYOrigin;
        }

        gaGC    = DefaultGC( gpDisplay, screen_num );
        aCopyGC = XCreateGC( gpDisplay, gaWin, nMask, &aValues );

        load_font( &font_info );

        XMapWindow( gpDisplay, gaWin );
        XFlush( gpDisplay );
    }

    SendEvent( SETUP_EVENT_TIME_TO_START );

    while( 1 )
    {
        nEvent = NextEvent();

        switch( nEvent )
        {
            case SETUP_EVENT_TIME_TO_START :
                SendEvent( SETUP_EVENT_INSTALL_SETUP );
                break;

            case SETUP_EVENT_INSTALL_SETUP :
                nSetupSize = atol( &(strExePatch[8]) );
                if( !nSetupSize )
                    InstallSetupFile( NULL );
                else
                    InstallBigSetupFile();
                break;

            case SETUP_EVENT_KILL_LOADER_WINDOW :
                if ( m_bUseX )
                    XUnmapWindow( gpDisplay, gaWin );
                SendEvent( SETUP_EVENT_START_SETUP );
                break;

            case SETUP_EVENT_START_SETUP : {
/* in execv are args only separate
                int nFrom = 1;
                for( i = nFrom; i < argc; ++i )
                {
                    strcat( strSetupBIN, " " );
                    strcat( strSetupBIN, argv[i] );
                }
*/

                chdir( strInitPath );
//              system( strSetupBIN );

                // #90613# this is the system(...) replacement
                
                if (( pid = fork()) < 0 )
                {
                    // DBG_ASSERT( FALSE, "fork error" );
                    fprintf(stderr, "fork error.\n");
                    exit(-1);
                }
                else if ( pid == 0 )
                {
//                  if ( execv( strSetupBIN, (char * const *) NULL ) < 0 )
                    if ( execv( strSetupBIN, argv ) < 0 )
                    {
                        // DBG_ASSERT( FALSE, "execv failed" );
                        fprintf(stderr, "execv failed with file:%s with %d.\n", strSetupBIN);
                        exit(-1);
                    }
                }
                //fprintf( stderr, "parent: %s %s\n", ppArgv[0] , ppArgv[1] );
                if ( nWaitpidValue = waitpid( pid, &nStatus, 0 ) < 0 )
                {
                    // DBG_ASSERT( FALSE, "wait error" );
                    fprintf(stderr, "wait failed.\n");
                    exit(-1);
                }
                
                if (WIFEXITED(nStatus) != 0)
                {
                    bReturnValueSet = 1;
                    nReturnValue = WEXITSTATUS(nStatus);
                }
                
    		chdir( strTmpPath );
                SendEvent( SETUP_EVENT_EXIT_LOADER );
            } break;

            case SETUP_EVENT_EXIT_LOADER :
                KillSetupDir();

                if ( m_bUseX )
                {
                    XUnloadFont( gpDisplay, font_info->fid );
                    XFreePixmap( gpDisplay, aImage );
                    if( aMask )
                        XFreePixmap( gpDisplay, aMask );
                    XFreeGC( gpDisplay, aCopyGC );
                    XCloseDisplay( gpDisplay );
                }

                if (bReturnValueSet == 1)
                    exit(nReturnValue);
                else
                    exit(1);
                break;

            case SETUP_EVENT_EXPOSE:
                {
                    int nX1, nX2, nY1, nY2;
                    
                    nX1 = 0;
                    nY1 = 0;
                    nX2 = nX1 + gnWindowWidth - 1;
                    nY2 = nY1;
                    
                    XSetForeground( gpDisplay, gaGC,
                                    WhitePixel( gpDisplay, screen_num ) );
                    XDrawLine( gpDisplay, gaWin, gaGC, nX1, nY1, nX2, nY2 );
                
                    nX2 = nX1;
                    nY2 = nY1 + gnWindowHeight - 1;
                    XDrawLine( gpDisplay, gaWin, gaGC, nX1, nY1, nX2, nY2 );

                    XSetForeground( gpDisplay, gaGC,
                                    BlackPixel( gpDisplay, screen_num ) );

                    nX1 = nX2 + gnWindowWidth - 1;
                    nY1 = nY2;
                    XDrawLine( gpDisplay, gaWin, gaGC, nX1, nY1, nX2, nY2 );
                    
                    nX2 = nX1;
                    nY2 = nY1 - gnWindowHeight + 1;
                    XDrawLine( gpDisplay, gaWin, gaGC, nX1, nY1, nX2, nY2 );

                    XCopyArea( gpDisplay, aImage, gaWin,
                               aCopyGC, 0, 0,
                               nWidth, nHeight, 1 + IMAGE_OFFSET, 1 + IMAGE_OFFSET );
                    DrawProgress( gnLastPercent );
                }

                break;
        }
    }

    return 1;
}

/*****************************************************************************/
/* getFullPath */
/*****************************************************************************/

BOOL __getFullPath(const char* pszFilename, char* pszPath, unsigned long MaxLen)
{
    int   n;
    char* pBuffer;
    char* pDir;
    struct stat status;
    struct stat root;
    struct stat parent;
    char  Path[PATH_MAX + 1];

    pDir = strdup(pszFilename);

    /* check if path has a trailing '/', so it should specify a directory, */
        /* or if last component doesn't exist or is not a directory. So in any case */
    /* of this the last component should be remove before checking the path */
    if ((pDir[strlen(pDir) - 1] == '/') ||
        (stat(pDir, &status) < 0) || (! S_ISDIR(status.st_mode)))
    {
        char* pFile;

        if ((pFile = strrchr(pDir, '/')) != NULL)
        {
            *pFile++ = '\0';
            strcpy(Path, pFile);
            strcat(Path, "/");
        }
        else
        {
            strcpy(Path, pDir);
            strcat(Path, "/");
            free(pDir);
            pDir = strdup(".");
        }

        if ((strlen(pDir) > 0) &&
            ((stat(pDir, &status) < 0) || (! S_ISDIR(status.st_mode))))
        {
            free(pDir);
            return (FALSE);
        }
    }
    else
        Path[0] = '\0';

    if ((n = pathconf(pDir, _PC_PATH_MAX)) < 0)
        n = PATH_MAX + 1;

    pBuffer = (char *)malloc((n + 1) * sizeof(char));
    strcpy(pBuffer, pDir);

    stat("/", &root);

    strcat(pBuffer, "/.");
    stat(pBuffer, &status);
    strcat(pBuffer, ".");

    while ((status.st_dev != root.st_dev) || (status.st_ino != root.st_ino))
    {
        DIR*           dir;
        struct dirent* entry;

        if (((dir = opendir(pBuffer)) == NULL) ||
            (stat(pBuffer, &parent) < 0))
        {
            free(pDir);
            free(pBuffer);

            return (FALSE);
        }

        if (status.st_dev == parent.st_dev)
        {
            do
            {
                if ((entry = readdir(dir)) == NULL)
                {
                    free(pDir);
                    free(pBuffer);

                    return (FALSE);
                }
            }
            while (entry->d_ino != status.st_ino);
        }
        else
        {
            /*
             * if this point is a mount point we have to check
             * each entry, because the inode number in the directory
             * is for the parent directory, not for the mounted file
             */
            char* full = (char *)malloc((strlen(pBuffer) + PATH_MAX + 1) * sizeof(char));
            char* name;

            strcpy(full, pBuffer);
            strcat(full, "/");
            name = full + strlen(full);

            do
            {
                if ((entry = readdir(dir)) == NULL)
                {
                    free(full);

                    free(pDir);
                    free(pBuffer);

                    return (FALSE);
                }

                if ((entry->d_name[0] == '.') && ((entry->d_name[1] == '\0') ||
                    ((entry->d_name[1] == '.') && (entry->d_name[2] == '\0'))))
                    continue;

                strcpy(name, entry->d_name);

                if (stat(full, &parent) < 0)
                    continue;
            }
            while ((parent.st_ino != status.st_ino) || (parent.st_dev != status.st_dev));

            free(full);
        }

        strcat(Path, entry->d_name);
        strcat(Path, "/");

        closedir(dir);

        stat(pBuffer, &status);
        strcat(pBuffer, "/..");
    }

    free(pDir);
    free(pBuffer);

    if (strlen(Path) < MaxLen)
    {
        int  n;
        char *p, *l;

        for (p = Path + strlen(Path), l = p; p >= Path; p--)
        {
            if (*p == '/')
            {
                n = l - (p + 1);
                memcpy(pszPath, p + 1, n);
                pszPath += n;
                *pszPath++ = '/';
                l = p;
            }
        }

        n = l - (p + 1);
        memcpy(pszPath, p + 1, n);
        pszPath += n;
        *pszPath = '\0';

        return (TRUE);
    }

    return (FALSE);
}

/*****************************************************************************/
/* ConvertXpm */
/*****************************************************************************/

typedef int bool;

#define true 1
#define false 0

void ConvertXpm( Display* pDisplay, char *xpm[], Pixmap* aPixmap, Pixmap* aMask, int* nWidth, int* nHeight )
{
	int nColors, nCharsPerPixel;
	XColor *pColors;
	char *pColorAlias;
	int nElement = 0,nColor = 0,i,nX,nY;
	char pColorString[256];
	bool bTransparent = false;
	XGCValues aValues;
    GC aMonoGC;

    int nScreen			= DefaultScreen( pDisplay );
    int nDepth			= DefaultDepth( pDisplay, nScreen );
    Colormap aColormap	= DefaultColormap( pDisplay, nScreen );
    Window aRoot		= DefaultRootWindow( pDisplay );
    GC aGC				= DefaultGC( pDisplay, nScreen );

	sscanf( xpm[ nElement++ ], "%d%d%d%d", nWidth, nHeight,
			&nColors, &nCharsPerPixel );
#if defined DEBUG
	fprintf( stderr, "ConvertXpm: converting width = %d height = %d ncolors = %d chars_per_pixel = %d\n", *nWidth, *nHeight, nColors, nCharsPerPixel );
#endif
	nColor  = 0;
	pColors = (XColor*)malloc( sizeof( XColor ) * nColors );
	pColorAlias = (char*)malloc( nColors * nCharsPerPixel );
	while( nElement <= nColors )
	{
		char* pLine = xpm[nElement++];
		char* pStart = pLine + nCharsPerPixel;
		while( *pStart && ( pStart[0] != 'c' || ! isspace( pStart[1] ) ) )
			pStart++;
		if( *pStart )
		{
			sscanf( pStart,"c %s", pColorString);
			if( strncasecmp( pColorString, "None", 4 ) )
			{
				XAllocNamedColor( pDisplay,
								  aColormap,
								  pColorString, &pColors[nColor], &pColors[nColor] );
				strncpy( &pColorAlias[nColor*nCharsPerPixel],
						 pLine, nCharsPerPixel );
				nColor++;
			}
		}
	}
	nColors = nColor+1;
	
	*aPixmap = XCreatePixmap( pDisplay,
                              aRoot,
                              *nWidth, *nHeight,
                              nDepth );
	XSetForeground( pDisplay,
					aGC,
					BlackPixel( pDisplay, nScreen ) );
	XFillRectangle( pDisplay,
                    *aPixmap,
                    aGC,
					0,0,*nWidth,*nHeight );

	*aMask   = XCreatePixmap( pDisplay, aRoot,
                              *nWidth, *nHeight, 1 );

	aValues.foreground = 0xffffffff;
	aValues.function = GXclear;
	aMonoGC = XCreateGC( pDisplay, *aMask,
                         GCFunction|GCForeground, &aValues );
    
	XFillRectangle( pDisplay, *aMask, aMonoGC,
					0,0, *nWidth, *nHeight );
	aValues.function   = GXset;
	XChangeGC( pDisplay, aMonoGC, GCFunction, &aValues );
	
	for( nY=0; nY < *nHeight; nY++ )
	{
		char *pRun = xpm[ nElement+nY ];
		for( nX=0; nX < *nWidth; nX++ )
		{
			// get color number
			nColor = 0;
			while( nColor < nColors &&
				   strncmp( pRun, &pColorAlias[nColor*nCharsPerPixel],
							nCharsPerPixel ) )
				nColor++;
			if( nColor < nColors )
			{
				XSetForeground( pDisplay,
                                aGC,
								pColors[ nColor ].pixel );
				XDrawPoint( pDisplay,
							*aPixmap,
                            aGC,
							nX, nY );
				
				XDrawPoint( pDisplay,
							*aMask, aMonoGC, nX, nY );
			}
			else
			{
				bTransparent = true;
			}
			pRun += nCharsPerPixel;
		}
	}
	free( pColors );
	free( pColorAlias );
	XFreeGC( pDisplay, aMonoGC );

	if( ! bTransparent )
	{
#if defined DEBUG
		fprintf( stderr, "ConvertXpm: keine Transparenz -> keine Maske\n" );
#endif
		XFreePixmap( pDisplay, *aMask );
		*aMask = None;
	}
}

/********************************/
/* ---      DrawProgress    --- */
/********************************/

void DrawProgress( long nPercent )
{
    if ( nPercent > 100 )
        nPercent = 100;
    else if ( nPercent < 0 )
        nPercent = 0;

    if ( m_bUseX )
    {
        int nX, nY;
        unsigned int nWidth, nHeight;

        XColor   aColor;
        Colormap aColorMap	= DefaultColormap( gpDisplay, screen_num );

        if ( nPercent <= gnLastPercent )
            return;

        gnLastPercent = nPercent;

        nX = gnWindowWidth - PROGRESS_OFFSET - PROGRESS_WIDTH - 1;
        nY = ( ( gnWindowHeight - PROGRESS_OFFSET ) / 2 ) - 1;
        nHeight = PROGRESS_HEIGHT;
        nWidth = PROGRESS_WIDTH * nPercent / 100;

        XAllocNamedColor( gpDisplay, aColorMap, "#000080", &aColor, &aColor );
        XSetForeground( gpDisplay, gaGC, aColor.pixel );
        XFillRectangle( gpDisplay, gaWin, gaGC, nX, nY, nWidth, nHeight );

        nWidth   = PROGRESS_WIDTH;

        XAllocNamedColor( gpDisplay, aColorMap, "black", &aColor, &aColor );
        XSetForeground( gpDisplay, gaGC, aColor.pixel );
        XDrawRectangle( gpDisplay, gaWin, gaGC, nX, nY, nWidth, nHeight );

        XFlush( gpDisplay );
    }
    else
    {
        if ( ( nPercent == 0 ) && ( gnLastPercent == -1 ) )
        {
            gnLastPercent = 0;
            printf( "\nInitializing installation program" );
            return;
        }
        
        nPercent = nPercent / 5;

        if ( nPercent <= gnLastPercent )
            return;
        
        gnLastPercent = nPercent;
        printf( "." );
        
        if ( nPercent == 20 )
            printf( "\n" );
        else
            fflush( stdout );
    }
}
