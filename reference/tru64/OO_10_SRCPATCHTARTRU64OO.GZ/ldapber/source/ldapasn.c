/*************************************************************************
 *
 *  $RCSfile: ldapasn.c,v $
 *
 *  $Revision: 1.1.1.1 $
 *
 *  last change: $Author: hr $ $Date: 2000/09/18 16:31:47 $
 *
 *  The Contents of this file are made available subject to the terms of
 *  either of the following licenses
 *
 *         - GNU Lesser General Public License Version 2.1
 *         - Sun Industry Standards Source License Version 1.1
 *
 *  Sun Microsystems Inc., October, 2000
 *
 *  GNU Lesser General Public License Version 2.1
 *  =============================================
 *  Copyright 2000 by Sun Microsystems, Inc.
 *  901 San Antonio Road, Palo Alto, CA 94303, USA
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License version 2.1, as published by the Free Software Foundation.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *  MA  02111-1307  USA
 *
 *
 *  Sun Industry Standards Source License Version 1.1
 *  =================================================
 *  The contents of this file are subject to the Sun Industry Standards
 *  Source License Version 1.1 (the "License"); You may not use this file
 *  except in compliance with the License. You may obtain a copy of the
 *  License at http://www.openoffice.org/license.html.
 *
 *  Software provided under this License is provided on an "AS IS" basis,
 *  WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING,
 *  WITHOUT LIMITATION, WARRANTIES THAT THE SOFTWARE IS FREE OF DEFECTS,
 *  MERCHANTABLE, FIT FOR A PARTICULAR PURPOSE, OR NON-INFRINGING.
 *  See the License for the specific provisions governing your rights and
 *  obligations concerning the Software.
 *
 *  The Initial Developer of the Original Code is: Sun Microsystems, Inc.
 *
 *  Copyright: 2000 by Sun Microsystems, Inc.
 *
 *  All Rights Reserved.
 *
 *  Contributor(s): _______________________________________
 *
 *
 ************************************************************************/

#ifndef _STDLIB_H
#include <stdlib.h>
#endif

#ifndef _LDAPBER_LDAPASN_H
#include <ldapber/ldapasn.h>
#endif
#if defined(TRU64) && !defined(long)
#define	long	int
#endif

/*========================================================================
 *
 * The Basics.
 *
 *======================================================================*/
/*
 * ASN1_dup.
 */
void* ASN1_dup (ASN1_i2d_t *i2d, ASN1_d2i_t *d2i, void *a)
{
	return NULL;
}

/*========================================================================
 *
 * ASN1_NULL.
 *
 *======================================================================*/
/*
 * ASN1_NULL_new.
 */
ASN1_NULL* ASN1_NULL_new (void)
{
	return NULL;
}

/*
 * i2d_ASN1_NULL.
 */
int i2d_ASN1_NULL (ASN1_NULL *a, BYTE **pp)
{
	return 0;
}

/*
 * d2i_ASN1_NULL.
 */
ASN1_NULL* d2i_ASN1_NULL (ASN1_NULL **a, BYTE **pp, long length)
{
	return NULL;
}

/*========================================================================
 *
 * ASN1_BOOLEAN.
 *
 *======================================================================*/
/*
 * ASN1_BOOLEAN_new.
 */
ASN1_BOOLEAN* ASN1_BOOLEAN_new (void)
{
	return NULL;
}

/*
 * ASN1_BOOLEAN_free.
 */
void ASN1_BOOLEAN_free (ASN1_BOOLEAN *a)
{
}

/*
 * i2d_ASN1_BOOLEAN.
 */
int i2d_ASN1_BOOLEAN (ASN1_BOOLEAN *a, BYTE **pp)
{
	return 0;
}

/*
 * d2i_ASN1_BOOLEAN.
 */
ASN1_BOOLEAN* d2i_ASN1_BOOLEAN (ASN1_BOOLEAN **a, BYTE **pp, long length)
{
	return NULL;
}

/*========================================================================
 *
 * ASN1_BIT_STRING.
 *
 *======================================================================*/
/*
 * ASN1_BIT_STRING_type_new.
 */
ASN1_BIT_STRING* ASN1_BIT_STRING_type_new (int type)
{
	return NULL;
}

/*
 * ASN1_BIT_STRING_free.
 */
void ASN1_BIT_STRING_free (ASN1_BIT_STRING *a)
{
}

/*
 * i2d_ASN1_BIT_STRING.
 */
int i2d_ASN1_BIT_STRING (ASN1_BIT_STRING *a, BYTE **pp)
{
	return 0;
}

/*
 * d2i_ASN1_BIT_STRING.
 */
ASN1_BIT_STRING* d2i_ASN1_BIT_STRING (
	ASN1_BIT_STRING **a, BYTE **pp, long length)
{
	return NULL;
}

/*========================================================================
 *
 * ASN1_BYTES.
 *
 *======================================================================*/
/*
 * i2d_ASN1_BYTES.
 */
int i2d_ASN1_BYTES (
	ASN1_BIT_STRING *a, BYTE **pp, int xtag, int xclass)
{
	return 0;
}

/*
 * d2i_ASN1_BYTES.
 */
ASN1_BIT_STRING* d2i_ASN1_BYTES (
	ASN1_BIT_STRING **a, BYTE **pp, long length, int xtag, int xclass)
{
	return NULL;
}

/*========================================================================
 *
 * ASN1_OCTET_STRING.
 *
 *======================================================================*/
/*
 * i2d_ASN1_OCTET_STRING.
 */
int i2d_ASN1_OCTET_STRING (ASN1_OCTET_STRING *a, BYTE **pp)
{
	return (i2d_ASN1_BYTES (
		a, pp, V_ASN1_OCTET_STRING, V_ASN1_UNIVERSAL));
}

/*
 * d2i_ASN1_OCTET_STRING.
 */
ASN1_OCTET_STRING* d2i_ASN1_OCTET_STRING (
	ASN1_OCTET_STRING **a, BYTE **pp, long length)
{
	return (d2i_ASN1_BYTES (
		a, pp, length, V_ASN1_OCTET_STRING, V_ASN1_UNIVERSAL));
}

/*========================================================================
 *
 * ASN1_OBJECT.
 *
 *======================================================================*/
/*
 * i2d_ASN1_OBJECT.
 */
int i2d_ASN1_OBJECT (ASN1_OBJECT *a, BYTE **pp)
{
	return (i2d_ASN1_BYTES (
		a, pp, V_ASN1_OBJECT, V_ASN1_UNIVERSAL));
}

/*
 * d2i_ASN1_OBJECT.
 */
ASN1_OBJECT* d2i_ASN1_OBJECT (
	ASN1_OBJECT **a, BYTE **pp, long length)
{
	return (d2i_ASN1_BYTES (
		a, pp, length, V_ASN1_OBJECT, V_ASN1_UNIVERSAL));
}

/*========================================================================
 *
 * ASN1_SIGNED_NUMBER.
 *
 *======================================================================*/
/*
 * i2d_ASN1_SIGNED_NUMBER.
 */
int i2d_ASN1_SIGNED_NUMBER (ASN1_SIGNED_NUMBER *a, BYTE **pp)
{
	return 0;
}

/*
 * d2i_ASN1_SIGNED_NUMBER.
 */
ASN1_SIGNED_NUMBER* d2i_ASN1_SIGNED_NUMBER (
	ASN1_SIGNED_NUMBER **a, BYTE **pp, long length)
{
	return NULL;
}

/*
 * ASN1_SIGNED_NUMBER_get.
 */
#if defined(TRU64)
int ASN1_SIGNED_NUMBER_get (ASN1_SIGNED_NUMBER *a, int *v)
#else
int ASN1_SIGNED_NUMBER_get (ASN1_SIGNED_NUMBER *a, long *v)
#endif
{
	return 0;
}

/*
 * ASN1_SIGNED_NUMBER_set.
 */
#if defined(TRU64)
int ASN1_SIGNED_NUMBER_set (ASN1_SIGNED_NUMBER *a, int  v)
#else
int ASN1_SIGNED_NUMBER_set (ASN1_SIGNED_NUMBER *a, long  v)
#endif
{
	return 0;
}

/*========================================================================
 *
 * ASN1_COLLECTION.
 *
 *======================================================================*/
/*
 * ASN1_COLLECTION_new.
 */
ASN1_COLLECTION* ASN1_COLLECTION_new (void)
{
	return NULL;
}

/*
 * ASN1_COLLECTION_free.
 */
void ASN1_COLLECTION_free (ASN1_COLLECTION *a, void (*destroy)())
{
}

/*
 * i2d_ASN1_COLLECTION.
 */
int i2d_ASN1_COLLECTION (
	ASN1_COLLECTION *a, BYTE **pp,
	ASN1_i2d_t *i2d, int xtag, int xclass)
{
	return 0;
}

/*
 * d2i_ASN1_COLLECTION.
 */
ASN1_COLLECTION* d2i_ASN1_COLLECTION (
	ASN1_COLLECTION **a, BYTE **pp, long length,
	ASN1_d2i_t *d2i, int xtag, int xclass)
{
	return NULL;
}

/*
 * ASN1_COLLECTION_insert.
 */
int ASN1_COLLECTION_insert (
	ASN1_COLLECTION *a, char *value, unsigned int pos)
{
	return 0;
}

/*
 * ASN1_COLLECTION_remove.
 */
char* ASN1_COLLECTION_remove (
	ASN1_COLLECTION *a, unsigned int pos)
{
	return NULL;
}

#if defined(TRU64) && defined(long)
#undef long
#endif
