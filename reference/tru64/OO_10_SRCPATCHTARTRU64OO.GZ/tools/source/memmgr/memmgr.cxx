/*************************************************************************
 *
 *  $RCSfile: memmgr.cxx,v $
 *
 *  $Revision: 1.5 $
 *
 *  last change: $Author: hr $ $Date: 2001/10/15 18:40:32 $
 *
 *  The Contents of this file are made available subject to the terms of
 *  either of the following licenses
 *
 *         - GNU Lesser General Public License Version 2.1
 *         - Sun Industry Standards Source License Version 1.1
 *
 *  Sun Microsystems Inc., October, 2000
 *
 *  GNU Lesser General Public License Version 2.1
 *  =============================================
 *  Copyright 2000 by Sun Microsystems, Inc.
 *  901 San Antonio Road, Palo Alto, CA 94303, USA
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License version 2.1, as published by the Free Software Foundation.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *  MA  02111-1307  USA
 *
 *
 *  Sun Industry Standards Source License Version 1.1
 *  =================================================
 *  The contents of this file are subject to the Sun Industry Standards
 *  Source License Version 1.1 (the "License"); You may not use this file
 *  except in compliance with the License. You may obtain a copy of the
 *  License at http://www.openoffice.org/license.html.
 *
 *  Software provided under this License is provided on an "AS IS" basis,
 *  WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING,
 *  WITHOUT LIMITATION, WARRANTIES THAT THE SOFTWARE IS FREE OF DEFECTS,
 *  MERCHANTABLE, FIT FOR A PARTICULAR PURPOSE, OR NON-INFRINGING.
 *  See the License for the specific provisions governing your rights and
 *  obligations concerning the Software.
 *
 *  The Initial Developer of the Original Code is: Sun Microsystems, Inc.
 *
 *  Copyright: 2000 by Sun Microsystems, Inc.
 *
 *  All Rights Reserved.
 *
 *  Contributor(s): _______________________________________
 *
 *
 ************************************************************************/

#ifdef WNT /* avoid 'std::bad_alloc' unresolved externals */
#define _CRTIMP
#define _NTSDK
#endif /* WNT */

#ifndef INCLUDED_ALGORITHM
#include <algorithm>
#define INCLUDED_ALGORITHM
#endif

#ifndef INCLUDED_NEW
#include <new>
#define INCLUDED_NEW
#endif

#ifndef _RTL_ALLOC_H_
#include <rtl/alloc.h>
#endif

#ifndef _NEW_HXX
#include "new.hxx"
#endif

#define SVMEM_REDEFINE_NEWALLOC
#if defined(SVX_LIGHT) || defined(TRU64)
#undef SVMEM_REDEFINE_NEWALLOC
#endif /* SVX_LIGHT */

// =======================================================================
_NEW_HANDLER SetNewHandler (_NEW_HANDLER pfnHandler)
{
	return std::set_new_handler (pfnHandler);
}

// =======================================================================
#ifndef SVMEM_REDEFINE_NEWALLOC
// =======================================================================

void* SvMemAlloc (ULONG nBytes, USHORT nFlags)
{
	return ::operator new (size_t(nBytes));
}

// =======================================================================

void SvMemFree (void * p)
{
	if (p)
	::operator delete (p);
}

// =======================================================================
#else  /* SVMEM_REDEFINE_NEWALLOC */
// =======================================================================

#if defined(GCC) && ( defined(_STLP_REDEFINE_STD) || defined(__STL_REDEFINE_STD) )
#undef std
#endif

#ifdef TRU64 && ( defined(_STLP_REDEFINE_STD) || defined(__STL_REDEFINE_STD) )
#undef std
#endif

static std::new_handler volatile g_pfnHandler = 0;

std::new_handler
SAL_CALL std::set_new_handler (std::new_handler pfnHandler) throw ()
{
	std::new_handler f = g_pfnHandler;
	g_pfnHandler = pfnHandler;
	return f;
}

#if defined(GCC) && ( defined(_STLP_REDEFINE_STD) || defined(__STL_REDEFINE_STD) )
#define std _STL
#endif

#ifdef TRU64 && ( defined(_STLP_REDEFINE_STD) || defined(__STL_REDEFINE_STD) )
#define std _STL
#endif

// =======================================================================

void* SvMemAlloc (ULONG nBytes, USHORT nFlags)
{
	nBytes = std::max(nBytes, ULONG(1));
	for (;;)
	{
		void * p = rtl_allocateMemory (sal_uInt32(nBytes));
		if ((p != 0) || (nFlags & MEM_NOCALLNEWHDL))
			return (p);

		std::new_handler f = g_pfnHandler;
		if (f == 0)
			throw std::bad_alloc();
		(*f)();
	}
}

// =======================================================================

void SvMemFree (void * p)
{
	rtl_freeMemory (p);
}

// =======================================================================

void* SAL_CALL operator new (size_t n) throw (std::bad_alloc)
{
	n = std::max(n, sizeof(char));
	for (;;)
	{
		void * p = rtl_allocateMemory (sal_uInt32(n));
		if (p != 0)
			return (p);

		std::new_handler f = g_pfnHandler;
		if (f == 0)
			throw std::bad_alloc();
		(*f)();
	}
}

// =======================================================================

void SAL_CALL operator delete (void * p) throw ()
{
	rtl_freeMemory (p);
}

// =======================================================================

void* SAL_CALL operator new[] (size_t n) throw (std::bad_alloc)
{
	n = std::max(n, sizeof(char));
	for (;;)
	{
		void * p = rtl_allocateMemory (sal_uInt32(n));
		if (p != 0)
			return (p);

		std::new_handler f = g_pfnHandler;
		if (f == 0)
			throw std::bad_alloc();
		(*f)();
	}
}

// =======================================================================

void SAL_CALL operator delete[] (void * p) throw ()
{
	rtl_freeMemory (p);
}

// =======================================================================
#endif /* SVMEM_REDEFINE_NEWALLOC */
// =======================================================================
